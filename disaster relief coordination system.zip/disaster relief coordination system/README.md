# 🚨 Disaster Relief Coordination System (Part 1)

A complete, full-stack incident command and disaster relief coordination web application built with **React.js + Vite**, **Node.js + Express.js**, and **MongoDB + Mongoose**.

---

## 📌 Project Overview

The **Disaster Relief Coordination System** is designed for real-time crisis management and relief operations. It enables emergency coordinators, volunteers, donors, and affected citizens to coordinate disaster response, manage resource allocations, report field casualties, and deploy rescue teams.

**Part 1** delivers the core authentication, authorization, database persistence, role-based clearance, user profile management, personnel administration console, and responsive command center dashboard.

---

## 🛠️ Tech Stack

### Frontend
- **Framework:** [React.js](https://react.dev/) (v19) with [Vite](https://vite.dev/)
- **Routing:** [React Router v6](https://reactrouter.com/)
- **Styling:** [Tailwind CSS v4](https://tailwindcss.com/)
- **Icons:** [Lucide React](https://lucide.dev/)
- **Notifications:** [React Hot Toast](https://react-hot-toast.com/)
- **HTTP Client:** [Axios](https://axios-http.com/)

### Backend
- **Runtime:** [Node.js](https://nodejs.org/) (JavaScript)
- **Framework:** [Express.js](https://expressjs.com/)
- **Database:** [MongoDB](https://www.mongodb.com/) with [Mongoose](https://mongoosejs.com/) ODM
- **Authentication:** [JSON Web Token (JWT)](https://jwt.io/) & [bcryptjs](https://www.npmjs.com/package/bcryptjs)
- **Security:** [Helmet](https://helmetjs.github.io/), [CORS](https://www.npmjs.com/package/cors), [Express-Validator](https://express-validator.github.io/)
- **Logging:** [Morgan](https://www.npmjs.com/package/morgan)

---

## 📁 Project Structure

```
disaster-relief-coordination-system/
├── backend/
│   ├── config/
│   │   └── db.js                  # MongoDB Mongoose connection handler
│   ├── controllers/
│   │   ├── authController.js      # Register, Login, Me, Logout
│   │   └── userController.js      # Profile, Admin CRUD, Metrics summary
│   ├── middleware/
│   │   ├── authMiddleware.js      # JWT Bearer verification
│   │   ├── roleMiddleware.js      # Role-based clearance guard
│   │   └── errorMiddleware.js     # Centralized error & 404 handler
│   ├── models/
│   │   └── User.js                # Mongoose User Schema & bcrypt hooks
│   ├── routes/
│   │   ├── authRoutes.js          # /api/auth routes with validation
│   │   └── userRoutes.js          # /api/users routes & admin endpoints
│   ├── utils/
│   │   └── generateToken.js       # JWT signing helper
│   ├── uploads/                   # Media & file upload storage
│   ├── seedAdmin.js               # Database seeder for default accounts
│   ├── testApi.js                 # Automated API test suite
│   ├── server.js                  # Express application entrypoint
│   ├── package.json
│   ├── .env.example
│   └── .env
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx          # Command header & active user status
│   │   │   ├── Sidebar.jsx         # Responsive navigation & role menus
│   │   │   ├── ProtectedRoute.jsx  # Route & Role clearance guard
│   │   │   ├── Loading.jsx         # Emergency spinner & pulse radar
│   │   │   ├── PageHeader.jsx      # Reusable page title & actions
│   │   │   ├── StatCard.jsx        # Metric summary card
│   │   │   └── Modal.jsx           # Accessible dialog component
│   │   ├── context/
│   │   │   └── AuthContext.jsx     # User state, JWT storage & auth methods
│   │   ├── layouts/
│   │   │   └── DashboardLayout.jsx # Layout wrapper with Toast provider
│   │   ├── pages/
│   │   │   ├── Login.jsx           # Sign in with demo quick-fill buttons
│   │   │   ├── Register.jsx        # Multi-field citizen registration
│   │   │   ├── Dashboard.jsx       # Incident Command metrics & hubs
│   │   │   ├── Profile.jsx         # Personal details, skills & availability
│   │   │   ├── Users.jsx           # Admin Personnel Management Console
│   │   │   ├── Part2Placeholder.jsx# Upcoming modules roadmap preview
│   │   │   ├── Unauthorized.jsx    # HTTP 403 Access Denied
│   │   │   └── NotFound.jsx        # HTTP 404 Not Found
│   │   ├── services/
│   │   │   ├── api.js              # Axios instance & interceptors
│   │   │   ├── authService.js      # Authentication endpoints
│   │   │   └── userService.js      # User management & profile endpoints
│   │   ├── App.jsx                 # Route definitions & guards
│   │   ├── main.jsx                # Application root mounting
│   │   └── index.css               # Tailwind & command center styles
│   ├── index.html
│   ├── vite.config.js
│   ├── package.json
│   ├── .env.example
│   └── .env
│
├── README.md
└── .gitignore
```

---

## ⚡ Prerequisites

Ensure you have the following installed on your machine:
- **Node.js** (v18 or higher)
- **npm** (v9 or higher)
- **MongoDB** (Local instance running on port `27017` or MongoDB Atlas URI)

---

## ⚙️ Environment Variables Setup

### Backend Configuration (`backend/.env`)
Create a file named `.env` in the `backend/` directory:

```env
PORT=5000
NODE_ENV=development
MONGO_URI=mongodb://127.0.0.1:27017/disaster_relief_db
JWT_SECRET=disaster_relief_super_secret_jwt_key_2026
CLIENT_URL=http://localhost:5173

# Admin Seeder Credentials
ADMIN_NAME=Emergency Coordinator Admin
ADMIN_EMAIL=admin@disasterrelief.org
ADMIN_PASSWORD=Admin@12345
```

### Frontend Configuration (`frontend/.env`)
Create a file named `.env` in the `frontend/` directory:

```env
VITE_API_URL=http://localhost:5000/api
```

---

## 🚀 Installation & Setup Instructions

### 1. Clone the repository and navigate to the project root:
```bash
cd "disaster relief coordination system"
```

### 2. Backend Setup & Run:
```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Seed Admin and Demo Accounts into MongoDB
npm run seed

# Start the Express server
npm run dev
# (or: npm start)
```
The backend will connect to MongoDB and listen on `http://localhost:5000`.

### 3. Frontend Setup & Run:
Open a second terminal window:
```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Start the Vite development server
npm run dev
```
The frontend portal will be accessible at `http://localhost:5173`.

---

## 🔑 Default Pre-Seeded Accounts

Running `npm run seed` in the `backend/` folder creates the default demo accounts:

| Role | Email | Password | Clearance Level |
|---|---|---|---|
| **Administrator (HQ)** | `admin@disasterrelief.org` | `Admin@12345` | Full access (`/users`, profile, stats) |
| **Volunteer (Field)** | `volunteer@disasterrelief.org` | `Volunteer@12345` | Field operations & profile |
| **Affected User** | `resident@disasterrelief.org` | `Resident@12345` | Relief seeker & profile |


---

## 🔄 Authentication & Authorization Flow

```
[React Frontend]
      │
      ▼
[Axios Service Layer (src/services/api.js)]
      │ (Bearer JWT header attached automatically)
      ▼
[Express REST API (/api/auth, /api/users)]
      │
      ├──▶ [authMiddleware.js] -> Verifies JWT token
      │
      ├──▶ [roleMiddleware.js] -> Verifies role clearance (e.g. 'admin')
      │
      ▼
[Controller (authController.js / userController.js)]
      │
      ▼
[Mongoose User Model & bcryptjs]
      │
      ▼
[MongoDB Persistence]
```

1. **Registration:** New users are automatically registered with the role `affected_user` (normal users cannot register as `admin`).
2. **Login:** Server verifies credentials via `bcrypt.compare`, generates a 7-day signed JWT token, and returns user details without the password field.
3. **Protected APIs:** Client includes `Authorization: Bearer <token>` on all requests.
4. **Role Protection:** Non-admin users attempting to access `/users` are immediately denied with HTTP 403.

---

## 📡 Implemented API Endpoints (Part 1)

### Authentication (`/api/auth`)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| `POST` | `/api/auth/register` | Public | Register new user account (role: `affected_user`) |
| `POST` | `/api/auth/login` | Public | Authenticate user & receive JWT token |
| `GET` | `/api/auth/me` | Private | Get currently authenticated user details |
| `POST` | `/api/auth/logout` | Public/Private | Clear authentication session |

### User & Profile Management (`/api/users`)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| `GET` | `/api/users/profile` | Private | Retrieve logged-in user profile |
| `PUT` | `/api/users/profile` | Private | Update personal info, skills & availability |
| `GET` | `/api/users/stats/summary`| Private | Retrieve live user counts and metrics summary |
| `GET` | `/api/users` | Admin Only | List all users with `?search=` and `?role=` filters |
| `GET` | `/api/users/:id` | Admin Only | Get individual user record by ID |
| `PUT` | `/api/users/:id` | Admin Only | Update user role and contact information |
| `DELETE`| `/api/users/:id` | Admin Only | Delete user account from MongoDB |

### Health Check (`/api/health`)
| Method | Endpoint | Access | Description |
|---|---|---|---|
| `GET` | `/api/health` | Public | System status and operational heartbeat |

---

## ✅ Part 1 Features Completed

- [x] **Full-Stack Architecture:** Clean separation of React+Vite frontend and Node+Express backend.
- [x] **MongoDB Persistence:** Mongoose connection with error handling and reconnection logging.
- [x] **User Model:** Comprehensive schema (`name`, `email`, `password`, `phone`, `address`, `city`, `role`, `skills`, `availability`, `timestamps`).
- [x] **Password Hashing:** `bcryptjs` pre-save salt and hashing hook.
- [x] **JWT Authentication:** Signed tokens with Bearer authorization middleware.
- [x] **Role-Based Access Control:** Strict role segregation (`admin`, `volunteer`, `affected_user`, `donor`).
- [x] **Admin Seeder Script:** Automatic idempotent admin and demo account creation.
- [x] **Profile Management:** View and edit personal info, skill tags manager, and availability states.
- [x] **Admin Personnel Console:** Real-time search, role filter pills, view user modal, role promotion modal, and safety-guarded delete user modal.
- [x] **Emergency Command Dashboard:** Live database metrics, personnel distribution cards, and quick action hubs.
- [x] **Modern UI/UX:** Dark Mode Command Center aesthetics with Tailwind CSS, Lucide icons, glassmorphism, and responsive drawer.
- [x] **Notifications & Feedback:** `react-hot-toast` notifications and smooth animated loaders.
- [x] **Security Middleware:** `helmet`, `cors` whitelist, sanitized error handler, and 404 catch-all.

---

## 🔮 Part 2 Planned Features

1. **Disaster Incident Reports:** Geo-located incident reporting, photo uploads, damage severity tags.
2. **Relief Requests & Aid Dispatch:** Citizen emergency request queue with triage priority allocation.
3. **Volunteers & Field Squads:** Emergency team formation, skill-based task assignments, GPS tracking.
4. **Resource Inventory Ledger:** Real-time stock levels for medical supplies, food rations, clean water, and rescue vehicles.
5. **Relief Camps & Evacuation Shelters:** Capacity management, bed occupancy rates, and evacuee registries.
6. **Donations & Financial Relief:** Payment gateway integration, transparent ledger, and supply shipment tracking.
7. **Emergency Broadcasts:** Multi-channel SMS and alert siren networks for imminent hazards.
8. **Executive Reports & Analytics:** Situational reports, casualty trends, and PDF export.

---

## 🧪 Running Automated Backend API Tests

To run the automated 12-point API test suite:
```bash
cd backend
node testApi.js
```
All tests verify status codes, role rejections, duplicate validations, profile updates, and database deletions.
