import api from './api';

export const reliefRequestService = {
  // Get relief requests with filters
  getReliefRequests: async (params = {}) => {
    const query = new URLSearchParams();
    if (params.search) query.append('search', params.search);
    if (params.requestType && params.requestType !== 'all') query.append('requestType', params.requestType);
    if (params.priority && params.priority !== 'all') query.append('priority', params.priority);
    if (params.status && params.status !== 'all') query.append('status', params.status);
    if (params.city && params.city !== 'all') query.append('city', params.city);
    if (params.myRequests) query.append('myRequests', params.myRequests);
    if (params.myAssigned) query.append('myAssigned', params.myAssigned);
    if (params.all) query.append('all', params.all);

    const queryString = query.toString();
    return await api.get(queryString ? `/relief-requests?${queryString}` : '/relief-requests');
  },

  // Get single relief request by ID
  getReliefRequestById: async (id) => {
    return await api.get(`/relief-requests/${id}`);
  },

  // Create new relief request
  createReliefRequest: async (data) => {
    return await api.post('/relief-requests', data);
  },

  // Update relief request (Status, Volunteer assignment, details)
  updateReliefRequest: async (id, data) => {
    return await api.put(`/relief-requests/${id}`, data);
  },

  // Admin: Assign volunteer to relief request
  assignVolunteer: async (id, volunteerId) => {
    return await api.put(`/relief-requests/${id}/assign`, { volunteerId });
  },

  // Volunteer: Get assigned tasks for currently logged-in volunteer
  getMyTasks: async () => {
    return await api.get('/relief-requests/my-tasks');
  },

  // Volunteer: Update task status (Assigned -> In Progress -> Completed)
  updateTaskStatus: async (id, status) => {
    return await api.put(`/relief-requests/${id}/status`, { status });
  },

  // Delete relief request
  deleteReliefRequest: async (id) => {
    return await api.delete(`/relief-requests/${id}`);
  },
};

export default reliefRequestService;
