import api from './api';

export const disasterService = {
  // Get all disaster reports with optional filters (search, type, severity, status, city, page, limit)
  getDisasters: async (params = {}) => {
    const query = new URLSearchParams();
    if (params.search) query.append('search', params.search);
    if (params.type && params.type !== 'all') query.append('type', params.type);
    if (params.disasterType && params.disasterType !== 'all') query.append('disasterType', params.disasterType);
    if (params.severity && params.severity !== 'all') query.append('severity', params.severity);
    if (params.status && params.status !== 'all') query.append('status', params.status);
    if (params.city && params.city !== 'all') query.append('city', params.city);
    if (params.page) query.append('page', params.page);
    if (params.limit) query.append('limit', params.limit);

    const queryString = query.toString();
    return await api.get(queryString ? `/disasters?${queryString}` : '/disasters');
  },

  // Get single disaster report by ID
  getDisasterById: async (id) => {
    return await api.get(`/disasters/${id}`);
  },

  // Create new disaster report
  createDisaster: async (disasterData) => {
    return await api.post('/disasters', disasterData);
  },

  // Update disaster report
  updateDisaster: async (id, updateData) => {
    return await api.put(`/disasters/${id}`, updateData);
  },

  // Delete disaster report
  deleteDisaster: async (id) => {
    return await api.delete(`/disasters/${id}`);
  },
};

export default disasterService;
