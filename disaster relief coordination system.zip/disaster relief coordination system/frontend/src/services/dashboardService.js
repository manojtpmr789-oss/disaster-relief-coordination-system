import api from './api';

export const dashboardService = {
  // Get consolidated live system stats and charts data
  getDashboardStats: async () => {
    return await api.get('/dashboard/stats');
  },
  // Get volunteer-specific stats (assignedToMe, completedByMe, etc.)
  getVolunteerDashboardStats: async () => {
    return await api.get('/dashboard/volunteer-stats');
  },
};

export default dashboardService;
