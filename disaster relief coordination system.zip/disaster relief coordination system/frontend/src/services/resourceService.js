import api from './api';

export const resourceService = {
  // Get all resources with search & category filters
  getResources: async (params = {}) => {
    const query = new URLSearchParams();
    if (params.search) query.append('search', params.search);
    if (params.category && params.category !== 'all') query.append('category', params.category);
    if (params.status && params.status !== 'all') query.append('status', params.status);
    if (params.city && params.city !== 'all') query.append('city', params.city);

    const queryString = query.toString();
    return await api.get(queryString ? `/resources?${queryString}` : '/resources');
  },

  // Get resource by ID
  getResourceById: async (id) => {
    return await api.get(`/resources/${id}`);
  },

  // Create resource item
  createResource: async (data) => {
    return await api.post('/resources', data);
  },

  // Update resource details
  updateResource: async (id, data) => {
    return await api.put(`/resources/${id}`, data);
  },

  // Adjust resource quantity
  updateQuantity: async (id, action, amount) => {
    return await api.put(`/resources/${id}/quantity`, { action, amount });
  },

  // Delete resource
  deleteResource: async (id) => {
    return await api.delete(`/resources/${id}`);
  },
};

export default resourceService;
