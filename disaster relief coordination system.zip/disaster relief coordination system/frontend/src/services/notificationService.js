import api from './api';

export const notificationService = {
  // Get notifications for current user
  getNotifications: async () => {
    return await api.get('/notifications');
  },

  // Mark single notification as read
  markAsRead: async (id) => {
    return await api.put(`/notifications/${id}/read`);
  },

  // Mark all notifications as read
  markAllAsRead: async () => {
    return await api.put('/notifications/read-all');
  },

  // Delete notification
  deleteNotification: async (id) => {
    return await api.delete(`/notifications/${id}`);
  },
};

export default notificationService;
