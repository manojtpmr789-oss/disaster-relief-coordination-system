import api from './api';

export const reportService = {
  // Get report dataset with multi-criteria filters
  getReportSummary: async (params = {}) => {
    const query = new URLSearchParams();
    if (params.module) query.append('module', params.module);
    if (params.city && params.city !== 'all') query.append('city', params.city);
    if (params.type && params.type !== 'all') query.append('type', params.type);
    if (params.severity && params.severity !== 'all') query.append('severity', params.severity);
    if (params.status && params.status !== 'all') query.append('status', params.status);
    if (params.priority && params.priority !== 'all') query.append('priority', params.priority);
    if (params.startDate) query.append('startDate', params.startDate);
    if (params.endDate) query.append('endDate', params.endDate);

    const queryString = query.toString();
    return await api.get(queryString ? `/reports/summary?${queryString}` : '/reports/summary');
  },
};

export default reportService;
