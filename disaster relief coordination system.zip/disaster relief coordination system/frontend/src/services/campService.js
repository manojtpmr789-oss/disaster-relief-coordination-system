import api from './api';

export const campService = {
  // Get all relief camps with search and filters
  getCamps: async (params = {}) => {
    const query = new URLSearchParams();
    if (params.search) query.append('search', params.search);
    if (params.city && params.city !== 'all') query.append('city', params.city);
    if (params.status && params.status !== 'all') query.append('status', params.status);
    if (params.medical) query.append('medical', params.medical);
    if (params.food) query.append('food', params.food);

    const queryString = query.toString();
    return await api.get(queryString ? `/camps?${queryString}` : '/camps');
  },

  // Get single relief camp by ID
  getCampById: async (id) => {
    return await api.get(`/camps/${id}`);
  },

  // Create relief camp
  createCamp: async (data) => {
    return await api.post('/camps', data);
  },

  // Update relief camp
  updateCamp: async (id, data) => {
    return await api.put(`/camps/${id}`, data);
  },

  // Update camp occupancy
  updateOccupancy: async (id, occupancy) => {
    return await api.put(`/camps/${id}/occupancy`, { occupancy });
  },

  // Delete relief camp
  deleteCamp: async (id) => {
    return await api.delete(`/camps/${id}`);
  },
};

export default campService;
