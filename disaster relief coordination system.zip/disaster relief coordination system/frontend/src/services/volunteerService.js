import api from './api';

export const volunteerService = {
  // Get volunteers with filters
  getVolunteers: async (params = {}) => {
    const query = new URLSearchParams();
    if (params.search) query.append('search', params.search);
    if (params.skill && params.skill !== 'all') query.append('skill', params.skill);
    if (params.city && params.city !== 'all') query.append('city', params.city);
    if (params.availability && params.availability !== 'all') query.append('availability', params.availability);
    if (params.verification && params.verification !== 'all') query.append('verification', params.verification);

    const queryString = query.toString();
    return await api.get(queryString ? `/volunteers?${queryString}` : '/volunteers');
  },

  // Get volunteer by ID
  getVolunteerById: async (id) => {
    return await api.get(`/volunteers/${id}`);
  },

  // Get logged-in user volunteer profile
  getMyProfile: async () => {
    return await api.get('/volunteers/profile/me');
  },

  // Update logged-in user volunteer profile
  updateMyProfile: async (data) => {
    return await api.put('/volunteers/profile/me', data);
  },

  // Admin: Verify volunteer
  verifyVolunteer: async (id, verificationStatus) => {
    return await api.put(`/volunteers/${id}/verify`, { verificationStatus });
  },

  // Admin: Assign task to volunteer
  assignTask: async (volunteerId, taskId) => {
    return await api.put(`/volunteers/${volunteerId}/assign`, { taskId });
  },
};

export default volunteerService;
