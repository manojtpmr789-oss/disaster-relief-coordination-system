import api from './api';

export const donationService = {
  // Get donations with filters
  getDonations: async (params = {}) => {
    const query = new URLSearchParams();
    if (params.search) query.append('search', params.search);
    if (params.type && params.type !== 'all') query.append('type', params.type);
    if (params.status && params.status !== 'all') query.append('status', params.status);
    if (params.myDonations) query.append('myDonations', params.myDonations);

    const queryString = query.toString();
    return await api.get(queryString ? `/donations?${queryString}` : '/donations');
  },

  // Get single donation by ID
  getDonationById: async (id) => {
    return await api.get(`/donations/${id}`);
  },

  // Create donation
  createDonation: async (data) => {
    return await api.post('/donations', data);
  },

  // Update donation status
  updateDonation: async (id, data) => {
    return await api.put(`/donations/${id}`, data);
  },

  // Delete donation
  deleteDonation: async (id) => {
    return await api.delete(`/donations/${id}`);
  },
};

export default donationService;
