import axios from 'axios';

const API_BASE_URL =
  import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 15000,
});

// Request interceptor: Attach JWT token if available
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor: Standardize error formatting
api.interceptors.response.use(
  (response) => {
    if (response.data && typeof response.data === 'object' && !('data' in response.data)) {
      try {
        Object.defineProperty(response.data, 'data', {
          value: response.data,
          enumerable: false,
          writable: true,
          configurable: true,
        });
      } catch (e) {
        // Ignore if property cannot be defined
      }
    }
    return response.data;
  },
  (error) => {
    let errorMessage = 'An unexpected server error occurred';

    if (error.response) {
      // The request was made and the server responded with a status code
      if (error.response.status === 401) {
        // Unauthorized - remove stale token if invalid
        const currentPath = window.location.pathname;
        if (currentPath !== '/login' && currentPath !== '/register') {
          localStorage.removeItem('token');
          localStorage.removeItem('user');
        }
      }
      errorMessage = error.response.data?.message || `Server returned error ${error.response.status}`;
    } else if (error.request) {
      // The request was made but no response was received
      errorMessage = 'Unable to connect to the backend server. Please verify the API is running on port 5000.';
    } else {
      errorMessage = error.message;
    }

    const enhancedError = new Error(errorMessage);
    enhancedError.statusCode = error.response?.status;
    enhancedError.data = error.response?.data;

    return Promise.reject(enhancedError);
  }
);

export default api;
