import api from './api';

export const userService = {
  // Get logged-in user profile
  getProfile: async () => {
    return await api.get('/users/profile');
  },

  // Update logged-in user profile
  updateProfile: async (profileData) => {
    return await api.put('/users/profile', profileData);
  },

  // Get dashboard metrics summary
  getDashboardStats: async () => {
    return await api.get('/users/stats/summary');
  },

  // Admin: Get all users with optional search, role filter, and pagination
  getAllUsers: async (params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.search) searchParams.append('search', params.search);
    if (params.role && params.role !== 'all') searchParams.append('role', params.role);
    if (params.page) searchParams.append('page', params.page);
    if (params.limit) searchParams.append('limit', params.limit);

    const queryString = searchParams.toString();
    const endpoint = queryString ? `/users?${queryString}` : '/users';
    return await api.get(endpoint);
  },

  // Admin: Get user by ID
  getUserById: async (id) => {
    return await api.get(`/users/${id}`);
  },

  // Admin: Update user role and details
  updateUser: async (id, userData) => {
    return await api.put(`/users/${id}`, userData);
  },

  // Admin: Delete user account
  deleteUser: async (id) => {
    return await api.delete(`/users/${id}`);
  },
};

export default userService;
