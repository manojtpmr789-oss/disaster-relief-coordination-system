import api from './api';

export const authService = {
  // Register a new user
  register: async (userData) => {
    return await api.post('/auth/register', userData);
  },

  // Log in user
  login: async (credentials) => {
    return await api.post('/auth/login', credentials);
  },

  // Get currently authenticated user
  getMe: async () => {
    return await api.get('/auth/me');
  },

  // Log out user
  logout: async () => {
    return await api.post('/auth/logout');
  },
};

export default authService;
