import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ShieldAlert,
  Users,
  Package,
  ClipboardList,
  AlertTriangle,
  CheckCircle2,
  Clock,
  RefreshCw,
  PlusCircle,
  FileText,
} from 'lucide-react';
import { dashboardService } from '../../services/dashboardService';
import { DisastersByTypeChart, DisastersBySeverityChart } from '../charts/DisasterCharts';
import { ReliefRequestsStatusChart } from '../charts/RequestCharts';
import toast from 'react-hot-toast';

const StatCard = ({ icon: Icon, label, value, sub, color, to }) => {
  const colorMap = {
    rose: {
      bg: 'bg-rose-500/10',
      text: 'text-rose-400',
      border: 'hover:border-rose-500/40',
    },
    orange: {
      bg: 'bg-orange-500/10',
      text: 'text-orange-400',
      border: 'hover:border-orange-500/40',
    },
    violet: {
      bg: 'bg-violet-500/10',
      text: 'text-violet-400',
      border: 'hover:border-violet-500/40',
    },
    sky: {
      bg: 'bg-sky-500/10',
      text: 'text-sky-400',
      border: 'hover:border-sky-500/40',
    },
    teal: {
      bg: 'bg-teal-500/10',
      text: 'text-teal-400',
      border: 'hover:border-teal-500/40',
    },
    emerald: {
      bg: 'bg-emerald-500/10',
      text: 'text-emerald-400',
      border: 'hover:border-emerald-500/40',
    },
    yellow: {
      bg: 'bg-amber-500/10',
      text: 'text-amber-400',
      border: 'hover:border-amber-500/40',
    },
  };

  const style = colorMap[color] || colorMap.sky;

  return (
    <Link
      to={to || '#'}
      className={`group relative bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-start gap-3.5 ${style.border} transition-all duration-200`}
    >
      <div className={`w-10 h-10 rounded-lg ${style.bg} flex items-center justify-center shrink-0`}>
        <Icon className={`w-5 h-5 ${style.text}`} />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-xl font-bold text-white tracking-tight leading-tight">{value ?? '—'}</p>
        <p className="text-xs font-medium text-slate-400 mt-0.5 truncate">{label}</p>
        {sub && <p className="text-[11px] text-slate-500 mt-0.5 truncate">{sub}</p>}
      </div>
    </Link>
  );
};

const SectionHeading = ({ title, subtitle }) => (
  <div className="mb-3">
    <h2 className="text-base font-bold text-white tracking-tight">{title}</h2>
    {subtitle && <p className="text-xs text-slate-400 mt-0.5">{subtitle}</p>}
  </div>
);

export const AdminDashboardView = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const res = await dashboardService.getDashboardStats();
      const data = res?.metrics ? res : res?.data;
      if (data) setStats(data);
    } catch {
      toast.error('Failed to load dashboard statistics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
        <RefreshCw className="w-5 h-5 animate-spin text-blue-400" />
        <span className="text-xs sm:text-sm">Loading dashboard metrics...</span>
      </div>
    );
  }

  const m = stats?.metrics || {};
  const charts = stats?.charts || {};
  const recentDisasters = stats?.recentDisasters || stats?.recent?.disasters || [];

  return (
    <div className="space-y-6">
      {/* Metric Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-5 gap-3">
        <StatCard icon={ShieldAlert} label="Total Disasters" value={m.totalDisasters} color="rose" to="/disasters" />
        <StatCard icon={AlertTriangle} label="Active Disasters" value={m.activeDisasters} color="orange" to="/disasters" />
        <StatCard icon={ClipboardList} label="Relief Requests" value={m.totalReliefRequests} color="violet" to="/relief-requests" />
        <StatCard icon={Users} label="Total Volunteers" value={m.totalVolunteers} color="sky" to="/volunteers" />
        <StatCard icon={Package} label="Resources Stock" value={m.totalResources ?? '—'} color="emerald" to="/resources" />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <SectionHeading title="Disasters by Type" subtitle="Distribution by incident type" />
          <div className="h-64">
            <DisastersByTypeChart data={charts.disastersByType} />
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <SectionHeading title="Severity Breakdown" subtitle="Incident severity levels" />
          <div className="h-64">
            <DisastersBySeverityChart data={charts.disastersBySeverity} />
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <SectionHeading title="Request Status" subtitle="Relief request pipeline" />
          <div className="h-64">
            <ReliefRequestsStatusChart data={charts.requestsByStatus} />
          </div>
        </div>
      </div>

      {/* Recent Disasters Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5">
        <div className="flex items-center justify-between mb-3">
          <SectionHeading title="Recent Disaster Reports" subtitle="Latest recorded incident reports in MongoDB" />
          <Link to="/disasters" className="text-xs text-blue-400 hover:text-blue-300 font-semibold transition-colors">
            View All Disasters →
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase tracking-wider">
                <th className="text-left pb-2.5 pr-4 font-semibold">Incident</th>
                <th className="text-left pb-2.5 pr-4 font-semibold">Type</th>
                <th className="text-left pb-2.5 pr-4 font-semibold">City</th>
                <th className="text-left pb-2.5 pr-4 font-semibold">Severity</th>
                <th className="text-left pb-2.5 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {recentDisasters.length === 0 ? (
                <tr>
                  <td colSpan="5" className="py-6 text-center text-slate-500">
                    No recent disaster reports found.
                  </td>
                </tr>
              ) : (
                recentDisasters.map((d) => (
                  <tr key={d._id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 pr-4">
                      <Link to={`/disasters/${d._id}`} className="font-semibold text-white hover:text-blue-400 transition-colors line-clamp-1">
                        {d.title}
                      </Link>
                    </td>
                    <td className="py-2.5 pr-4 text-slate-400">{d.disasterType}</td>
                    <td className="py-2.5 pr-4 text-slate-400">{d.city}</td>
                    <td className="py-2.5 pr-4">
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                        d.severity === 'Critical' ? 'bg-rose-500/20 text-rose-400' :
                        d.severity === 'High' ? 'bg-orange-500/20 text-orange-400' :
                        d.severity === 'Medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-green-500/20 text-green-400'
                      }`}>{d.severity}</span>
                    </td>
                    <td className="py-2.5">
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                        d.status === 'Active' ? 'bg-rose-500/20 text-rose-400' :
                        d.status === 'Verified' ? 'bg-sky-500/20 text-sky-400' :
                        d.status === 'Resolved' ? 'bg-emerald-500/20 text-emerald-400' :
                        'bg-slate-500/20 text-slate-400'
                      }`}>{d.status}</span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export const VolunteerDashboardView = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch volunteer-specific stats from dedicated endpoint
    const fetchStats = async () => {
      try {
        const [volunteerRes, globalRes] = await Promise.all([
          dashboardService.getVolunteerDashboardStats(),
          dashboardService.getDashboardStats(),
        ]);

        const volunteerData = volunteerRes?.metrics ? volunteerRes : volunteerRes?.data || volunteerRes;
        const globalData = globalRes?.charts ? globalRes : globalRes?.data || globalRes;

        setStats({
          volunteerMetrics: volunteerData?.metrics || volunteerRes?.metrics || {},
          charts: globalData?.charts || {},
        });
      } catch {
        // fallback – leave stats null so dashboard shows 0s gracefully
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
        <RefreshCw className="w-5 h-5 animate-spin text-blue-400" />
        <span className="text-xs sm:text-sm">Loading volunteer dashboard...</span>
      </div>
    );
  }

  const vm = stats?.volunteerMetrics || {};

  return (
    <div className="space-y-6">
      {/* Metrics Row – all from real MongoDB data */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={ShieldAlert} label="Active Disasters" value={vm.activeDisasters ?? '—'} color="rose" to="/disasters" />
        <StatCard icon={ClipboardList} label="Pending Requests" value={vm.pendingReliefRequests ?? '—'} color="yellow" to="/relief-requests" />
        <StatCard icon={Clock} label="Assigned Tasks" value={vm.assignedToMe ?? 0} color="sky" to="/my-tasks" />
        <StatCard icon={CheckCircle2} label="Completed Tasks" value={vm.completedByMe ?? 0} color="emerald" to="/my-tasks" />
      </div>

      {/* Relief Request Triage Chart – full width */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <SectionHeading title="Relief Request Triage" subtitle="Current status pipeline across all requests" />
          <Link to="/relief-requests" className="text-xs text-blue-400 hover:text-blue-300 font-semibold transition-colors">
            View All →
          </Link>
        </div>
        <div className="h-64">
          <ReliefRequestsStatusChart data={stats?.charts?.requestsByStatus} />
        </div>
      </div>
    </div>
  );
};

export const AffectedUserDashboardView = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardService.getDashboardStats()
      .then((res) => {
        const data = res?.metrics ? res : res?.data;
        if (data) setStats(data);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
        <RefreshCw className="w-5 h-5 animate-spin text-blue-400" />
        <span className="text-xs sm:text-sm">Loading user dashboard...</span>
      </div>
    );
  }

  const m = stats?.metrics || {};

  return (
    <div className="space-y-6">
      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <StatCard icon={ShieldAlert} label="Active Disasters" value={m.activeDisasters} color="rose" to="/disasters" />
        <StatCard icon={ClipboardList} label="My Relief Requests" value={m.myRequests || m.totalReliefRequests || 0} color="violet" to="/my-requests" />
        <StatCard icon={Clock} label="Pending Requests" value={m.pendingReliefRequests || m.pendingRequests || 0} color="yellow" to="/my-requests" />
      </div>

      {/* Quick Action Tiles */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Link
          to="/disasters/create"
          className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-rose-500/40 transition-all duration-200 group"
        >
          <div className="w-10 h-10 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400 mb-3">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-white text-sm mb-1">Report a Disaster</h3>
          <p className="text-xs text-slate-400">Alert emergency response teams about an active incident in your area.</p>
        </Link>

        <Link
          to="/relief-requests/create"
          className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-violet-500/40 transition-all duration-200 group"
        >
          <div className="w-10 h-10 rounded-lg bg-violet-500/10 flex items-center justify-center text-violet-400 mb-3">
            <ClipboardList className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-white text-sm mb-1">Request Relief Support</h3>
          <p className="text-xs text-slate-400">Submit an urgent request for food, medical aid, or emergency rescue.</p>
        </Link>

        <Link
          to="/disasters"
          className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-blue-500/40 transition-all duration-200 group"
        >
          <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 mb-3">
            <FileText className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-white text-sm mb-1">View Disaster Reports</h3>
          <p className="text-xs text-slate-400">Track recorded disaster alerts, severity levels, and real-time status.</p>
        </Link>
      </div>
    </div>
  );
};
