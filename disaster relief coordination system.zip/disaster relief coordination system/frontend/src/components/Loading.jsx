import React from 'react';
import { ShieldAlert, Loader2 } from 'lucide-react';

export const Loading = ({ fullScreen = false, message = 'Loading emergency coordination data...' }) => {
  if (fullScreen) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950/90 backdrop-blur-md">
        <div className="relative flex items-center justify-center mb-6">
          <div className="w-20 h-20 rounded-full border-4 border-sky-500/20 border-t-sky-500 animate-spin"></div>
          <ShieldAlert className="w-8 h-8 text-sky-400 absolute animate-pulse" />
        </div>
        <h3 className="text-lg font-semibold text-slate-100 mb-1 tracking-wide">
          Disaster Relief Coordination System
        </h3>
        <p className="text-sm text-slate-400 animate-pulse">{message}</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center p-12 space-y-3">
      <div className="relative flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-sky-400 animate-spin" />
      </div>
      <p className="text-sm text-slate-400 font-medium">{message}</p>
    </div>
  );
};

export default Loading;
