import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  ShieldAlert,
  HeartHandshake,
  Users2,
  Package,
  Bell,
  UserCog,
  LogOut,
  X,
  Shield,
  ClipboardList,
  PlusCircle,
} from 'lucide-react';

// Role-based nav configuration strictly according to project specifications
const NAV_CONFIG = {
  admin: [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Disaster Reports', path: '/disasters', icon: ShieldAlert },
    { name: 'Relief Requests', path: '/relief-requests', icon: HeartHandshake },
    { name: 'Volunteers', path: '/volunteers', icon: Users2 },
    { name: 'Resources', path: '/resources', icon: Package },
    { name: 'Notifications', path: '/notifications', icon: Bell },
    { name: 'Manage Users', path: '/users', icon: UserCog },
    { name: 'My Profile', path: '/profile', icon: Shield },
  ],
  volunteer: [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Disaster Reports', path: '/disasters', icon: ShieldAlert },
    { name: 'Relief Requests / My Tasks', path: '/my-tasks', icon: ClipboardList },
    { name: 'Notifications', path: '/notifications', icon: Bell },
    { name: 'My Profile', path: '/profile', icon: Shield },
  ],
  affected_user: [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Disaster Reports', path: '/disasters', icon: ShieldAlert },
    { name: 'Report Disaster', path: '/disasters/create', icon: PlusCircle },
    { name: 'My Relief Requests', path: '/my-requests', icon: ClipboardList },
    { name: 'Notifications', path: '/notifications', icon: Bell },
    { name: 'My Profile', path: '/profile', icon: Shield },
  ],
};

const ROLE_LABELS = {
  admin: { label: 'Admin', color: 'bg-rose-500/10 text-rose-400 border-rose-500/30' },
  volunteer: { label: 'Volunteer', color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' },
  affected_user: { label: 'Affected User', color: 'bg-amber-500/10 text-amber-400 border-amber-500/30' },
  donor: { label: 'Donor', color: 'bg-sky-500/10 text-sky-400 border-sky-500/30' },
};

export const Sidebar = ({ isOpen, onClose }) => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  const role = currentUser?.role || 'affected_user';
  const navItems = NAV_CONFIG[role] || NAV_CONFIG.affected_user;
  const roleStyle = ROLE_LABELS[role] || ROLE_LABELS.affected_user;

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 z-30 bg-slate-950/70 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar panel */}
      <aside
        className={`fixed top-0 left-0 z-40 h-screen w-64 flex flex-col bg-slate-950 border-r border-slate-800 transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="flex items-center justify-between px-4 py-4 border-b border-slate-800 h-16 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-blue-600 shadow-md text-white">
              <Shield className="w-4 h-4" />
            </div>
            <div className="leading-tight">
              <p className="text-xs font-bold text-white tracking-tight">Disaster Relief</p>
              <p className="text-[10px] text-slate-400">Coordination System</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:text-white hover:bg-slate-800 lg:hidden transition-colors"
            aria-label="Close Sidebar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* User Pill */}
        <div className="px-4 py-3 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-xs uppercase">
              {currentUser?.name?.[0] || 'U'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-white truncate">{currentUser?.name || 'User'}</p>
              <span className={`inline-block mt-0.5 px-1.5 py-0.2 rounded text-[10px] font-semibold border ${roleStyle.color}`}>
                {roleStyle.label}
              </span>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={`${item.path}-${item.name}`}
                to={item.path}
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-all duration-200 group ${
                    isActive
                      ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    <Icon className={`w-4 h-4 shrink-0 transition-colors ${isActive ? 'text-blue-400' : 'text-slate-400 group-hover:text-white'}`} />
                    <span className="truncate">{item.name}</span>
                  </>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Footer with Logout */}
        <div className="p-3 border-t border-slate-800 shrink-0">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium text-rose-400 hover:bg-rose-500/10 hover:text-rose-300 transition-all duration-200 cursor-pointer"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
