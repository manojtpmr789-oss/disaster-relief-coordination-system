import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { MapPin } from 'lucide-react';

function MapClickHandler({ onLocationSelect, position }) {
  useMapEvents({
    click(e) {
      onLocationSelect(e.latlng.lat, e.latlng.lng);
    },
  });

  return position ? <Marker position={[position.lat, position.lng]} /> : null;
}

export const LocationPicker = ({
  latitude,
  longitude,
  onLocationChange,
  height = '260px',
  defaultCenter = [34.0522, -118.2437],
}) => {
  const [selectedPos, setSelectedPos] = useState({
    lat: Number(latitude) || defaultCenter[0],
    lng: Number(longitude) || defaultCenter[1],
  });

  const handleSelect = (lat, lng) => {
    setSelectedPos({ lat, lng });
    onLocationChange(lat.toFixed(6), lng.toFixed(6));
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs text-slate-400">
        <span className="flex items-center gap-1.5 font-medium text-slate-300">
          <MapPin className="w-3.5 h-3.5 text-sky-400" />
          <span>Click map to place GPS coordinates</span>
        </span>
        <span className="font-mono text-[11px] text-sky-400">
          {latitude || selectedPos.lat.toFixed(4)}, {longitude || selectedPos.lng.toFixed(4)}
        </span>
      </div>

      <div
        className="rounded-xl overflow-hidden border border-slate-700/80 bg-slate-900"
        style={{ height }}
      >
        <MapContainer
          center={[selectedPos.lat, selectedPos.lng]}
          zoom={11}
          scrollWheelZoom={false}
          className="w-full h-full"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapClickHandler onLocationSelect={handleSelect} position={selectedPos} />
        </MapContainer>
      </div>
    </div>
  );
};

export default LocationPicker;
