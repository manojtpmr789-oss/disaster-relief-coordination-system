import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, CircleMarker, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { ShieldAlert, Tent, MapPin, Eye, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

// Fix default leaflet marker icon issue in webpack/vite bundles
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Custom AutoFitBounds component
function AutoFitBounds({ points }) {
  const map = useMap();
  useEffect(() => {
    if (points && points.length > 0) {
      const validPoints = points.filter((p) => p.lat && p.lng && (p.lat !== 0 || p.lng !== 0));
      if (validPoints.length > 0) {
        const bounds = L.latLngBounds(validPoints.map((p) => [p.lat, p.lng]));
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
      }
    }
  }, [points, map]);
  return null;
}

export const LeafletMap = ({
  disasters = [],
  camps = [],
  center = [34.0522, -118.2437],
  zoom = 11,
  height = '420px',
  interactive = true,
}) => {
  // Aggregate points for auto-fit bounds
  const mapPoints = [
    ...disasters
      .filter((d) => d.latitude && d.longitude)
      .map((d) => ({ lat: d.latitude, lng: d.longitude })),
    ...camps
      .filter((c) => c.latitude && c.longitude)
      .map((c) => ({ lat: c.latitude, lng: c.longitude })),
  ];

  return (
    <div
      className="relative w-full rounded-2xl overflow-hidden border border-slate-800 shadow-xl bg-slate-900 z-10"
      style={{ height }}
    >
      <MapContainer
        center={center}
        zoom={zoom}
        scrollWheelZoom={false}
        className="w-full h-full"
        style={{ background: '#090d16' }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {mapPoints.length > 1 && <AutoFitBounds points={mapPoints} />}

        {/* Disaster Circle Markers */}
        {disasters.map((disaster) => {
          const lat = disaster.latitude;
          const lng = disaster.longitude;
          if (!lat || !lng || (lat === 0 && lng === 0)) return null;

          const isCritical = disaster.severity === 'Critical';
          const isHigh = disaster.severity === 'High';
          const color = isCritical ? '#ef4444' : isHigh ? '#f97316' : '#eab308';

          return (
            <CircleMarker
              key={`disaster-${disaster._id}`}
              center={[lat, lng]}
              pathOptions={{
                color: color,
                fillColor: color,
                fillOpacity: 0.8,
                weight: 2,
              }}
              radius={isCritical ? 12 : 9}
            >
              <Popup className="disaster-popup">
                <div className="p-1 space-y-1.5 min-w-[200px] text-slate-900">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-rose-600 uppercase tracking-wider">
                    <span>🚨 {disaster.disasterType}</span>
                    <span className="px-1.5 py-0.2 rounded bg-rose-100 text-rose-700 text-[10px]">
                      {disaster.severity}
                    </span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 leading-tight">
                    {disaster.title}
                  </h4>
                  <p className="text-xs text-slate-600 line-clamp-2">
                    {disaster.description}
                  </p>
                  <div className="pt-1 flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-200">
                    <span>📍 {disaster.city}</span>
                    <span className="font-semibold">{disaster.status}</span>
                  </div>
                  <Link
                    to={`/disasters/${disaster._id}`}
                    className="mt-1.5 flex items-center justify-center gap-1 w-full py-1 rounded bg-slate-900 text-white text-[11px] font-bold hover:bg-slate-800 transition-colors"
                  >
                    <span>View Incident</span>
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                </div>
              </Popup>
            </CircleMarker>
          );
        })}

        {/* Relief Camp Circle Markers */}
        {camps.map((camp) => {
          const lat = camp.latitude;
          const lng = camp.longitude;
          if (!lat || !lng || (lat === 0 && lng === 0)) return null;

          const isFull = camp.status === 'Full' || camp.availableBeds === 0;
          const color = isFull ? '#64748b' : '#0284c7';

          return (
            <CircleMarker
              key={`camp-${camp._id}`}
              center={[lat, lng]}
              pathOptions={{
                color: color,
                fillColor: color,
                fillOpacity: 0.8,
                weight: 2,
              }}
              radius={10}
            >
              <Popup className="camp-popup">
                <div className="p-1 space-y-1.5 min-w-[200px] text-slate-900">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-sky-700 uppercase tracking-wider">
                    <span>⛺ Relief Shelter</span>
                    <span
                      className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                        isFull ? 'bg-slate-200 text-slate-700' : 'bg-sky-100 text-sky-800'
                      }`}
                    >
                      {camp.status}
                    </span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 leading-tight">
                    {camp.name}
                  </h4>
                  <div className="text-xs text-slate-600">
                    <p>
                      <strong>Free Beds:</strong> {camp.availableBeds} / {camp.capacity}
                    </p>
                    <p>
                      <strong>Location:</strong> {camp.location}, {camp.city}
                    </p>
                    <p>
                      <strong>Contact:</strong> {camp.contactNumber}
                    </p>
                  </div>
                  <Link
                    to={`/camps/${camp._id}`}
                    className="mt-1.5 flex items-center justify-center gap-1 w-full py-1 rounded bg-sky-600 text-white text-[11px] font-bold hover:bg-sky-500 transition-colors"
                  >
                    <span>Shelter Details</span>
                    <ExternalLink className="w-3 h-3" />
                  </Link>
                </div>
              </Popup>
            </CircleMarker>
          );
        })}
      </MapContainer>

      {/* Map Legend Overlay */}
      <div className="absolute bottom-3 right-3 z-20 bg-slate-950/90 border border-slate-800 rounded-xl p-2.5 shadow-lg backdrop-blur-md text-[11px] text-slate-300 space-y-1">
        <div className="font-bold text-white mb-1 uppercase tracking-wider text-[10px]">
          Map Legend
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-rose-500 inline-block shadow-sm" />
          <span>Active Disaster Incident</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-sky-500 inline-block shadow-sm" />
          <span>Relief Camp / Shelter</span>
        </div>
      </div>
    </div>
  );
};

export default LeafletMap;
