import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { notificationService } from '../services/notificationService';
import {
  Bell,
  Menu,
  Shield,
  LogOut,
  User as UserIcon,
  ChevronDown,
} from 'lucide-react';

const roleColorMap = {
  admin: {
    bg: 'bg-rose-500/10',
    border: 'border-rose-500/30',
    text: 'text-rose-400',
    label: 'Admin',
  },
  volunteer: {
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/30',
    text: 'text-emerald-400',
    label: 'Volunteer',
  },
  affected_user: {
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
    text: 'text-amber-400',
    label: 'Affected User',
  },
};

export const Navbar = ({ onToggleSidebar }) => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  const roleStyle = roleColorMap[currentUser?.role] || roleColorMap.affected_user;

  // Fetch live unread notification count
  useEffect(() => {
    if (!currentUser) return;
    const fetchUnread = () => {
      notificationService
        .getNotifications()
        .then((res) => {
          if (res.data?.success) setUnreadCount(res.data.unreadCount || 0);
        })
        .catch(() => {});
    };
    fetchUnread();
    const interval = setInterval(fetchUnread, 30000);
    return () => clearInterval(interval);
  }, [currentUser]);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-800 bg-slate-900/90 px-4 sm:px-6 backdrop-blur-md">
      {/* Left side: Mobile Hamburger + Brand Name */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white lg:hidden"
          aria-label="Toggle Sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-blue-600 shadow-md text-white font-bold">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold tracking-tight text-white text-sm sm:text-base">
              Disaster Relief Coordination System
            </span>
          </div>
        </div>
      </div>

      {/* Right side: Notifications + User Menu */}
      <div className="flex items-center gap-3 sm:gap-4">
        {/* Notifications Link with Live Badge */}
        <Link
          to="/notifications"
          className="relative p-2 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          title="View Notifications"
        >
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center px-1 ring-2 ring-slate-900">
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </Link>

        {/* User Profile Pill & Dropdown */}
        <div className="relative">
          <button
            onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
            className="flex items-center gap-2.5 p-1.5 sm:px-3 sm:py-1.5 rounded-xl hover:bg-slate-800 border border-transparent hover:border-slate-700 transition-all text-left cursor-pointer"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white font-bold text-xs uppercase shadow-sm">
              {currentUser?.name ? currentUser.name.charAt(0) : 'U'}
            </div>
            <div className="hidden sm:block">
              <div className="text-xs font-semibold text-white truncate max-w-[120px]">
                {currentUser?.name || 'User'}
              </div>
              <div className="flex items-center gap-1">
                <span
                  className={`inline-block px-1.5 py-0.2 rounded text-[10px] font-semibold border ${roleStyle.bg} ${roleStyle.border} ${roleStyle.text}`}
                >
                  {roleStyle.label}
                </span>
              </div>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-400 hidden sm:block" />
          </button>

          {profileDropdownOpen && (
            <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="p-3 border-b border-slate-800">
                <p className="text-xs font-bold text-white truncate">
                  {currentUser?.name}
                </p>
                <p className="text-[11px] text-slate-400 truncate mt-0.5">
                  {currentUser?.email}
                </p>
                <span
                  className={`mt-2 inline-block px-2 py-0.5 rounded text-[10px] font-semibold border ${roleStyle.bg} ${roleStyle.border} ${roleStyle.text}`}
                >
                  {roleStyle.label}
                </span>
              </div>

              <div className="py-1">
                <Link
                  to="/profile"
                  onClick={() => setProfileDropdownOpen(false)}
                  className="flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
                >
                  <UserIcon className="w-4 h-4 text-blue-400" />
                  <span>My Profile</span>
                </Link>

                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors mt-1 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
