import React from 'react';

const colorThemes = {
  blue: {
    bg: 'bg-sky-500/10',
    border: 'border-sky-500/20',
    text: 'text-sky-400',
    glow: 'group-hover:border-sky-500/40',
    accentBg: 'bg-sky-500',
  },
  emerald: {
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    text: 'text-emerald-400',
    glow: 'group-hover:border-emerald-500/40',
    accentBg: 'bg-emerald-500',
  },
  amber: {
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/20',
    text: 'text-amber-400',
    glow: 'group-hover:border-amber-500/40',
    accentBg: 'bg-amber-500',
  },
  rose: {
    bg: 'bg-rose-500/10',
    border: 'border-rose-500/20',
    text: 'text-rose-400',
    glow: 'group-hover:border-rose-500/40',
    accentBg: 'bg-rose-500',
  },
  violet: {
    bg: 'bg-violet-500/10',
    border: 'border-violet-500/20',
    text: 'text-violet-400',
    glow: 'group-hover:border-violet-500/40',
    accentBg: 'bg-violet-500',
  },
};

export const StatCard = ({
  title,
  value,
  icon: Icon,
  color = 'blue',
  badge,
  badgeType = 'live',
  description,
}) => {
  const theme = colorThemes[color] || colorThemes.blue;

  return (
    <div
      className={`group relative overflow-hidden rounded-2xl bg-slate-900/80 border ${theme.border} ${theme.glow} p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-black/40 backdrop-blur-md`}
    >
      {/* Top accent border line */}
      <div className={`absolute top-0 left-0 right-0 h-1 ${theme.accentBg} opacity-80`} />

      <div className="flex items-start justify-between gap-4">
        <div className="space-y-1.5">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            {title}
          </span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white tracking-tight">
              {value}
            </span>
          </div>
        </div>

        {Icon && (
          <div
            className={`p-3 rounded-xl ${theme.bg} ${theme.border} border ${theme.text} transition-transform duration-300 group-hover:scale-110`}
          >
            <Icon className="w-6 h-6" />
          </div>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between pt-3 border-t border-slate-800/60">
        {description && (
          <span className="text-xs text-slate-400 truncate max-w-[170px]">
            {description}
          </span>
        )}
        {badge && (
          <span
            className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium ${
              badgeType === 'live'
                ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                : 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
            }`}
          >
            {badgeType === 'live' && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse" />
            )}
            {badge}
          </span>
        )}
      </div>
    </div>
  );
};

export default StatCard;
