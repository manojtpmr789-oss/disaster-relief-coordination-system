import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, Plus, Search, RefreshCw, Trash2, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { resourceService } from '../services/resourceService';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const STATUS_STYLES = {
  Available: 'bg-emerald-500/20 text-emerald-400',
  'Low Stock': 'bg-orange-500/20 text-orange-400',
  'Out of Stock': 'bg-rose-500/20 text-rose-400',
};

const CATEGORY_COLORS = {
  Food: 'text-yellow-400',
  Water: 'text-sky-400',
  Medicine: 'text-rose-400',
  'Shelter Equipment': 'text-teal-400',
  'Emergency Equipment': 'text-orange-400',
  Clothing: 'text-violet-400',
};

const Resources = () => {
  const { user } = useAuth();
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ search: '', category: 'all', status: 'all' });
  const [showAdd, setShowAdd] = useState(false);
  const [addForm, setAddForm] = useState({ name: '', category: 'Food', quantity: 0, unit: 'units', location: '', city: '', minimumStock: 10, donatedBy: '' });

  const isAdmin = user?.role === 'admin';

  const fetchResources = async () => {
    try {
      setLoading(true);
      const res = await resourceService.getResources(filters);
      if (res.data?.success) setResources(res.data.resources);
    } catch { toast.error('Failed to load resources'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchResources(); }, [filters]);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this resource?')) return;
    try {
      await resourceService.deleteResource(id);
      toast.success('Resource deleted');
      fetchResources();
    } catch { toast.error('Delete failed'); }
  };

  const handleAddSubmit = async (e) => {
    e.preventDefault();
    try {
      await resourceService.createResource(addForm);
      toast.success('Resource added!');
      setShowAdd(false);
      setAddForm({ name: '', category: 'Food', quantity: 0, unit: 'units', location: '', city: '', minimumStock: 10, donatedBy: '' });
      fetchResources();
    } catch { toast.error('Failed to add resource'); }
  };

  const inputCls = 'w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Resource Inventory</h1>
          <p className="text-sm text-slate-400 mt-1">{resources.length} items in stock</p>
        </div>
        {isAdmin && (
          <button onClick={() => setShowAdd(!showAdd)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-600 text-white text-sm font-bold transition-all shadow-lg shadow-teal-500/20">
            <Plus className="w-4 h-4" /> Add Resource
          </button>
        )}
      </div>

      {/* Add Resource Form */}
      {showAdd && isAdmin && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
          <h2 className="font-bold text-white mb-4 flex items-center gap-2"><Package className="w-5 h-5 text-teal-400" /> New Resource</h2>
          <form onSubmit={handleAddSubmit} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            <input required placeholder="Resource Name *" value={addForm.name} onChange={e => setAddForm(f => ({...f, name: e.target.value}))} className={inputCls} />
            <select value={addForm.category} onChange={e => setAddForm(f => ({...f, category: e.target.value}))} className={inputCls}>
              {['Food','Water','Medicine','Shelter Equipment','Emergency Equipment','Clothing','Other'].map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <input type="number" min="0" placeholder="Quantity" value={addForm.quantity} onChange={e => setAddForm(f => ({...f, quantity: e.target.value}))} className={inputCls} />
            <input placeholder="Unit (e.g. packs, jugs)" value={addForm.unit} onChange={e => setAddForm(f => ({...f, unit: e.target.value}))} className={inputCls} />
            <input placeholder="Location / Depot" value={addForm.location} onChange={e => setAddForm(f => ({...f, location: e.target.value}))} className={inputCls} />
            <input required placeholder="City *" value={addForm.city} onChange={e => setAddForm(f => ({...f, city: e.target.value}))} className={inputCls} />
            <input type="number" min="0" placeholder="Minimum Stock Threshold" value={addForm.minimumStock} onChange={e => setAddForm(f => ({...f, minimumStock: e.target.value}))} className={inputCls} />
            <input placeholder="Donated By" value={addForm.donatedBy} onChange={e => setAddForm(f => ({...f, donatedBy: e.target.value}))} className={inputCls} />
            <div className="flex gap-2">
              <button type="submit" className="flex-1 py-2 rounded-xl bg-teal-500 hover:bg-teal-600 text-white text-sm font-bold transition-all">Add</button>
              <button type="button" onClick={() => setShowAdd(false)} className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold transition-all">Cancel</button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input type="text" placeholder="Search resources…" value={filters.search}
            onChange={e => setFilters(f => ({...f, search: e.target.value}))}
            className="w-full pl-9 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500" />
        </div>
        <select value={filters.category} onChange={e => setFilters(f => ({...f, category: e.target.value}))}
          className="w-full px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500">
          <option value="all">All Categories</option>
          {['Food','Water','Medicine','Shelter Equipment','Emergency Equipment','Clothing','Other'].map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <select value={filters.status} onChange={e => setFilters(f => ({...f, status: e.target.value}))}
          className="w-full px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500">
          <option value="all">All Stock Levels</option>
          {['Available','Low Stock','Out of Stock'].map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span className="text-sm">Loading inventory…</span>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-500 uppercase tracking-wider">
                  <th className="text-left px-5 py-3.5 font-medium">Resource Name</th>
                  <th className="text-left px-5 py-3.5 font-medium">Category</th>
                  <th className="text-left px-5 py-3.5 font-medium">Quantity</th>
                  <th className="text-left px-5 py-3.5 font-medium">Location</th>
                  <th className="text-left px-5 py-3.5 font-medium">Stock Status</th>
                  {isAdmin && <th className="text-left px-5 py-3.5 font-medium">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {resources.length === 0 ? (
                  <tr><td colSpan={6} className="text-center py-12 text-slate-500 text-sm">No resources found</td></tr>
                ) : resources.map(r => (
                  <tr key={r._id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="px-5 py-3.5">
                      <p className="font-semibold text-white text-xs">{r.name}</p>
                      {r.donatedBy && <p className="text-slate-500 text-[11px]">by {r.donatedBy}</p>}
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`text-xs font-semibold ${CATEGORY_COLORS[r.category] || 'text-slate-400'}`}>{r.category}</span>
                    </td>
                    <td className="px-5 py-3.5 text-white font-bold text-xs">{r.quantity} {r.unit}</td>
                    <td className="px-5 py-3.5 text-slate-400 text-xs">{r.city}</td>
                    <td className="px-5 py-3.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${STATUS_STYLES[r.status] || 'bg-slate-700 text-slate-400'}`}>
                        {r.status}
                      </span>
                    </td>
                    {isAdmin && (
                      <td className="px-5 py-3.5">
                        <button onClick={() => handleDelete(r._id)}
                          className="p-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 transition-all">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Resources;
