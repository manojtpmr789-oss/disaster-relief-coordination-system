import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import userService from '../services/userService';
import PageHeader from '../components/PageHeader';
import Modal from '../components/Modal';
import Loading from '../components/Loading';
import toast from 'react-hot-toast';
import {
  Users as UsersIcon,
  Search,
  Filter,
  Eye,
  Edit3,
  Trash2,
  AlertTriangle,
  RefreshCw,
  Loader2,
} from 'lucide-react';

const roleBadgeConfig = {
  admin: {
    bg: 'bg-rose-500/10',
    border: 'border-rose-500/30',
    text: 'text-rose-400',
    label: 'Admin',
  },
  volunteer: {
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/30',
    text: 'text-emerald-400',
    label: 'Volunteer',
  },
  affected_user: {
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
    text: 'text-amber-400',
    label: 'Affected User',
  },
};

export const Users = () => {
  const { currentUser } = useAuth();

  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');
  const [breakdown, setBreakdown] = useState(null);

  // Modals state
  const [viewingUser, setViewingUser] = useState(null);
  const [editingUser, setEditingUser] = useState(null);
  const [deletingUser, setDeletingUser] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);

  // Edit form state
  const [editFormData, setEditFormData] = useState({
    role: '',
    name: '',
    phone: '',
    city: '',
    address: '',
    availability: '',
  });

  const fetchUsers = useCallback(async () => {
    try {
      setLoading(true);
      const res = await userService.getAllUsers({
        search: searchQuery,
        role: selectedRole,
      });

      if (res.success) {
        setUsers(res.users || []);
        if (res.breakdown) setBreakdown(res.breakdown);
      }
    } catch (err) {
      toast.error(err.message || 'Failed to retrieve users list');
    } finally {
      setLoading(false);
    }
  }, [searchQuery, selectedRole]);

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchUsers();
    }, 300);
    return () => clearTimeout(timer);
  }, [fetchUsers]);

  // Open Edit Modal
  const handleOpenEdit = (user) => {
    setEditingUser(user);
    setEditFormData({
      role: user.role,
      name: user.name,
      phone: user.phone,
      city: user.city,
      address: user.address,
      availability: user.availability || 'available',
    });
  };

  // Submit Role & Details Edit
  const handleSaveEdit = async (e) => {
    e.preventDefault();
    if (!editingUser) return;

    try {
      setActionLoading(true);
      const res = await userService.updateUser(editingUser._id, editFormData);
      if (res.success) {
        toast.success(`User '${res.user.name}' updated successfully.`);
        setEditingUser(null);
        fetchUsers();
      }
    } catch (err) {
      toast.error(err.message || 'Failed to update user');
    } finally {
      setActionLoading(false);
    }
  };

  // Confirm Delete User
  const handleConfirmDelete = async () => {
    if (!deletingUser) return;

    try {
      setActionLoading(true);
      const res = await userService.deleteUser(deletingUser._id);
      if (res.success) {
        toast.success(`User '${deletingUser.name}' removed successfully.`);
        setDeletingUser(null);
        fetchUsers();
      }
    } catch (err) {
      toast.error(err.message || 'Failed to delete user');
    } finally {
      setActionLoading(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="User & Personnel Management"
        subtitle="Manage system roles, view contact details, and update volunteer clearance."
        icon={UsersIcon}
        badge="ADMIN CONSOLE"
        actions={
          <button
            onClick={fetchUsers}
            disabled={loading}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 transition-all disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Reload Directory</span>
          </button>
        }
      />

      {/* Role Stats Filter Pills */}
      {breakdown && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => setSelectedRole('all')}
            className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${selectedRole === 'all'
                ? 'bg-blue-600/15 border-blue-500/40 text-blue-300 shadow-sm'
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:bg-slate-800/60'
              }`}
          >
            <span className="text-[10px] font-bold uppercase tracking-wider block text-slate-400">
              Total Users
            </span>
            <span className="text-xl font-bold text-white mt-0.5 block">
              {breakdown.totalUsers}
            </span>
          </button>

          <button
            onClick={() => setSelectedRole('admin')}
            className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${selectedRole === 'admin'
                ? 'bg-rose-500/15 border-rose-500/40 text-rose-300 shadow-sm'
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:bg-slate-800/60'
              }`}
          >
            <span className="text-[10px] font-bold uppercase tracking-wider block text-rose-400">
              Administrators
            </span>
            <span className="text-xl font-bold text-white mt-0.5 block">
              {breakdown.totalAdmins}
            </span>
          </button>

          <button
            onClick={() => setSelectedRole('volunteer')}
            className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${selectedRole === 'volunteer'
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 shadow-sm'
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:bg-slate-800/60'
              }`}
          >
            <span className="text-[10px] font-bold uppercase tracking-wider block text-emerald-400">
              Volunteers
            </span>
            <span className="text-xl font-bold text-white mt-0.5 block">
              {breakdown.totalVolunteers}
            </span>
          </button>

          <button
            onClick={() => setSelectedRole('affected_user')}
            className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${selectedRole === 'affected_user'
                ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 shadow-sm'
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:bg-slate-800/60'
              }`}
          >
            <span className="text-[10px] font-bold uppercase tracking-wider block text-amber-400">
              Affected Users
            </span>
            <span className="text-xl font-bold text-white mt-0.5 block">
              {breakdown.totalAffected}
            </span>
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-900 border border-slate-800">
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, email, city, or phone..."
            className="w-full pl-10 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-all"
          />
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
          >
            <option value="all">All Roles</option>
            <option value="admin">Administrators</option>
            <option value="volunteer">Volunteers</option>
            <option value="affected_user">Affected Users</option>
          </select>
        </div>
      </div>

      {/* Users Table Card */}
      <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden shadow-sm">
        {loading ? (
          <Loading message="Loading users directory..." />
        ) : users.length === 0 ? (
          <div className="p-12 text-center space-y-2">
            <UsersIcon className="w-10 h-10 text-slate-600 mx-auto" />
            <h4 className="text-sm font-bold text-slate-300">No users found</h4>
            <p className="text-xs text-slate-500">
              Try adjusting your search query or role filter.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="px-4 py-3 font-semibold">User / Name</th>
                  <th className="px-4 py-3 font-semibold">Email</th>
                  <th className="px-4 py-3 font-semibold">Phone</th>
                  <th className="px-4 py-3 font-semibold">City</th>
                  <th className="px-4 py-3 font-semibold">Role</th>
                  <th className="px-4 py-3 font-semibold">Joined</th>
                  <th className="px-4 py-3 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {users.map((user) => {
                  const roleStyle =
                    roleBadgeConfig[user.role] || roleBadgeConfig.affected_user;
                  const isCurrentAdmin = user._id === currentUser?._id;

                  return (
                    <tr
                      key={user._id}
                      className="hover:bg-slate-800/40 transition-colors group"
                    >
                      {/* Name & Avatar */}
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-lg bg-blue-600/30 border border-blue-500/30 text-blue-300 font-bold text-xs flex items-center justify-center">
                            {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
                          </div>
                          <div>
                            <span className="font-semibold text-white block">
                              {user.name}
                            </span>
                            {isCurrentAdmin && (
                              <span className="text-[10px] text-rose-400 font-medium">
                                (You)
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Email */}
                      <td className="px-4 py-3 whitespace-nowrap text-slate-300 font-mono text-[11px]">
                        {user.email}
                      </td>

                      {/* Phone */}
                      <td className="px-4 py-3 whitespace-nowrap text-slate-300">
                        {user.phone || '—'}
                      </td>

                      {/* City */}
                      <td className="px-4 py-3 whitespace-nowrap text-slate-300">
                        {user.city || '—'}
                      </td>

                      {/* Role Badge */}
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${roleStyle.bg} ${roleStyle.border} ${roleStyle.text}`}
                        >
                          {roleStyle.label}
                        </span>
                      </td>

                      {/* Created Date */}
                      <td className="px-4 py-3 whitespace-nowrap text-slate-400 text-[11px]">
                        {formatDate(user.createdAt)}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setViewingUser(user)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                            title="View Full Profile"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => handleOpenEdit(user)}
                            className="p-1.5 rounded-lg bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
                            title="Edit Role & Details"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => setDeletingUser(user)}
                            disabled={isCurrentAdmin}
                            className={`p-1.5 rounded-lg transition-colors ${isCurrentAdmin
                                ? 'bg-slate-800/40 text-slate-600 cursor-not-allowed'
                                : 'bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-300 cursor-pointer'
                              }`}
                            title={
                              isCurrentAdmin
                                ? 'Cannot delete own account'
                                : 'Delete User Account'
                            }
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* VIEW USER DETAILS MODAL */}
      <Modal
        isOpen={!!viewingUser}
        onClose={() => setViewingUser(null)}
        title="User Details"
        subtitle={`Directory record for ${viewingUser?.name}`}
      >
        {viewingUser && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-800 border border-slate-700">
              <div className="w-10 h-10 rounded-xl bg-blue-600 text-white font-bold text-base flex items-center justify-center">
                {viewingUser.name ? viewingUser.name.charAt(0) : 'U'}
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">{viewingUser.name}</h4>
                <p className="text-slate-400 font-mono text-[11px]">{viewingUser.email}</p>
                <span
                  className={`inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-semibold border ${roleBadgeConfig[viewingUser.role]?.bg
                    } ${roleBadgeConfig[viewingUser.role]?.border} ${roleBadgeConfig[viewingUser.role]?.text
                    }`}
                >
                  {roleBadgeConfig[viewingUser.role]?.label}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Phone Number</span>
                <span className="font-semibold text-white">{viewingUser.phone || 'N/A'}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Assigned City</span>
                <span className="font-semibold text-white">{viewingUser.city || 'N/A'}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Availability</span>
                <span className="font-semibold text-emerald-400 capitalize">
                  {viewingUser.availability || 'Available'}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-800">
                <span className="text-slate-400 block mb-0.5">Registered On</span>
                <span className="font-semibold text-white">{formatDate(viewingUser.createdAt)}</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-800">
              <span className="text-slate-400 block mb-0.5">Physical Address / Sector</span>
              <span className="font-semibold text-white">{viewingUser.address || 'N/A'}</span>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setViewingUser(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition-colors cursor-pointer"
              >
                Close View
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* EDIT ROLE & DETAILS MODAL */}
      <Modal
        isOpen={!!editingUser}
        onClose={() => setEditingUser(null)}
        title="Edit User Role & Details"
        subtitle={`Update record for ${editingUser?.name}`}
      >
        {editingUser && (
          <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-300 mb-1">
                System Role *
              </label>
              <select
                value={editFormData.role}
                onChange={(e) =>
                  setEditFormData({ ...editFormData, role: e.target.value })
                }
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:ring-1 focus:ring-blue-500"
              >
                <option value="admin">Administrator</option>
                <option value="volunteer">Volunteer</option>
                <option value="affected_user">Affected User</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-300 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={editFormData.name}
                  onChange={(e) =>
                    setEditFormData({ ...editFormData, name: e.target.value })
                  }
                  required
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-300 mb-1">
                  Phone
                </label>
                <input
                  type="text"
                  value={editFormData.phone}
                  onChange={(e) =>
                    setEditFormData({ ...editFormData, phone: e.target.value })
                  }
                  required
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-300 mb-1">
                  City
                </label>
                <input
                  type="text"
                  value={editFormData.city}
                  onChange={(e) =>
                    setEditFormData({ ...editFormData, city: e.target.value })
                  }
                  required
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-300 mb-1">
                  Availability
                </label>
                <select
                  value={editFormData.availability}
                  onChange={(e) =>
                    setEditFormData({ ...editFormData, availability: e.target.value })
                  }
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
                >
                  <option value="available">Available</option>
                  <option value="busy">Busy</option>
                  <option value="unavailable">Unavailable</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-slate-300 mb-1">
                Address
              </label>
              <input
                type="text"
                value={editFormData.address}
                onChange={(e) =>
                  setEditFormData({ ...editFormData, address: e.target.value })
                }
                required
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={actionLoading}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-xs font-semibold text-white transition-all disabled:opacity-50 cursor-pointer shadow-sm"
              >
                {actionLoading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <span>Save Changes</span>
                )}
              </button>
            </div>
          </form>
        )}
      </Modal>

      {/* DELETE CONFIRMATION MODAL */}
      <Modal
        isOpen={!!deletingUser}
        onClose={() => setDeletingUser(null)}
        title="Confirm User Deletion"
        subtitle="Security verification"
      >
        {deletingUser && (
          <div className="space-y-4 text-xs">
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 shrink-0 text-rose-400 mt-0.5" />
              <div>
                <p className="font-bold text-sm text-white">
                  Permanently remove account?
                </p>
                <p className="mt-1 text-slate-300 leading-relaxed">
                  Are you sure you want to delete user{' '}
                  <strong className="text-white">{deletingUser.name}</strong> (
                  <span className="font-mono text-slate-300">{deletingUser.email}</span>)?
                  This action will permanently delete this account from MongoDB and cannot be undone.
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeletingUser(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={actionLoading}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-semibold text-white transition-all disabled:opacity-50 cursor-pointer shadow-sm"
              >
                {actionLoading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete User</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default Users;
