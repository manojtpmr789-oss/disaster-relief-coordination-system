import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ShieldAlert, ArrowLeft, Loader2, Save, MapPin, Compass } from 'lucide-react';
import { disasterService } from '../services/disasterService';
import toast from 'react-hot-toast';

const DISASTER_TYPES = [
  'Flood',
  'Earthquake',
  'Cyclone',
  'Landslide',
  'Fire',
  'Tsunami',
  'Drought',
  'Other',
];

const SEVERITIES = ['Low', 'Medium', 'High', 'Critical'];

const inputCls =
  'w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-colors';

const CreateDisaster = () => {
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  const [form, setForm] = useState({
    title: '',
    disasterType: 'Flood',
    description: '',
    location: '',
    city: '',
    severity: 'High',
    latitude: '',
    longitude: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    // Clear validation error on change
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!form.title.trim()) {
      newErrors.title = 'Title is required';
    }
    if (!form.disasterType) {
      newErrors.disasterType = 'Disaster type is required';
    }
    if (!form.description.trim()) {
      newErrors.description = 'Description is required';
    }
    if (!form.location.trim()) {
      newErrors.location = 'Specific location is required';
    }
    if (!form.city.trim()) {
      newErrors.city = 'City is required';
    }
    if (!form.severity) {
      newErrors.severity = 'Severity level is required';
    }

    if (form.latitude !== '' && form.latitude !== null) {
      const lat = Number(form.latitude);
      if (isNaN(lat) || lat < -90 || lat > 90) {
        newErrors.latitude = 'Latitude must be between -90 and 90';
      }
    }

    if (form.longitude !== '' && form.longitude !== null) {
      const lng = Number(form.longitude);
      if (isNaN(lng) || lng < -180 || lng > 180) {
        newErrors.longitude = 'Longitude must be between -180 and 180';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      toast.error('Please fill all required fields correctly');
      return;
    }

    try {
      setSubmitting(true);

      const payload = {
        title: form.title.trim(),
        disasterType: form.disasterType,
        description: form.description.trim(),
        location: form.location.trim(),
        city: form.city.trim(),
        severity: form.severity,
      };

      if (form.latitude !== '' && form.latitude !== null) {
        payload.latitude = Number(form.latitude);
      }
      if (form.longitude !== '' && form.longitude !== null) {
        payload.longitude = Number(form.longitude);
      }

      const res = await disasterService.createDisaster(payload);

      if (res && (res.success || res.disaster || res.data?.success)) {
        toast.success('Disaster report submitted successfully.');
        setForm({
          title: '',
          disasterType: 'Flood',
          description: '',
          location: '',
          city: '',
          severity: 'High',
          latitude: '',
          longitude: '',
        });
        navigate('/disasters');
      } else {
        toast.error(res?.message || 'Unable to submit disaster report. Please try again.');
      }
    } catch (err) {
      const msg = err.message || 'Unable to submit disaster report. Please try again.';
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Link
          to="/disasters"
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">Report a Disaster</h1>
          <p className="text-xs text-slate-400 mt-0.5">Submit an incident report for emergency response teams</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Basic Information */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 space-y-4">
          <h2 className="font-bold text-white text-sm flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400" /> Incident Information
          </h2>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-300">
              Incident Title <span className="text-rose-400">*</span>
            </label>
            <input
              name="title"
              value={form.title}
              onChange={handleChange}
              placeholder="e.g. Flash Flood near Riverside Sector 4"
              className={inputCls}
            />
            {errors.title && <p className="text-[11px] text-rose-400 font-medium">{errors.title}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">
                Disaster Type <span className="text-rose-400">*</span>
              </label>
              <select
                name="disasterType"
                value={form.disasterType}
                onChange={handleChange}
                className={inputCls}
              >
                {DISASTER_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
              {errors.disasterType && (
                <p className="text-[11px] text-rose-400 font-medium">{errors.disasterType}</p>
              )}
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">
                Severity Level <span className="text-rose-400">*</span>
              </label>
              <select
                name="severity"
                value={form.severity}
                onChange={handleChange}
                className={inputCls}
              >
                {SEVERITIES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
              {errors.severity && (
                <p className="text-[11px] text-rose-400 font-medium">{errors.severity}</p>
              )}
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-300">
              Description <span className="text-rose-400">*</span>
            </label>
            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              rows={4}
              placeholder="Describe the incident — affected areas, observed damages, and urgent needs..."
              className={inputCls + ' resize-none'}
            />
            {errors.description && (
              <p className="text-[11px] text-rose-400 font-medium">{errors.description}</p>
            )}
          </div>
        </div>

        {/* Location Details */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 space-y-4">
          <h2 className="font-bold text-white text-sm flex items-center gap-2">
            <MapPin className="w-4 h-4 text-blue-400" /> Location Details
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">
                Specific Location / Address <span className="text-rose-400">*</span>
              </label>
              <input
                name="location"
                value={form.location}
                onChange={handleChange}
                placeholder="e.g. Main Bridge, East Canal Road"
                className={inputCls}
              />
              {errors.location && (
                <p className="text-[11px] text-rose-400 font-medium">{errors.location}</p>
              )}
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">
                City / Region <span className="text-rose-400">*</span>
              </label>
              <input
                name="city"
                value={form.city}
                onChange={handleChange}
                placeholder="e.g. Riverdale"
                className={inputCls}
              />
              {errors.city && (
                <p className="text-[11px] text-rose-400 font-medium">{errors.city}</p>
              )}
            </div>
          </div>

          {/* Optional GPS Coordinates */}
          <div className="pt-2 border-t border-slate-800">
            <p className="text-xs font-semibold text-slate-400 flex items-center gap-1.5 mb-3">
              <Compass className="w-3.5 h-3.5 text-slate-400" /> Coordinates (Optional)
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-xs text-slate-400">Latitude</label>
                <input
                  type="number"
                  step="any"
                  name="latitude"
                  value={form.latitude}
                  onChange={handleChange}
                  placeholder="e.g. 19.0760"
                  className={inputCls}
                />
                {errors.latitude && (
                  <p className="text-[11px] text-rose-400 font-medium">{errors.latitude}</p>
                )}
              </div>
              <div className="space-y-1.5">
                <label className="block text-xs text-slate-400">Longitude</label>
                <input
                  type="number"
                  step="any"
                  name="longitude"
                  value={form.longitude}
                  onChange={handleChange}
                  placeholder="e.g. 72.8777"
                  className={inputCls}
                />
                {errors.longitude && (
                  <p className="text-[11px] text-rose-400 font-medium">{errors.longitude}</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Submit Actions */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <Link
            to="/disasters"
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition-all"
          >
            Cancel
          </Link>
          <button
            type="submit"
            disabled={submitting}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white text-xs font-semibold transition-all shadow-sm cursor-pointer disabled:cursor-not-allowed"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Submitting...</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Submit Report</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateDisaster;
