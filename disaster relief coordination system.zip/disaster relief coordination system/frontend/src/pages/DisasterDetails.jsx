import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ShieldAlert,
  ArrowLeft,
  MapPin,
  User,
  Trash2,
  RefreshCw,
  Calendar,
  Compass,
  CheckCircle,
} from 'lucide-react';
import { disasterService } from '../services/disasterService';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const SEVERITY_COLORS = {
  Critical: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
  High: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  Medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  Low: 'bg-green-500/20 text-green-400 border-green-500/30',
};

const STATUS_COLORS = {
  Active: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
  Verified: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
  Resolved: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  Pending: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
};

const DisasterDetails = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [disaster, setDisaster] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updatingStatus, setUpdatingStatus] = useState(false);

  const isAdmin = user?.role === 'admin';
  const isVolunteer = user?.role === 'volunteer';
  const isReporter =
    user &&
    disaster &&
    disaster.reportedBy &&
    (disaster.reportedBy._id === user._id || disaster.reportedBy === user._id);

  const canEditStatus = isAdmin || isVolunteer;
  const canDelete = isAdmin || isReporter;

  useEffect(() => {
    setLoading(true);
    disasterService
      .getDisasterById(id)
      .then((res) => {
        const item = res?.disaster || res?.data?.disaster || (res?.success ? res : null);
        if (item) {
          setDisaster(item);
        } else {
          setDisaster(null);
        }
      })
      .catch((err) => {
        toast.error(err.message || 'Failed to load disaster details');
      })
      .finally(() => setLoading(false));
  }, [id]);

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to permanently delete this disaster report?')) return;
    try {
      await disasterService.deleteDisaster(id);
      toast.success('Disaster report deleted successfully.');
      navigate('/disasters');
    } catch (err) {
      toast.error(err.message || 'Failed to delete disaster report');
    }
  };

  const handleStatusChange = async (newStatus) => {
    try {
      setUpdatingStatus(true);
      const res = await disasterService.updateDisaster(id, { status: newStatus });
      const updated = res?.disaster || res?.data?.disaster;
      if (updated) {
        setDisaster(updated);
        toast.success(`Status updated to ${newStatus}`);
      } else {
        setDisaster((prev) => ({ ...prev, status: newStatus }));
        toast.success(`Status updated to ${newStatus}`);
      }
    } catch (err) {
      toast.error(err.message || 'Failed to update status');
    } finally {
      setUpdatingStatus(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-56 gap-3 text-slate-400">
        <RefreshCw className="w-5 h-5 animate-spin text-blue-400" />
        <span className="text-xs sm:text-sm">Loading incident details from MongoDB...</span>
      </div>
    );
  }

  if (!disaster) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center text-slate-400 max-w-xl mx-auto">
        <ShieldAlert className="w-12 h-12 mx-auto mb-3 text-slate-600" />
        <h2 className="text-base font-bold text-white mb-1">Disaster Report Not Found</h2>
        <p className="text-xs text-slate-400 mb-4">
          The requested disaster record does not exist or has been removed.
        </p>
        <Link
          to="/disasters"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Disaster Reports</span>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Back button + Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link
            to="/disasters"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight line-clamp-1">
              {disaster.title}
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Incident ID: <span className="font-mono text-slate-300">{disaster._id}</span>
            </p>
          </div>
        </div>

        {canDelete && (
          <button
            onClick={handleDelete}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold border border-rose-500/20 transition-all cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span className="hidden sm:inline">Delete Report</span>
          </button>
        )}
      </div>

      {/* Main Incident Details Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 space-y-6">
        {/* Badges & Status Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div className="flex items-center gap-2 flex-wrap">
            <span
              className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                SEVERITY_COLORS[disaster.severity] || 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {disaster.severity} Severity
            </span>
            <span
              className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                STATUS_COLORS[disaster.status] || 'bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              Status: {disaster.status}
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
              {disaster.disasterType}
            </span>
          </div>

          {canEditStatus && (
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs text-slate-400 mr-1 font-medium">Update Status:</span>
              {['Pending', 'Active', 'Verified', 'Resolved'].map((s) => (
                <button
                  key={s}
                  onClick={() => handleStatusChange(s)}
                  disabled={disaster.status === s || updatingStatus}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer disabled:cursor-not-allowed ${
                    disaster.status === s
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white disabled:opacity-50'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Description */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Incident Description
          </h3>
          <p className="text-slate-200 text-xs sm:text-sm leading-relaxed whitespace-pre-line bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
            {disaster.description}
          </p>
        </div>

        {/* Key Metadata Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
          <div className="bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl space-y-1">
            <span className="text-[11px] text-slate-400 flex items-center gap-1.5 font-medium">
              <MapPin className="w-3.5 h-3.5 text-blue-400" /> Location
            </span>
            <p className="text-xs font-semibold text-white truncate">{disaster.location}</p>
            <p className="text-[11px] text-slate-400">{disaster.city}</p>
          </div>

          <div className="bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl space-y-1">
            <span className="text-[11px] text-slate-400 flex items-center gap-1.5 font-medium">
              <Calendar className="w-3.5 h-3.5 text-violet-400" /> Date Reported
            </span>
            <p className="text-xs font-semibold text-white">
              {new Date(disaster.createdAt).toLocaleDateString()}
            </p>
            <p className="text-[11px] text-slate-400">
              {new Date(disaster.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>

          <div className="bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl space-y-1">
            <span className="text-[11px] text-slate-400 flex items-center gap-1.5 font-medium">
              <User className="w-3.5 h-3.5 text-emerald-400" /> Reported By
            </span>
            <p className="text-xs font-semibold text-white truncate">
              {disaster.reportedBy?.name || 'Community Member'}
            </p>
            <p className="text-[11px] text-slate-400 truncate">
              {disaster.reportedBy?.email || 'N/A'}
            </p>
          </div>

          <div className="bg-slate-800/40 border border-slate-800 p-3.5 rounded-xl space-y-1">
            <span className="text-[11px] text-slate-400 flex items-center gap-1.5 font-medium">
              <Compass className="w-3.5 h-3.5 text-amber-400" /> Coordinates
            </span>
            <p className="text-xs font-semibold text-white">
              {disaster.latitude != null && disaster.longitude != null
                ? `${disaster.latitude.toFixed(4)}, ${disaster.longitude.toFixed(4)}`
                : 'Not provided'}
            </p>
            <p className="text-[11px] text-slate-400">GPS Position</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DisasterDetails;
