import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldX, ArrowLeft, ShieldAlert } from 'lucide-react';

export const Unauthorized = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 px-4 py-12 relative overflow-hidden">
      <div className="w-full max-w-md text-center z-10 space-y-6">
        <div className="inline-flex items-center justify-center p-5 rounded-3xl bg-rose-500/10 border border-rose-500/30 text-rose-400 shadow-2xl shadow-rose-500/10">
          <ShieldX className="w-16 h-16 animate-pulse" />
        </div>

        <div className="space-y-2">
          <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-500/10 text-rose-400 border border-rose-500/30">
            HTTP 403 Forbidden
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Clearance Level Insufficient
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm mx-auto">
            You do not possess the required administrative clearance to access this incident command console route.
          </p>
        </div>

        <div className="pt-2">
          <Link
            to="/dashboard"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-all shadow-md"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Safe Dashboard</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Unauthorized;
