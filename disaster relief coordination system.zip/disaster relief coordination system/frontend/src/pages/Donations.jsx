import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { HandCoins, Plus, Search, Eye, Trash2, RefreshCw, DollarSign } from 'lucide-react';
import { donationService } from '../services/donationService';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const STATUS_STYLES = {
  Pending: 'bg-yellow-500/20 text-yellow-400',
  Received: 'bg-emerald-500/20 text-emerald-400',
  Distributed: 'bg-sky-500/20 text-sky-400',
  Cancelled: 'bg-rose-500/20 text-rose-400',
};

const Donations = () => {
  const { user } = useAuth();
  const [donations, setDonations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ search: '', type: 'all', status: 'all' });
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ donationType: 'Money', amount: '', itemName: '', quantity: '', description: '' });

  const isAdmin = user?.role === 'admin';
  const isDonor = user?.role === 'donor';

  const fetchDonations = async () => {
    try {
      setLoading(true);
      const params = { ...filters };
      if (isDonor) params.myDonations = true;
      const res = await donationService.getDonations(params);
      if (res.data?.success) setDonations(res.data.donations);
    } catch { toast.error('Failed to load donations'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchDonations(); }, [filters]);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this donation record?')) return;
    try {
      await donationService.deleteDonation(id);
      toast.success('Donation deleted');
      fetchDonations();
    } catch { toast.error('Delete failed'); }
  };

  const handleStatusChange = async (id, status) => {
    try {
      const res = await donationService.updateDonation(id, { status });
      if (res.data?.success) {
        setDonations(ds => ds.map(d => d._id === id ? { ...d, status } : d));
        toast.success(`Donation marked as ${status}`);
      }
    } catch { toast.error('Update failed'); }
  };

  const handleCreateSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await donationService.createDonation(form);
      if (res.data?.success) {
        toast.success('Donation submitted!');
        setShowCreate(false);
        setForm({ donationType: 'Money', amount: '', itemName: '', quantity: '', description: '' });
        fetchDonations();
      }
    } catch { toast.error('Failed to submit donation'); }
  };

  const inputCls = 'w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">
            {isDonor ? 'My Donations' : 'Donations'}
          </h1>
          <p className="text-sm text-slate-400 mt-1">{donations.length} donation{donations.length !== 1 ? 's' : ''} recorded</p>
        </div>
        {isDonor && (
          <button onClick={() => setShowCreate(!showCreate)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-bold transition-all shadow-lg shadow-emerald-500/20">
            <Plus className="w-4 h-4" /> Make Donation
          </button>
        )}
      </div>

      {/* Create Donation Form */}
      {showCreate && isDonor && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
          <h2 className="font-bold text-white mb-4 flex items-center gap-2">
            <HandCoins className="w-5 h-5 text-emerald-400" /> New Donation
          </h2>
          <form onSubmit={handleCreateSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <select value={form.donationType} onChange={e => setForm(f => ({...f, donationType: e.target.value}))} className={inputCls}>
              {['Money','Food','Clothing','Medicine','Equipment','Other'].map(t => <option key={t} value={t}>{t}</option>)}
            </select>
            {form.donationType === 'Money' ? (
              <input type="number" min="1" required placeholder="Amount (USD) *" value={form.amount} onChange={e => setForm(f => ({...f, amount: e.target.value}))} className={inputCls} />
            ) : (
              <>
                <input required placeholder="Item Name *" value={form.itemName} onChange={e => setForm(f => ({...f, itemName: e.target.value}))} className={inputCls} />
                <input type="number" min="1" placeholder="Quantity" value={form.quantity} onChange={e => setForm(f => ({...f, quantity: e.target.value}))} className={inputCls} />
              </>
            )}
            <textarea rows={2} placeholder="Description…" value={form.description} onChange={e => setForm(f => ({...f, description: e.target.value}))}
              className={inputCls + ' resize-none col-span-full'} />
            <div className="flex gap-2 col-span-full">
              <button type="submit" className="flex-1 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-bold transition-all">Submit Donation</button>
              <button type="button" onClick={() => setShowCreate(false)} className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-semibold transition-all">Cancel</button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input type="text" placeholder="Search donations…" value={filters.search}
            onChange={e => setFilters(f => ({...f, search: e.target.value}))}
            className="w-full pl-9 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500" />
        </div>
        <select value={filters.type} onChange={e => setFilters(f => ({...f, type: e.target.value}))}
          className="w-full px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500">
          <option value="all">All Types</option>
          {['Money','Food','Clothing','Medicine','Equipment','Other'].map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <select value={filters.status} onChange={e => setFilters(f => ({...f, status: e.target.value}))}
          className="w-full px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500">
          <option value="all">All Statuses</option>
          {['Pending','Received','Distributed','Cancelled'].map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span className="text-sm">Loading donations…</span>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-500 uppercase tracking-wider">
                  <th className="text-left px-5 py-3.5 font-medium">Donor</th>
                  <th className="text-left px-5 py-3.5 font-medium">Type</th>
                  <th className="text-left px-5 py-3.5 font-medium">Amount / Item</th>
                  <th className="text-left px-5 py-3.5 font-medium">Status</th>
                  {isAdmin && <th className="text-left px-5 py-3.5 font-medium">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {donations.length === 0 ? (
                  <tr><td colSpan={5} className="text-center py-12 text-slate-500 text-sm">No donations found</td></tr>
                ) : donations.map(d => (
                  <tr key={d._id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="px-5 py-3.5">
                      <p className="font-semibold text-white text-xs">{d.donor?.name || 'Anonymous'}</p>
                      <p className="text-slate-500 text-[11px]">{new Date(d.createdAt).toLocaleDateString()}</p>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-300">{d.donationType}</span>
                    </td>
                    <td className="px-5 py-3.5 text-white font-semibold text-xs">
                      {d.donationType === 'Money' ? `$${d.amount?.toLocaleString()}` : `${d.quantity} × ${d.itemName}`}
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${STATUS_STYLES[d.status] || 'bg-slate-700 text-slate-400'}`}>
                        {d.status}
                      </span>
                    </td>
                    {isAdmin && (
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-1">
                          {['Received','Distributed'].map(s => (
                            <button key={s} onClick={() => handleStatusChange(d._id, s)}
                              disabled={d.status === s}
                              className={`px-2 py-1 rounded-lg text-[10px] font-semibold transition-all ${
                                d.status === s ? 'bg-sky-500/20 text-sky-400 cursor-default' : 'bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white'
                              }`}>
                              {s}
                            </button>
                          ))}
                          <button onClick={() => handleDelete(d._id)} className="p-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 transition-all">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Donations;
