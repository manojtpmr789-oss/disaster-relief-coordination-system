import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ShieldAlert,
  Plus,
  Search,
  MapPin,
  Clock,
  Eye,
  Trash2,
  RefreshCw,
  Droplets,
  Flame,
  Mountain,
  Wind,
  User,
  Filter,
} from 'lucide-react';
import { disasterService } from '../services/disasterService';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const SEVERITY_STYLES = {
  Critical: 'bg-rose-500/20 text-rose-400 border border-rose-500/30',
  High: 'bg-orange-500/20 text-orange-400 border border-orange-500/30',
  Medium: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30',
  Low: 'bg-green-500/20 text-green-400 border border-green-500/30',
};

const STATUS_STYLES = {
  Active: 'bg-rose-500/20 text-rose-400',
  Verified: 'bg-sky-500/20 text-sky-400',
  Resolved: 'bg-emerald-500/20 text-emerald-400',
  Pending: 'bg-amber-500/20 text-amber-400',
};

const DISASTER_ICONS = {
  Flood: Droplets,
  Fire: Flame,
  Earthquake: Mountain,
  Cyclone: Wind,
  Landslide: Mountain,
  Tsunami: Droplets,
  default: ShieldAlert,
};

const DisasterCard = ({ disaster, onDelete, canDelete }) => {
  const Icon = DISASTER_ICONS[disaster.disasterType] || DISASTER_ICONS.default;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all duration-200 group flex flex-col justify-between gap-3">
      <div className="space-y-3">
        {/* Top bar: icon, title, severity */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center shrink-0">
              <Icon className="w-5 h-5 text-rose-400" />
            </div>
            <div className="min-w-0 flex-1">
              <Link
                to={`/disasters/${disaster._id}`}
                className="font-bold text-white hover:text-blue-400 transition-colors line-clamp-1 text-sm leading-snug"
              >
                {disaster.title}
              </Link>
              <p className="text-xs text-slate-400 mt-0.5">
                {disaster.disasterType} · {disaster.city}
              </p>
            </div>
          </div>
          <span
            className={`shrink-0 px-2 py-0.5 rounded-full text-[11px] font-bold ${
              SEVERITY_STYLES[disaster.severity] || 'bg-slate-800 text-slate-400'
            }`}
          >
            {disaster.severity}
          </span>
        </div>

        {/* Description */}
        <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
          {disaster.description}
        </p>

        {/* Location & Reporter info */}
        <div className="flex flex-col gap-1 text-[11px] text-slate-400 pt-1">
          <div className="flex items-center gap-1.5 truncate">
            <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span className="truncate">{disaster.location}</span>
          </div>
          <div className="flex items-center justify-between text-slate-500">
            <div className="flex items-center gap-1.5 truncate">
              <User className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span className="truncate">{disaster.reportedBy?.name || 'Community Member'}</span>
            </div>
            <span className="shrink-0">
              {new Date(disaster.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>

      {/* Footer & Actions */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-800 gap-2">
        <span
          className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
            STATUS_STYLES[disaster.status] || 'bg-slate-800 text-slate-400'
          }`}
        >
          {disaster.status}
        </span>

        <div className="flex items-center gap-2">
          <Link
            to={`/disasters/${disaster._id}`}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition-all"
          >
            <Eye className="w-3.5 h-3.5" /> View Details
          </Link>
          {canDelete && (
            <button
              onClick={() => onDelete(disaster._id)}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-all cursor-pointer"
              title="Delete Disaster Report"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

const DisasterReports = () => {
  const { user } = useAuth();
  const [disasters, setDisasters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: '',
    type: 'all',
    severity: 'all',
    status: 'all',
  });

  // Only admin and affected_user can create disaster reports; volunteers cannot
  const canCreate = ['admin', 'affected_user'].includes(user?.role);
  const canDelete = user?.role === 'admin';

  const fetchDisasters = async () => {
    try {
      setLoading(true);
      const res = await disasterService.getDisasters(filters);
      const list = res?.disasters || res?.data?.disasters || [];
      setDisasters(list);
    } catch (err) {
      toast.error('Failed to load disaster reports from server');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDisasters();
  }, [filters]);

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to permanently delete this disaster report?')) return;
    try {
      await disasterService.deleteDisaster(id);
      toast.success('Disaster report deleted successfully.');
      fetchDisasters();
    } catch (err) {
      toast.error(err.message || 'Failed to delete disaster report');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">Disaster Reports</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            {disasters.length} incident{disasters.length !== 1 ? 's' : ''} on record in database
          </p>
        </div>
        {canCreate && (
          <Link
            to="/disasters/create"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-semibold transition-all shadow-sm w-fit"
          >
            <Plus className="w-4 h-4" />
            <span>Report Disaster</span>
          </Link>
        )}
      </div>

      {/* Filters Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search title, description, city..."
            value={filters.search}
            onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
            className="w-full pl-9 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <select
          value={filters.type}
          onChange={(e) => setFilters((f) => ({ ...f, type: e.target.value }))}
          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
        >
          <option value="all">All Disaster Types</option>
          {['Flood', 'Earthquake', 'Cyclone', 'Landslide', 'Fire', 'Tsunami', 'Drought', 'Other'].map(
            (t) => (
              <option key={t} value={t}>
                {t}
              </option>
            )
          )}
        </select>

        <select
          value={filters.severity}
          onChange={(e) => setFilters((f) => ({ ...f, severity: e.target.value }))}
          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
        >
          <option value="all">All Severities</option>
          {['Critical', 'High', 'Medium', 'Low'].map((s) => (
            <option key={s} value={s}>
              {s} Severity
            </option>
          ))}
        </select>

        <select
          value={filters.status}
          onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
        >
          <option value="all">All Statuses</option>
          {['Pending', 'Active', 'Verified', 'Resolved'].map((s) => (
            <option key={s} value={s}>
              {s} Status
            </option>
          ))}
        </select>
      </div>

      {/* Disasters Content */}
      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin text-blue-400" />
          <span className="text-xs sm:text-sm">Loading disaster reports from database...</span>
        </div>
      ) : disasters.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-10 flex flex-col items-center justify-center text-center text-slate-400">
          <ShieldAlert className="w-10 h-10 mb-3 text-slate-500 opacity-60" />
          <h3 className="text-sm font-bold text-white mb-1">No Disaster Reports Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mb-4">
            No incidents match your current search and filter criteria, or none have been submitted yet.
          </p>
          {canCreate && (
            <Link
              to="/disasters/create"
              className="text-xs font-semibold text-rose-400 hover:text-rose-300 transition-colors"
            >
              + Submit the first disaster report
            </Link>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {disasters.map((d) => (
            <DisasterCard
              key={d._id}
              disaster={d}
              onDelete={handleDelete}
              canDelete={canDelete || (user && d.reportedBy && (d.reportedBy._id === user._id || d.reportedBy === user._id))}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default DisasterReports;
