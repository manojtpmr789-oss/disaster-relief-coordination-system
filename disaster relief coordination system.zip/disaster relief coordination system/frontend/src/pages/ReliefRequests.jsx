import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ClipboardList, Plus, Search, Eye, Trash2, RefreshCw, Package,
  Droplets, Pill, HelpCircle, User, Shield, ChevronDown, UserCheck
} from 'lucide-react';
import { reliefRequestService } from '../services/reliefRequestService';
import { volunteerService } from '../services/volunteerService';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const PRIORITY_STYLES = {
  Critical: 'bg-rose-500/20 text-rose-400 border border-rose-500/30',
  High: 'bg-orange-500/20 text-orange-400 border border-orange-500/30',
  Medium: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30',
  Low: 'bg-green-500/20 text-green-400 border border-green-500/30',
};
const STATUS_STYLES = {
  Pending: 'bg-yellow-500/20 text-yellow-400',
  Approved: 'bg-sky-500/20 text-sky-400',
  Assigned: 'bg-violet-500/20 text-violet-400',
  'In Progress': 'bg-blue-500/20 text-blue-400',
  Completed: 'bg-emerald-500/20 text-emerald-400',
  Rejected: 'bg-rose-500/20 text-rose-400',
};
const TYPE_ICONS = {
  Food: Package,
  Water: Droplets,
  Medicine: Pill,
  Rescue: Shield,
  Shelter: HelpCircle,
  Clothing: Package,
  Other: ClipboardList,
  default: ClipboardList,
};

const RequestCard = ({ request, onDelete, onAssign, volunteers, isAdmin }) => {
  const [assignOpen, setAssignOpen] = useState(false);
  const [selectedVol, setSelectedVol] = useState('');
  const [assigning, setAssigning] = useState(false);

  const Icon = TYPE_ICONS[request.requestType] || TYPE_ICONS.default;

  const handleAssign = async () => {
    if (!selectedVol) {
      toast.error('Please select a volunteer');
      return;
    }
    setAssigning(true);
    try {
      await onAssign(request._id, selectedVol);
      setAssignOpen(false);
      setSelectedVol('');
    } catch {
      // Toast handled by parent
    } finally {
      setAssigning(false);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all duration-300 flex flex-col gap-3">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-violet-500/10 flex items-center justify-center shrink-0">
            <Icon className="w-5 h-5 text-violet-400" />
          </div>
          <div className="min-w-0">
            <Link
              to={`/relief-requests/${request._id}`}
              className="font-bold text-white hover:text-sky-400 transition-colors text-sm line-clamp-1"
            >
              {request.requestType} Request
            </Link>
            <p className="text-xs text-slate-500 mt-0.5">
              {request.requester?.name || 'Unknown'} · {request.city}
            </p>
          </div>
        </div>
        <span className={`shrink-0 px-2 py-0.5 rounded-full text-[11px] font-bold ${PRIORITY_STYLES[request.priority]}`}>
          {request.priority}
        </span>
      </div>

      <p className="text-xs text-slate-400 line-clamp-2">{request.description}</p>

      {/* Location & Assigned Volunteer display */}
      <div className="text-xs text-slate-500 space-y-1">
        <p className="truncate">📍 {request.location}, {request.city}</p>
        {request.assignedVolunteer && (
          <p className="text-emerald-400 font-semibold text-xs flex items-center gap-1">
            <UserCheck className="w-3.5 h-3.5 shrink-0" />
            Assigned Volunteer: {request.assignedVolunteer?.name || 'Assigned'}
          </p>
        )}
      </div>

      <div className="flex items-center justify-between pt-2 border-t border-slate-800">
        <span className="text-xs text-slate-500">Qty: {request.quantity}</span>
        <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${STATUS_STYLES[request.status] || 'bg-slate-700 text-slate-400'}`}>
          {request.status}
        </span>
      </div>

      {/* Admin Inline Volunteer Assignment Panel */}
      {isAdmin && assignOpen && (
        <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2 mt-1">
          <label className="text-[11px] font-semibold text-slate-400">Select Volunteer</label>
          <select
            value={selectedVol}
            onChange={(e) => setSelectedVol(e.target.value)}
            className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-sky-500"
          >
            <option value="">— Select Volunteer —</option>
            {volunteers.map((v) => {
              const volunteerUserId = v.user?._id || v._id;
              const name = v.user?.name || v.name || 'Volunteer';
              const city = v.user?.city || v.city || 'Field';
              return (
                <option key={v._id || volunteerUserId} value={volunteerUserId}>
                  {name} - {city}
                </option>
              );
            })}
          </select>
          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              onClick={() => { setAssignOpen(false); setSelectedVol(''); }}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 text-xs font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handleAssign}
              disabled={!selectedVol || assigning}
              className="px-3 py-1 rounded-lg bg-sky-500 hover:bg-sky-600 disabled:opacity-40 text-white text-xs font-bold transition-all"
            >
              {assigning ? 'Assigning...' : 'Assign'}
            </button>
          </div>
        </div>
      )}

      <div className="flex items-center gap-2 mt-1">
        <Link
          to={`/relief-requests/${request._id}`}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 hover:text-white transition-all"
        >
          <Eye className="w-3.5 h-3.5" /> View Details
        </Link>
        {isAdmin && !assignOpen && (
          <button
            onClick={() => setAssignOpen(true)}
            className="flex items-center gap-1 px-3 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 text-xs font-bold transition-all border border-blue-500/30"
          >
            <UserCheck className="w-3.5 h-3.5" />
            Assign Volunteer
          </button>
        )}
        {isAdmin && (
          <button
            onClick={() => onDelete(request._id)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-all"
            title="Delete Request"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};

const ReliefRequests = () => {
  const { user } = useAuth();
  const [requests, setRequests] = useState([]);
  const [volunteers, setVolunteers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ search: '', requestType: 'all', priority: 'all', status: 'all' });

  const isAdmin = user?.role === 'admin';
  const isAffected = user?.role === 'affected_user';

  const fetchRequests = async () => {
    try {
      setLoading(true);
      const params = { ...filters };
      if (isAffected) params.myRequests = true;
      const res = await reliefRequestService.getReliefRequests(params);
      const list = res?.reliefRequests || res?.data?.reliefRequests || [];
      setRequests(list);
    } catch {
      toast.error('Failed to load relief requests');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, [filters]);

  useEffect(() => {
    if (isAdmin) {
      volunteerService.getVolunteers()
        .then((res) => {
          const vList = res?.volunteers || res?.data?.volunteers || [];
          setVolunteers(vList);
        })
        .catch(() => {});
    }
  }, [isAdmin]);

  const handleAssign = async (requestId, volunteerId) => {
    try {
      const res = await reliefRequestService.assignVolunteer(requestId, volunteerId);
      const updated = res?.reliefRequest || res?.data?.reliefRequest;
      if (updated) {
        setRequests((prev) =>
          prev.map((r) => (r._id === requestId ? { ...r, ...updated } : r))
        );
        toast.success('Volunteer assigned successfully');
      }
    } catch (err) {
      toast.error(err?.message || 'Failed to assign volunteer');
      throw err;
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this relief request?')) return;
    try {
      await reliefRequestService.deleteReliefRequest(id);
      toast.success('Request deleted');
      fetchRequests();
    } catch {
      toast.error('Failed to delete request');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">
            {isAffected ? 'My Relief Requests' : 'Relief Requests'}
          </h1>
          <p className="text-sm text-slate-400 mt-1">{requests.length} request{requests.length !== 1 ? 's' : ''} found</p>
        </div>
        {isAffected && (
          <Link to="/relief-requests/create"
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-violet-500 hover:bg-violet-600 text-white text-sm font-bold transition-all shadow-lg shadow-violet-500/20">
            <Plus className="w-4 h-4" /> New Request
          </Link>
        )}
      </div>

      {/* Filters */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input type="text" placeholder="Search requests…" value={filters.search}
            onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
            className="w-full pl-9 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500" />
        </div>
        <select value={filters.requestType} onChange={(e) => setFilters((f) => ({ ...f, requestType: e.target.value }))}
          className="w-full px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500">
          <option value="all">All Types</option>
          {['Food','Water','Medicine','Rescue','Shelter','Clothing','Other'].map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <select value={filters.priority} onChange={(e) => setFilters((f) => ({ ...f, priority: e.target.value }))}
          className="w-full px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500">
          <option value="all">All Priorities</option>
          {['Critical','High','Medium','Low'].map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <select value={filters.status} onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
          className="w-full px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500">
          <option value="all">All Statuses</option>
          {['Pending','Approved','Assigned','In Progress','Completed','Rejected'].map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span className="text-sm">Loading requests…</span>
        </div>
      ) : requests.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 gap-3 text-slate-500">
          <ClipboardList className="w-10 h-10 opacity-30" />
          <p className="text-sm">No relief requests found</p>
          {isAffected && (
            <Link to="/relief-requests/create" className="text-sm text-violet-400 hover:text-violet-300 font-medium transition-colors">
              + Submit your first request
            </Link>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {requests.map((r) => (
            <RequestCard
              key={r._id}
              request={r}
              onDelete={handleDelete}
              onAssign={handleAssign}
              volunteers={volunteers}
              isAdmin={isAdmin}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default ReliefRequests;
