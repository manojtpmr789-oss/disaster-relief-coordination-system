import React, { useState } from 'react';
import { BarChart2, Download, RefreshCw, FileText, Filter } from 'lucide-react';
import { reportService } from '../services/reportService';
import toast from 'react-hot-toast';

const MODULES = [
  { id: 'disasters', label: 'Disaster Incidents' },
  { id: 'reliefRequests', label: 'Relief Requests' },
  { id: 'volunteers', label: 'Volunteers' },
  { id: 'resources', label: 'Resource Inventory' },
  { id: 'donations', label: 'Donations' },
];

const exportCSV = (data, module) => {
  if (!data || data.length === 0) {
    toast.error('No data to export');
    return;
  }
  const headers = Object.keys(data[0]);
  const rows = data.map(row =>
    headers.map(h => {
      const val = row[h];
      if (typeof val === 'object' && val !== null) return JSON.stringify(val).replace(/"/g, "'");
      return `"${String(val ?? '').replace(/"/g, "'")}"`;
    }).join(',')
  );
  const csvContent = [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${module}_report_${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  toast.success('CSV exported!');
};

const Reports = () => {
  const [activeModule, setActiveModule] = useState('disasters');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [filters, setFilters] = useState({ status: 'all', severity: 'all', startDate: '', endDate: '' });

  const fetchReport = async () => {
    try {
      setLoading(true);
      const res = await reportService.getReportSummary({ module: activeModule, ...filters });
      const reportList = res?.reportData || res?.data?.reportData;
      if (reportList) {
        setData(reportList);
        toast.success(`Loaded ${reportList.length} records`);
      }
    } catch { toast.error('Failed to generate report'); }
    finally { setLoading(false); }
  };

  const inputCls = 'px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500';

  // Build table headers from first row
  const getDisplayHeaders = () => {
    if (data.length === 0) return [];
    const all = Object.keys(data[0]);
    // Prioritize key fields to display (filter out IDs and complex objects)
    return all.filter(k => !['__v', 'images', 'assignedTasks', 'completedTasks'].includes(k)).slice(0, 8);
  };

  const headers = getDisplayHeaders();

  const getCellValue = (row, header) => {
    const val = row[header];
    if (val === null || val === undefined) return '—';
    if (typeof val === 'boolean') return val ? 'Yes' : 'No';
    if (typeof val === 'object') {
      if (val.name) return val.name;
      return JSON.stringify(val).substring(0, 40) + '…';
    }
    if (typeof val === 'string' && val.includes('T') && val.includes('Z')) {
      return new Date(val).toLocaleDateString();
    }
    return String(val);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <BarChart2 className="w-6 h-6 text-violet-400" /> Reports & Analytics
          </h1>
          <p className="text-sm text-slate-400 mt-1">Generate and export data reports for any module</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={fetchReport}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-violet-500 hover:bg-violet-600 text-white text-sm font-bold transition-all">
            <RefreshCw className="w-4 h-4" /> Generate
          </button>
          <button onClick={() => exportCSV(data, activeModule)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-bold transition-all">
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>
      </div>

      {/* Module Tabs */}
      <div className="flex flex-wrap gap-2">
        {MODULES.map(m => (
          <button key={m.id} onClick={() => { setActiveModule(m.id); setData([]); }}
            className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
              activeModule === m.id
                ? 'bg-violet-500 text-white shadow-lg shadow-violet-500/20'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
            }`}>
            {m.label}
          </button>
        ))}
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-wrap gap-3 items-end">
        <div>
          <label className="block text-xs text-slate-500 mb-1">Status</label>
          <select value={filters.status} onChange={e => setFilters(f => ({...f, status: e.target.value}))} className={inputCls}>
            <option value="all">All</option>
            {['Active','Verified','Resolved','Pending','Completed','In Progress','Rejected'].map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">Start Date</label>
          <input type="date" value={filters.startDate} onChange={e => setFilters(f => ({...f, startDate: e.target.value}))} className={inputCls} />
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">End Date</label>
          <input type="date" value={filters.endDate} onChange={e => setFilters(f => ({...f, endDate: e.target.value}))} className={inputCls} />
        </div>
        <button onClick={fetchReport}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-sm font-semibold transition-all">
          <Filter className="w-4 h-4" /> Apply Filters
        </button>
      </div>

      {/* Report Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
            <RefreshCw className="w-5 h-5 animate-spin" />
            <span className="text-sm">Generating report…</span>
          </div>
        ) : data.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 gap-3 text-slate-500">
            <FileText className="w-10 h-10 opacity-30" />
            <p className="text-sm">Click "Generate" to load report data</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between">
              <span className="text-sm font-semibold text-white">{data.length} records found</span>
              <span className="text-xs text-slate-500">
                Report: {MODULES.find(m => m.id === activeModule)?.label}
              </span>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-500 uppercase tracking-wider">
                  {headers.map(h => (
                    <th key={h} className="text-left px-4 py-3 font-medium whitespace-nowrap">
                      {h.replace(/([A-Z])/g, ' $1').trim()}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {data.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                    {headers.map(h => (
                      <td key={h} className="px-4 py-3 text-xs text-slate-300 whitespace-nowrap max-w-[200px] truncate">
                        {getCellValue(row, h)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Reports;
