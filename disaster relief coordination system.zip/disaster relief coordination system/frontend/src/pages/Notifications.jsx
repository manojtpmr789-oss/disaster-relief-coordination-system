import React, { useEffect, useState } from 'react';
import { Bell, Check, CheckCheck, Trash2, RefreshCw, Info, AlertTriangle, Package, HandCoins, ClipboardList, ShieldAlert } from 'lucide-react';
import { notificationService } from '../services/notificationService';
import toast from 'react-hot-toast';

const TYPE_STYLES = {
  Disaster: { bg: 'bg-rose-500/10 border-rose-500/20', icon: ShieldAlert, iconColor: 'text-rose-400' },
  'Relief Request': { bg: 'bg-violet-500/10 border-violet-500/20', icon: ClipboardList, iconColor: 'text-violet-400' },
  Resource: { bg: 'bg-orange-500/10 border-orange-500/20', icon: Package, iconColor: 'text-orange-400' },
  Donation: { bg: 'bg-emerald-500/10 border-emerald-500/20', icon: HandCoins, iconColor: 'text-emerald-400' },
  General: { bg: 'bg-sky-500/10 border-sky-500/20', icon: Info, iconColor: 'text-sky-400' },
};

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const res = await notificationService.getNotifications();
      if (res.data?.success) {
        setNotifications(res.data.notifications);
        setUnreadCount(res.data.unreadCount);
      }
    } catch { toast.error('Failed to load notifications'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchNotifications(); }, []);

  const markRead = async (id) => {
    try {
      await notificationService.markAsRead(id);
      setNotifications(ns => ns.map(n => n._id === id ? { ...n, isRead: true } : n));
      setUnreadCount(c => Math.max(0, c - 1));
    } catch { toast.error('Failed to mark as read'); }
  };

  const markAllRead = async () => {
    try {
      await notificationService.markAllAsRead();
      setNotifications(ns => ns.map(n => ({ ...n, isRead: true })));
      setUnreadCount(0);
      toast.success('All notifications marked as read');
    } catch { toast.error('Failed to mark all as read'); }
  };

  const deleteNotif = async (id) => {
    try {
      await notificationService.deleteNotification(id);
      setNotifications(ns => ns.filter(n => n._id !== id));
      toast.success('Notification deleted');
    } catch { toast.error('Delete failed'); }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Bell className="w-6 h-6 text-sky-400" />
            Notifications
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-sky-500 text-white text-xs font-bold">{unreadCount}</span>
            )}
          </h1>
          <p className="text-sm text-slate-400 mt-1">{notifications.length} total · {unreadCount} unread</p>
        </div>
        {unreadCount > 0 && (
          <button onClick={markAllRead}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-sm font-semibold transition-all">
            <CheckCheck className="w-4 h-4" /> Mark All Read
          </button>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span className="text-sm">Loading notifications…</span>
        </div>
      ) : notifications.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 gap-3 text-slate-500">
          <Bell className="w-10 h-10 opacity-30" />
          <p className="text-sm">No notifications yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((n) => {
            const style = TYPE_STYLES[n.type] || TYPE_STYLES.General;
            const Icon = style.icon;

            return (
              <div key={n._id}
                className={`relative flex items-start gap-4 p-4 rounded-2xl border transition-all duration-200 ${
                  n.isRead ? 'bg-slate-900 border-slate-800' : `${style.bg} border`
                }`}>

                {/* Unread dot */}
                {!n.isRead && (
                  <span className="absolute top-4 right-4 w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                )}

                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${n.isRead ? 'bg-slate-800' : `${style.bg}`}`}>
                  <Icon className={`w-5 h-5 ${n.isRead ? 'text-slate-500' : style.iconColor}`} />
                </div>

                <div className="flex-1 min-w-0 pr-6">
                  <p className={`font-semibold text-sm leading-snug ${n.isRead ? 'text-slate-400' : 'text-white'}`}>
                    {n.title}
                  </p>
                  <p className={`text-xs mt-1 leading-relaxed ${n.isRead ? 'text-slate-600' : 'text-slate-400'}`}>
                    {n.message}
                  </p>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="text-[11px] text-slate-600">{new Date(n.createdAt).toLocaleString()}</span>
                    {!n.isRead && (
                      <button onClick={() => markRead(n._id)}
                        className="text-[11px] text-sky-400 hover:text-sky-300 font-semibold transition-colors flex items-center gap-1">
                        <Check className="w-3 h-3" /> Mark as read
                      </button>
                    )}
                  </div>
                </div>

                <button onClick={() => deleteNotif(n._id)}
                  className="absolute bottom-4 right-4 p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-500 hover:text-rose-400 transition-all">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default Notifications;
