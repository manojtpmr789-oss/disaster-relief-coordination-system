import React, { useEffect, useState } from 'react';
import {
  Users,
  Search,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Mail,
  Phone,
  MapPin,
  Clock,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';
import { volunteerService } from '../services/volunteerService';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const VERIFY_STYLES = {
  Verified: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30',
  Pending: 'bg-amber-500/20 text-amber-400 border border-amber-500/30',
  Rejected: 'bg-rose-500/20 text-rose-400 border border-rose-500/30',
};

const AVAILABILITY_STYLES = {
  available: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20',
  busy: 'bg-amber-500/10 text-amber-400 border border-amber-500/20',
  unavailable: 'bg-slate-800 text-slate-400 border border-slate-700',
};

const Volunteers = () => {
  const { user } = useAuth();
  const [volunteers, setVolunteers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState(null);
  const [filters, setFilters] = useState({
    search: '',
    city: 'all',
    availability: 'all',
    verification: 'all',
  });

  const isAdmin = user?.role === 'admin';

  const fetchVolunteers = async () => {
    try {
      setLoading(true);
      const res = await volunteerService.getVolunteers(filters);
      const list = res?.volunteers || res?.data?.volunteers || [];
      setVolunteers(list);
    } catch (err) {
      toast.error('Failed to load volunteer records from MongoDB');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVolunteers();
  }, [filters]);

  const handleVerify = async (id, status) => {
    try {
      setUpdatingId(id);
      await volunteerService.verifyVolunteer(id, status);
      toast.success(`Volunteer status updated to ${status}`);
      fetchVolunteers();
    } catch (err) {
      toast.error(err.message || 'Verification update failed');
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">Volunteers</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            {volunteers.length} volunteer{volunteers.length !== 1 ? 's' : ''} registered in the system
          </p>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search name, email, skills, city..."
            value={filters.search}
            onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
            className="w-full pl-9 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>

        <select
          value={filters.availability}
          onChange={(e) => setFilters((f) => ({ ...f, availability: e.target.value }))}
          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
        >
          <option value="all">All Availability</option>
          <option value="available">Available</option>
          <option value="busy">Busy / On-call</option>
          <option value="unavailable">Unavailable</option>
        </select>

        <select
          value={filters.verification}
          onChange={(e) => setFilters((f) => ({ ...f, verification: e.target.value }))}
          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
        >
          <option value="all">All Verification Statuses</option>
          <option value="Pending">Pending Verification</option>
          <option value="Verified">Verified</option>
          <option value="Rejected">Rejected</option>
        </select>
      </div>

      {/* Volunteer Records Table */}
      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin text-blue-400" />
          <span className="text-xs sm:text-sm">Loading volunteers from database...</span>
        </div>
      ) : volunteers.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-10 flex flex-col items-center justify-center text-center text-slate-400">
          <Users className="w-10 h-10 mb-3 text-slate-500 opacity-60" />
          <h3 className="text-sm font-bold text-white mb-1">No Volunteer Records Found</h3>
          <p className="text-xs text-slate-400 max-w-sm">
            No registered volunteers match your current search and filter settings.
          </p>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] text-slate-400 uppercase tracking-wider bg-slate-950/40">
                  <th className="text-left px-4 py-3 font-semibold">Volunteer</th>
                  <th className="text-left px-4 py-3 font-semibold">Contact</th>
                  <th className="text-left px-4 py-3 font-semibold">Skills</th>
                  <th className="text-left px-4 py-3 font-semibold">City</th>
                  <th className="text-left px-4 py-3 font-semibold">Availability</th>
                  <th className="text-left px-4 py-3 font-semibold">Verification</th>
                  {isAdmin && <th className="text-left px-4 py-3 font-semibold">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {volunteers.map((v) => (
                  <tr key={v._id} className="hover:bg-slate-800/40 transition-colors">
                    {/* Volunteer Name & Role */}
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-xs shrink-0">
                          {v.user?.name?.[0]?.toUpperCase() || 'V'}
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-white truncate max-w-[140px]">
                            {v.user?.name || 'Volunteer'}
                          </p>
                          <p className="text-[11px] text-slate-400 truncate max-w-[140px]">
                            {v.user?.email || 'N/A'}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* Contact Phone & Emergency */}
                    <td className="px-4 py-3 text-slate-300">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1.5 text-slate-300">
                          <Phone className="w-3 h-3 text-slate-500 shrink-0" />
                          <span>{v.user?.phone || '—'}</span>
                        </div>
                        {v.emergencyContact && v.emergencyContact !== v.user?.phone && (
                          <p className="text-[10px] text-slate-500">
                            Emerg: {v.emergencyContact}
                          </p>
                        )}
                      </div>
                    </td>

                    {/* Skills */}
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1 max-w-[200px]">
                        {(v.skills || []).length === 0 ? (
                          <span className="text-slate-500 text-[11px]">None listed</span>
                        ) : (
                          (v.skills || []).map((s, idx) => (
                            <span
                              key={idx}
                              className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 text-[10px]"
                            >
                              {s}
                            </span>
                          ))
                        )}
                      </div>
                    </td>

                    {/* City */}
                    <td className="px-4 py-3 text-slate-300">
                      <span>{v.city || v.user?.city || '—'}</span>
                    </td>

                    {/* Availability */}
                    <td className="px-4 py-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-semibold capitalize ${
                          AVAILABILITY_STYLES[v.availability] || 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {v.availability}
                      </span>
                    </td>

                    {/* Verification Status */}
                    <td className="px-4 py-3">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${
                          VERIFY_STYLES[v.verificationStatus] || 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {v.verificationStatus}
                      </span>
                    </td>

                    {/* Actions (Admin Only) */}
                    {isAdmin && (
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          {v.verificationStatus !== 'Verified' && (
                            <button
                              onClick={() => handleVerify(v._id, 'Verified')}
                              disabled={updatingId === v._id}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[11px] font-semibold transition-all cursor-pointer disabled:opacity-50"
                              title="Verify Volunteer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Verify</span>
                            </button>
                          )}

                          {v.verificationStatus !== 'Rejected' && (
                            <button
                              onClick={() => handleVerify(v._id, 'Rejected')}
                              disabled={updatingId === v._id}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[11px] font-semibold transition-all cursor-pointer disabled:opacity-50"
                              title="Reject Volunteer"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Reject</span>
                            </button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Volunteers;
