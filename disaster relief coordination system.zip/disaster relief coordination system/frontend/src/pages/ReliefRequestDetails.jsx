import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ClipboardList, ArrowLeft, User, MapPin, Phone, Calendar, Trash2, RefreshCw, CheckCircle2
} from 'lucide-react';
import { reliefRequestService } from '../services/reliefRequestService';
import { volunteerService } from '../services/volunteerService';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const PRIORITY_STYLES = {
  Critical: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
  High: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  Medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  Low: 'bg-green-500/20 text-green-400 border-green-500/30',
};
const STATUS_STYLES = {
  Pending: 'bg-yellow-500/20 text-yellow-400',
  Approved: 'bg-sky-500/20 text-sky-400',
  Assigned: 'bg-violet-500/20 text-violet-400',
  'In Progress': 'bg-blue-500/20 text-blue-400',
  Completed: 'bg-emerald-500/20 text-emerald-400',
  Rejected: 'bg-rose-500/20 text-rose-400',
};

const ReliefRequestDetails = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [request, setRequest] = useState(null);
  const [volunteers, setVolunteers] = useState([]);
  const [selectedVolunteer, setSelectedVolunteer] = useState('');
  const [loading, setLoading] = useState(true);

  const isAdmin = user?.role === 'admin';
  const isVolunteer = user?.role === 'volunteer';

  useEffect(() => {
    reliefRequestService.getReliefRequestById(id)
      .then(res => {
        const reqData = res?.reliefRequest || res?.data?.reliefRequest;
        if (reqData) setRequest(reqData);
      })
      .catch(() => toast.error('Failed to load request'))
      .finally(() => setLoading(false));

    if (isAdmin) {
      // Fetch all registered volunteers for assignment dropdown
      volunteerService.getVolunteers()
        .then(res => {
          const vList = res?.volunteers || res?.data?.volunteers || [];
          setVolunteers(vList);
        })
        .catch(() => {});
    }
  }, [id, isAdmin]);

  const updateStatus = async (status) => {
    try {
      let res;
      if (isVolunteer) {
        res = await reliefRequestService.updateTaskStatus(id, status);
      } else {
        res = await reliefRequestService.updateReliefRequest(id, { status });
      }
      const updated = res?.reliefRequest || res?.data?.reliefRequest;
      if (updated) {
        setRequest(updated);
        toast.success(`Status updated to ${status}`);
      }
    } catch (err) {
      toast.error(err?.message || 'Update failed');
    }
  };

  const handleAssignVolunteer = async () => {
    if (!selectedVolunteer) {
      toast.error('Please select a volunteer');
      return;
    }
    try {
      const res = await reliefRequestService.assignVolunteer(id, selectedVolunteer);
      const updated = res?.reliefRequest || res?.data?.reliefRequest;
      if (updated) {
        setRequest(updated);
        toast.success('Volunteer assigned successfully');
      }
    } catch (err) {
      toast.error(err?.message || 'Failed to assign volunteer');
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Delete this relief request?')) return;
    try {
      await reliefRequestService.deleteReliefRequest(id);
      toast.success('Request deleted');
      navigate('/relief-requests');
    } catch { toast.error('Delete failed'); }
  };

  if (loading) return (
    <div className="flex items-center justify-center h-64 gap-3 text-slate-400">
      <RefreshCw className="w-5 h-5 animate-spin" />
      <span className="text-sm">Loading request details…</span>
    </div>
  );

  if (!request) return (
    <div className="text-center py-20 text-slate-500">
      <ClipboardList className="w-10 h-10 mx-auto mb-3 opacity-30" />
      <p>Relief request not found</p>
      <Link to="/relief-requests" className="text-sky-400 hover:text-sky-300 text-sm mt-2 inline-block">← Back</Link>
    </div>
  );

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Link to="/relief-requests" className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="text-xl font-bold text-white">{request.requestType} Relief Request</h1>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
        {/* Badges */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={`px-3 py-1 rounded-full text-xs font-bold border ${PRIORITY_STYLES[request.priority]}`}>
              {request.priority} Priority
            </span>
            <span className={`px-3 py-1 rounded-full text-xs font-bold ${STATUS_STYLES[request.status]}`}>
              {request.status}
            </span>
          </div>
          {isAdmin && (
            <button onClick={handleDelete} className="p-2 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 transition-all">
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>

        <div>
          <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Description</h3>
          <p className="text-slate-300 text-sm leading-relaxed">{request.description}</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm">
          <div>
            <p className="text-xs text-slate-500 mb-1">Quantity</p>
            <p className="text-white font-semibold">{request.quantity} units</p>
          </div>
          <div className="flex items-start gap-2 text-slate-400">
            <MapPin className="w-4 h-4 text-sky-400 mt-0.5" />
            <div>
              <p className="text-xs text-slate-500 mb-0.5">Location</p>
              <p className="text-white text-xs">{request.location}, {request.city}</p>
            </div>
          </div>
          <div className="flex items-start gap-2 text-slate-400">
            <Phone className="w-4 h-4 text-teal-400 mt-0.5" />
            <div>
              <p className="text-xs text-slate-500 mb-0.5">Contact</p>
              <p className="text-white text-xs">{request.contactNumber}</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <User className="w-4 h-4 text-violet-400 mt-0.5" />
            <div>
              <p className="text-xs text-slate-500 mb-0.5">Requester</p>
              <p className="text-white text-xs">{request.requester?.name || 'Unknown'}</p>
            </div>
          </div>
          {request.assignedVolunteer && (
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5" />
              <div>
                <p className="text-xs text-slate-500 mb-0.5">Assigned Volunteer</p>
                <p className="text-white text-xs">{request.assignedVolunteer?.name || 'Assigned'}</p>
              </div>
            </div>
          )}
        </div>

        {/* Admin Actions */}
        {isAdmin && (
          <div className="border-t border-slate-800 pt-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-300">Update Status</h3>
            <div className="flex flex-wrap gap-2">
              {['Approved', 'Assigned', 'In Progress', 'Completed', 'Rejected'].map(s => (
                <button key={s} onClick={() => updateStatus(s)}
                  disabled={request.status === s}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    request.status === s
                      ? 'bg-sky-500/20 text-sky-400 cursor-default'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white'
                  }`}>
                  {s}
                </button>
              ))}
            </div>

            <div className="flex gap-3">
              <select value={selectedVolunteer} onChange={e => setSelectedVolunteer(e.target.value)}
                className="flex-1 px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-1 focus:ring-sky-500">
                <option value="">— Select Volunteer —</option>
                {volunteers.map(v => {
                  const volunteerUserId = v.user?._id || v._id;
                  const name = v.user?.name || v.name || 'Volunteer';
                  const city = v.user?.city || v.city || 'Field';
                  return (
                    <option key={v._id || volunteerUserId} value={volunteerUserId}>
                      {name} - {city}
                    </option>
                  );
                })}
              </select>
              <button onClick={handleAssignVolunteer} disabled={!selectedVolunteer}
                className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 disabled:opacity-40 text-white text-sm font-bold transition-all">
                Assign
              </button>
            </div>
          </div>
        )}

        {/* Volunteer: Start Task (Assigned → In Progress) */}
        {isVolunteer &&
          request.assignedVolunteer &&
          ((request.assignedVolunteer._id || request.assignedVolunteer).toString() === user?._id?.toString()) &&
          request.status === 'Assigned' && (
          <div className="border-t border-slate-800 pt-4 flex items-center gap-3 flex-wrap">
            <button onClick={() => updateStatus('In Progress')}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold transition-all">
              Start Task
            </button>
            <span className="text-xs text-slate-500">Click to begin relief operations for this task.</span>
          </div>
        )}

        {/* Volunteer: Mark Completed (In Progress → Completed) */}
        {isVolunteer &&
          request.assignedVolunteer &&
          ((request.assignedVolunteer._id || request.assignedVolunteer).toString() === user?._id?.toString()) &&
          request.status === 'In Progress' && (
          <div className="border-t border-slate-800 pt-4 flex items-center gap-3 flex-wrap">
            <button onClick={() => updateStatus('Completed')}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-bold transition-all">
              <CheckCircle2 className="w-4 h-4" /> Mark Completed
            </button>
            <span className="text-xs text-slate-500">Mark this relief task as completed.</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReliefRequestDetails;
