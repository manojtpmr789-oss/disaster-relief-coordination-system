import React from 'react';
import { useAuth } from '../context/AuthContext';
import {
  AdminDashboardView,
  VolunteerDashboardView,
  AffectedUserDashboardView,
} from '../components/dashboard/DashboardViews';

const ROLE_GREETINGS = {
  admin: {
    title: 'Admin Dashboard',
    subtitle: 'Overview of relief operations, active incidents, volunteers, and resources.',
  },
  volunteer: {
    title: 'Volunteer Dashboard',
    subtitle: 'Overview of assigned field tasks, active incidents, and relief requests.',
  },
  affected_user: {
    title: 'Community Dashboard',
    subtitle: 'Report emergency incidents and submit or track relief assistance requests.',
  },
};

const Dashboard = () => {
  const { user } = useAuth();
  const role = user?.role || 'affected_user';
  const greeting = ROLE_GREETINGS[role] || ROLE_GREETINGS.affected_user;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">{greeting.title}</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">{greeting.subtitle}</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 w-fit">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span className="text-slate-300 capitalize font-medium">{role.replace('_', ' ')}</span>
        </div>
      </div>

      {/* Role-Based Dashboard Views */}
      {role === 'admin' && <AdminDashboardView />}
      {role === 'volunteer' && <VolunteerDashboardView />}
      {role === 'affected_user' && <AffectedUserDashboardView />}
    </div>
  );
};

export default Dashboard;
