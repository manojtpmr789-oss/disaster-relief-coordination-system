import React from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../components/PageHeader';
import {
  Clock,
  Sparkles,
  ArrowLeft,
  CheckCircle2,
  Layers,
  ShieldAlert,
} from 'lucide-react';

export const Part2Placeholder = ({
  moduleName = 'Operational Module',
  description = 'Emergency logistics and relief coordination workflow.',
  icon: Icon = Layers,
}) => {
  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <PageHeader
        title={moduleName}
        subtitle="Phase 2 Roadmap & Architecture"
        icon={Icon}
        badge="PART 2 PLANNED"
        actions={
          <Link
            to="/dashboard"
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 transition-all"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Dashboard</span>
          </Link>
        }
      />

      <div className="relative overflow-hidden rounded-3xl bg-slate-900/90 border border-slate-800 p-8 sm:p-12 text-center shadow-2xl backdrop-blur-xl">
        <div className="max-w-xl mx-auto space-y-6">
          <div className="inline-flex items-center justify-center p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
            <Clock className="w-10 h-10 animate-pulse" />
          </div>

          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wider bg-amber-500/10 text-amber-400 border border-amber-500/30">
              Module will be implemented in Part 2
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {moduleName}
            </h2>
            <p className="text-sm text-slate-400 leading-relaxed">
              {description} Part 1 core system (Express API, MongoDB integration, JWT Authentication, and Admin Personnel Management) is complete and verified.
            </p>
          </div>

          {/* Feature Highlights planned */}
          <div className="p-6 rounded-2xl bg-slate-800/40 border border-slate-800 text-left space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Part 2 Scheduled Features for this Module</span>
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Real-time dispatch status updates and live geospatial mapping</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Multi-role approvals with audit trail logging</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Automated SMS and Push broadcast alerts to registered first responders</span>
              </li>
            </ul>
          </div>

          <div>
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 shadow-lg shadow-sky-500/25 transition-all"
            >
              <span>Back to Command Dashboard</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Part2Placeholder;
