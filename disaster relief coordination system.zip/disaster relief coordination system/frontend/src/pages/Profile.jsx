import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import userService from '../services/userService';
import PageHeader from '../components/PageHeader';
import Loading from '../components/Loading';
import {
  User,
  Mail,
  Phone,
  MapPin,
  Building,
  Shield,
  Clock,
  Wrench,
  Save,
  CheckCircle2,
  Plus,
  X,
  Loader2,
  Lock,
  Sparkles,
} from 'lucide-react';

export const Profile = () => {
  const { currentUser, updateUserProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    role: '',
    availability: 'available',
    skills: [],
  });

  const [newSkillInput, setNewSkillInput] = useState('');

  // Pre-fill profile from current user
  useEffect(() => {
    if (currentUser) {
      setFormData({
        name: currentUser.name || '',
        email: currentUser.email || '',
        phone: currentUser.phone || '',
        address: currentUser.address || '',
        city: currentUser.city || '',
        role: currentUser.role || 'affected_user',
        availability: currentUser.availability || 'available',
        skills: currentUser.skills || [],
      });
    }
  }, [currentUser]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleAddSkill = (e) => {
    e.preventDefault();
    const skillTrimmed = newSkillInput.trim();
    if (skillTrimmed && !formData.skills.includes(skillTrimmed)) {
      setFormData({
        ...formData,
        skills: [...formData.skills, skillTrimmed],
      });
      setNewSkillInput('');
    }
  };

  const handleRemoveSkill = (skillToRemove) => {
    setFormData({
      ...formData,
      skills: formData.skills.filter((s) => s !== skillToRemove),
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      await updateUserProfile({
        name: formData.name,
        phone: formData.phone,
        address: formData.address,
        city: formData.city,
        skills: formData.skills,
        availability: formData.availability,
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <PageHeader
        title="Responder Profile & Capabilities"
        subtitle="Manage your personal contact details, incident skill set, and emergency readiness."
        icon={User}
        badge="PROFILE"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Profile Summary Card */}
        <div className="space-y-6">
          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 backdrop-blur-md">
            <div className="flex flex-col items-center text-center pb-6 border-b border-slate-800">
              <div className="relative mb-3">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-sky-500 to-blue-700 text-white font-black text-2xl flex items-center justify-center shadow-xl shadow-sky-500/20">
                  {formData.name ? formData.name.charAt(0).toUpperCase() : 'U'}
                </div>
                <span
                  className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-slate-900 ${
                    formData.availability === 'available'
                      ? 'bg-emerald-500'
                      : formData.availability === 'busy'
                      ? 'bg-amber-500'
                      : 'bg-slate-500'
                  }`}
                  title={`Status: ${formData.availability}`}
                />
              </div>

              <h3 className="text-base font-bold text-white">{formData.name || 'User'}</h3>
              <p className="text-xs text-slate-400 mt-0.5">{formData.email}</p>

              <div className="mt-3 flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-sky-500/10 text-sky-400 border border-sky-500/30">
                  Role: {formData.role}
                </span>
                <span
                  className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                    formData.availability === 'available'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      : formData.availability === 'busy'
                      ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {formData.availability}
                </span>
              </div>
            </div>

            {/* Quick Summary list */}
            <div className="py-4 space-y-3 text-xs">
              <div className="flex items-center justify-between text-slate-400">
                <span className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-500" />
                  <span>Phone Number</span>
                </span>
                <span className="text-slate-200 font-semibold">{formData.phone || 'Not set'}</span>
              </div>

              <div className="flex items-center justify-between text-slate-400">
                <span className="flex items-center gap-2">
                  <Building className="w-3.5 h-3.5 text-slate-500" />
                  <span>Assigned City</span>
                </span>
                <span className="text-slate-200 font-semibold">{formData.city || 'Not set'}</span>
              </div>

              <div className="flex items-center justify-between text-slate-400">
                <span className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-500" />
                  <span>Address</span>
                </span>
                <span className="text-slate-200 font-semibold truncate max-w-[140px]">
                  {formData.address || 'Not set'}
                </span>
              </div>
            </div>

            {/* System Security Notice */}
            <div className="mt-2 p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/60 text-xs text-slate-400 flex items-start gap-2.5">
              <Lock className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-slate-300">Identity Security</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Email and Role permissions are governed by Incident Command Administrators and cannot be modified directly.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right 2 Columns: Editable Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8 backdrop-blur-md space-y-6">
            <div>
              <h3 className="text-base font-bold text-white">Edit Profile Details</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Update your contact info and capabilities to facilitate relief coordination
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Name */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                  Full Name *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              {/* Email (Read-Only) */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                  Email Address (Read-only)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    disabled
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-800/40 border border-slate-800 rounded-xl text-sm text-slate-400 cursor-not-allowed"
                  />
                </div>
              </div>

              {/* Phone */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                  Contact Phone Number *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <Phone className="w-4 h-4" />
                  </div>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              {/* City */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                  City / District *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <Building className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    required
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all"
                  />
                </div>
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                Physical Location / Base Address *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <MapPin className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  required
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all"
                />
              </div>
            </div>

            {/* Availability & Role Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                  Emergency Availability Status
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <Clock className="w-4 h-4" />
                  </div>
                  <select
                    name="availability"
                    value={formData.availability}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all"
                  >
                    <option value="available">Available (On-Call & Ready)</option>
                    <option value="busy">Busy (Currently Deployed)</option>
                    <option value="unavailable">Unavailable (Off-Duty)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                  Assigned System Role (Read-only)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <Shield className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={formData.role}
                    disabled
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-800/40 border border-slate-800 rounded-xl text-sm text-slate-400 capitalize cursor-not-allowed"
                  />
                </div>
              </div>
            </div>

            {/* Skills & Certifications Tag Manager */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                Skills & Emergency Certifications
              </label>
              <div className="space-y-3">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                      <Wrench className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      value={newSkillInput}
                      onChange={(e) => setNewSkillInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddSkill(e);
                        }
                      }}
                      placeholder="e.g. First Aid, Drone Piloting, Heavy Machinery..."
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-800/80 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-all"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleAddSkill}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-white transition-all cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Skill</span>
                  </button>
                </div>

                {/* Skill Badges Display */}
                <div className="flex flex-wrap gap-2 min-h-[40px] p-3 rounded-xl bg-slate-800/40 border border-slate-800">
                  {formData.skills && formData.skills.length > 0 ? (
                    formData.skills.map((skill, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium bg-sky-500/10 text-sky-300 border border-sky-500/25 animate-in fade-in duration-150"
                      >
                        <span>{skill}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveSkill(skill)}
                          className="p-0.5 rounded-md hover:bg-sky-500/20 text-sky-400 hover:text-sky-200"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))
                  ) : (
                    <span className="text-xs text-slate-500 italic">
                      No skills added yet. Type a skill above and click Add.
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                type="submit"
                disabled={saving}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 shadow-lg shadow-sky-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                {saving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Saving Changes...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Save Profile Changes</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Profile;
