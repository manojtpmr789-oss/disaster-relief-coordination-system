import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ClipboardList, ArrowLeft, Loader2, Save, MapPin } from 'lucide-react';
import { reliefRequestService } from '../services/reliefRequestService';
import { disasterService } from '../services/disasterService';
import toast from 'react-hot-toast';

const inputCls = 'w-full px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500 transition-colors';
const FormGroup = ({ label, required, children }) => (
  <div className="space-y-1.5">
    <label className="block text-sm font-medium text-slate-300">
      {label} {required && <span className="text-rose-400">*</span>}
    </label>
    {children}
  </div>
);

const CreateReliefRequest = () => {
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [disasters, setDisasters] = useState([]);
  const [form, setForm] = useState({
    requestType: 'Food',
    description: '',
    quantity: 1,
    priority: 'High',
    location: '',
    city: '',
    contactNumber: '',
    disaster: '',
  });

  useEffect(() => {
    disasterService.getDisasters({ status: 'Active' })
      .then(res => { if (res.data?.success) setDisasters(res.data.disasters); })
      .catch(() => {});
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.description.trim() || !form.city.trim() || !form.contactNumber.trim()) {
      toast.error('Please fill all required fields');
      return;
    }
    try {
      setSubmitting(true);
      const res = await reliefRequestService.createReliefRequest({
        ...form,
        disaster: form.disaster || undefined,
      });
      if (res.data?.success) {
        toast.success('Relief request submitted successfully!');
        navigate('/relief-requests');
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to submit request');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Link to="/relief-requests" className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-white">Submit Relief Request</h1>
          <p className="text-sm text-slate-400 mt-0.5">Request emergency aid — food, water, medicine, or rescue</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <h2 className="font-bold text-white text-base flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-violet-400" /> Request Details
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormGroup label="Request Type" required>
              <select name="requestType" value={form.requestType} onChange={handleChange} className={inputCls}>
                {['Food','Water','Medicine','Rescue','Shelter','Clothing','Other'].map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </FormGroup>
            <FormGroup label="Priority Level" required>
              <select name="priority" value={form.priority} onChange={handleChange} className={inputCls}>
                {['Critical','High','Medium','Low'].map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </FormGroup>
          </div>

          <FormGroup label="Description" required>
            <textarea name="description" value={form.description} onChange={handleChange} required rows={3}
              placeholder="Describe your urgent need in detail…"
              className={inputCls + ' resize-none'} />
          </FormGroup>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormGroup label="Quantity Required" required>
              <input name="quantity" type="number" min="1" value={form.quantity} onChange={handleChange}
                className={inputCls} />
            </FormGroup>
            <FormGroup label="Related Disaster">
              <select name="disaster" value={form.disaster} onChange={handleChange} className={inputCls}>
                <option value="">— Select active disaster (optional) —</option>
                {disasters.map(d => <option key={d._id} value={d._id}>{d.title}</option>)}
              </select>
            </FormGroup>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
          <h2 className="font-bold text-white text-base flex items-center gap-2">
            <MapPin className="w-5 h-5 text-sky-400" /> Your Location & Contact
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormGroup label="Location / Address" required>
              <input name="location" value={form.location} onChange={handleChange} required
                placeholder="e.g. 14 Riverside Blvd, Zone B" className={inputCls} />
            </FormGroup>
            <FormGroup label="City" required>
              <input name="city" value={form.city} onChange={handleChange} required
                placeholder="e.g. Riverdale" className={inputCls} />
            </FormGroup>
          </div>

          <FormGroup label="Contact Number" required>
            <input name="contactNumber" value={form.contactNumber} onChange={handleChange} required
              placeholder="+1 (555) 000-0000" className={inputCls} />
          </FormGroup>
        </div>

        <div className="flex items-center justify-end gap-3">
          <Link to="/relief-requests"
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-sm font-semibold transition-all">
            Cancel
          </Link>
          <button type="submit" disabled={submitting}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-violet-500 hover:bg-violet-600 disabled:opacity-60 text-white text-sm font-bold transition-all shadow-lg shadow-violet-500/20">
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            <span>{submitting ? 'Submitting…' : 'Submit Request'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateReliefRequest;
