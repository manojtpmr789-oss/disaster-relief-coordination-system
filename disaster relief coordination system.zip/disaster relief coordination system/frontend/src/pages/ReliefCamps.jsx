import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Tent, Plus, Search, Eye, MapPin, RefreshCw, Trash2, Users } from 'lucide-react';
import { campService } from '../services/campService';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const STATUS_STYLES = {
  Open: 'bg-emerald-500/20 text-emerald-400',
  Full: 'bg-rose-500/20 text-rose-400',
  Closed: 'bg-slate-500/20 text-slate-400',
};

const CampCard = ({ camp, onDelete, isAdmin }) => {
  const pct = camp.capacity > 0 ? Math.round((camp.currentOccupancy / camp.capacity) * 100) : 0;
  const barColor = pct >= 100 ? 'bg-rose-500' : pct >= 80 ? 'bg-orange-500' : 'bg-emerald-500';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-all flex flex-col gap-4">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-start gap-3 min-w-0">
          <div className="w-10 h-10 rounded-lg bg-teal-500/10 flex items-center justify-center shrink-0">
            <Tent className="w-5 h-5 text-teal-400" />
          </div>
          <div className="min-w-0">
            <h3 className="font-bold text-white text-sm line-clamp-2 leading-snug">
              {camp.name}
            </h3>
            <div className="flex items-center gap-1 text-xs text-slate-400 mt-1">
              <MapPin className="w-3.5 h-3.5 shrink-0 text-blue-400" />
              <span className="truncate">{camp.location}, {camp.city}</span>
            </div>
          </div>
        </div>
        <span className={`shrink-0 px-2 py-0.5 rounded-full text-[11px] font-bold ${STATUS_STYLES[camp.status] || 'bg-slate-700 text-slate-400'}`}>
          {camp.status}
        </span>
      </div>

      {/* Occupancy Bar */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" /> Occupancy</span>
          <span className="font-semibold text-white">{camp.currentOccupancy} / {camp.capacity}</span>
        </div>
        <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div className={`h-full rounded-full transition-all ${barColor}`} style={{ width: `${Math.min(pct, 100)}%` }} />
        </div>
        <div className="flex items-center justify-between text-[11px] text-slate-400">
          <span>{camp.availableBeds} beds available</span>
          <span>{pct}% capacity</span>
        </div>
      </div>

      {/* Amenities & Contact */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex gap-2">
          {camp.foodAvailable && <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-medium">🍽 Food Available</span>}
          {camp.medicalFacility && <span className="px-2 py-0.5 rounded-full text-[10px] bg-rose-500/20 text-rose-300 font-medium">🏥 Medical Facility</span>}
        </div>
        {camp.contactNumber && (
          <span className="text-[11px] text-slate-400 font-mono">
            Ph: {camp.contactNumber}
          </span>
        )}
      </div>

      {isAdmin && (
        <div className="flex items-center justify-end pt-2 border-t border-slate-800">
          <button
            onClick={() => onDelete(camp._id)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold transition-all cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Remove Camp</span>
          </button>
        </div>
      )}
    </div>
  );
};

const ReliefCamps = () => {
  const { user } = useAuth();
  const [camps, setCamps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ search: '', status: 'all' });

  const isAdmin = user?.role === 'admin';

  const fetchCamps = async () => {
    try {
      setLoading(true);
      const res = await campService.getCamps(filters);
      if (res.data?.success) setCamps(res.data.camps);
    } catch {
      toast.error('Failed to load relief camps');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCamps();
  }, [filters]);

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this relief camp?')) return;
    try {
      await campService.deleteCamp(id);
      toast.success('Camp removed successfully');
      fetchCamps();
    } catch {
      toast.error('Delete failed');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Relief Camps & Shelters</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">{camps.length} registered relief shelter{camps.length !== 1 ? 's' : ''}</p>
        </div>
        {isAdmin && (
          <Link
            to="/camps/create"
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs sm:text-sm font-semibold transition-all shadow-sm w-fit"
          >
            <Plus className="w-4 h-4" /> Add Relief Camp
          </Link>
        )}
      </div>

      {/* Filters */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search by camp name, address, or city..."
            value={filters.search}
            onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
            className="w-full pl-9 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>
        <select
          value={filters.status}
          onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
        >
          <option value="all">All Statuses</option>
          {['Open', 'Full', 'Closed'].map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      {/* Camps Listing */}
      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span className="text-sm">Loading relief camps...</span>
        </div>
      ) : camps.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-48 gap-2 text-slate-500 bg-slate-900 border border-slate-800 rounded-xl p-6">
          <Tent className="w-10 h-10 opacity-30" />
          <p className="text-xs">No relief camps match your search criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {camps.map((c) => (
            <CampCard key={c._id} camp={c} onDelete={handleDelete} isAdmin={isAdmin} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ReliefCamps;
