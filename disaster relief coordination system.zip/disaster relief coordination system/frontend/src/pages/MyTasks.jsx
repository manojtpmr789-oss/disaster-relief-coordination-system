import React, { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  ClipboardList,
  MapPin,
  Phone,
  User,
  Calendar,
  ShieldAlert,
  CheckCircle2,
  Clock,
  PlayCircle,
  RefreshCw,
  AlertTriangle,
  Package,
  Droplets,
  Pill,
  Shield,
  HelpCircle,
  ArrowRight,
} from 'lucide-react';
import { reliefRequestService } from '../services/reliefRequestService';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

// ─── Style maps ──────────────────────────────────────────────────────────────

const PRIORITY_STYLES = {
  Critical: {
    badge: 'bg-rose-500/20 text-rose-400 border border-rose-500/30',
    card: 'border-rose-500/40',
  },
  High: {
    badge: 'bg-orange-500/20 text-orange-400 border border-orange-500/30',
    card: 'border-orange-500/30',
  },
  Medium: {
    badge: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30',
    card: '',
  },
  Low: {
    badge: 'bg-green-500/20 text-green-400 border border-green-500/30',
    card: '',
  },
};

const STATUS_CONFIG = {
  Assigned: { badge: 'bg-violet-500/20 text-violet-400 border border-violet-500/30', label: 'Assigned', Icon: Clock, step: 1 },
  'In Progress': { badge: 'bg-blue-500/20 text-blue-400 border border-blue-500/30', label: 'In Progress', Icon: PlayCircle, step: 2 },
  Completed: { badge: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30', label: 'Completed', Icon: CheckCircle2, step: 3 },
};

const TYPE_ICONS = {
  Food: Package, Water: Droplets, Medicine: Pill,
  Rescue: Shield, Shelter: HelpCircle, Clothing: Package, Other: ClipboardList,
};

// ─── Progress Indicator ──────────────────────────────────────────────────────

const ProgressIndicator = ({ status }) => {
  const steps = ['Assigned', 'In Progress', 'Completed'];
  const currentStep = STATUS_CONFIG[status]?.step || 1;

  return (
    <div className="flex items-center gap-1 mt-2 mb-1">
      {steps.map((step, idx) => {
        const stepNum = idx + 1;
        const isActive = stepNum === currentStep;
        const isDone = stepNum < currentStep;
        return (
          <React.Fragment key={step}>
            <div className="flex flex-col items-center gap-0.5">
              <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${
                isDone ? 'bg-emerald-500 text-white' :
                isActive ? 'bg-blue-500 text-white ring-2 ring-blue-400/30' :
                'bg-slate-700 text-slate-500'
              }`}>
                {isDone ? '✓' : stepNum}
              </div>
              <span className={`text-[9px] font-medium whitespace-nowrap ${
                isDone ? 'text-emerald-400' : isActive ? 'text-blue-400' : 'text-slate-600'
              }`}>{step}</span>
            </div>
            {idx < steps.length - 1 && (
              <div className={`flex-1 h-0.5 mb-3.5 transition-all ${stepNum < currentStep ? 'bg-emerald-500' : 'bg-slate-700'}`} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};

// ─── Task Card ───────────────────────────────────────────────────────────────

const TaskCard = ({ task, onStatusUpdate, updating }) => {
  const TypeIcon = TYPE_ICONS[task.requestType] || TYPE_ICONS.Other;
  const priorityStyle = PRIORITY_STYLES[task.priority] || PRIORITY_STYLES.Medium;
  const statusConfig = STATUS_CONFIG[task.status] || STATUS_CONFIG.Assigned;
  const { Icon: StatusIcon } = statusConfig;

  const isCompleted = task.status === 'Completed';
  const canStartTask = task.status === 'Assigned';
  const canComplete = task.status === 'In Progress';
  const isHighRisk = task.priority === 'Critical' || task.priority === 'High';

  const cardClass = `bg-slate-900 rounded-2xl p-5 flex flex-col gap-3.5 transition-all duration-200 border ${
    isHighRisk ? priorityStyle.card : 'border-slate-800 hover:border-slate-700'
  } ${isCompleted ? 'opacity-75' : ''}`;

  return (
    <div className={cardClass}>
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3 min-w-0">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
            isCompleted ? 'bg-emerald-500/10' : 'bg-violet-500/10'
          }`}>
            <TypeIcon className={`w-5 h-5 ${isCompleted ? 'text-emerald-400' : 'text-violet-400'}`} />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-white text-sm">{task.requestType} Relief Task</span>
              {isHighRisk && (
                <AlertTriangle className={`w-3.5 h-3.5 shrink-0 ${task.priority === 'Critical' ? 'text-rose-400' : 'text-orange-400'}`} />
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {task.requester?.name || 'Unknown Requester'} · {task.city}
            </p>
          </div>
        </div>
        <span className={`shrink-0 px-2.5 py-0.5 rounded-full text-[11px] font-bold ${priorityStyle.badge}`}>
          {task.priority}
        </span>
      </div>

      {/* Description */}
      <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">{task.description}</p>

      {/* Details Grid */}
      <div className="grid grid-cols-2 gap-2.5 text-[11px]">
        <div className="flex items-start gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-sky-400 mt-0.5 shrink-0" />
          <div>
            <p className="text-slate-600 text-[10px]">Location</p>
            <p className="text-slate-300 leading-snug">{task.location}, {task.city}</p>
          </div>
        </div>
        <div className="flex items-start gap-1.5">
          <Phone className="w-3.5 h-3.5 text-teal-400 mt-0.5 shrink-0" />
          <div>
            <p className="text-slate-600 text-[10px]">Contact</p>
            <p className="text-slate-300 leading-snug">{task.contactNumber}</p>
          </div>
        </div>
        {task.requester?.name && (
          <div className="flex items-start gap-1.5">
            <User className="w-3.5 h-3.5 text-violet-400 mt-0.5 shrink-0" />
            <div>
              <p className="text-slate-600 text-[10px]">Requester</p>
              <p className="text-slate-300 leading-snug">{task.requester.name}</p>
            </div>
          </div>
        )}
        <div className="flex items-start gap-1.5">
          <Calendar className="w-3.5 h-3.5 text-slate-500 mt-0.5 shrink-0" />
          <div>
            <p className="text-slate-600 text-[10px]">
              {isCompleted ? 'Completed Date' : 'Assigned Date'}
            </p>
            <p className="text-slate-300 leading-snug">
              {new Date(isCompleted ? (task.updatedAt || task.createdAt) : (task.updatedAt || task.createdAt)).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
            </p>
          </div>
        </div>
      </div>

      {/* Disaster info */}
      {task.disaster && (
        <div className="flex items-center gap-2 px-3 py-2 bg-slate-800/60 rounded-xl border border-slate-700/60 text-[11px]">
          <ShieldAlert className="w-3.5 h-3.5 text-rose-400 shrink-0" />
          <span className="text-slate-400">Disaster:</span>
          <span className="text-white font-semibold truncate">{task.disaster.title || task.disaster.disasterType}</span>
          <span className={`ml-auto shrink-0 px-1.5 py-0.5 rounded text-[10px] font-bold ${
            task.disaster.severity === 'Critical' ? 'bg-rose-500/20 text-rose-400' :
            task.disaster.severity === 'High' ? 'bg-orange-500/20 text-orange-400' :
            'bg-slate-700 text-slate-400'
          }`}>{task.disaster.severity}</span>
        </div>
      )}

      {/* Progress indicator */}
      <ProgressIndicator status={task.status} />

      {/* Status + Actions */}
      <div className="flex items-center justify-between pt-2 border-t border-slate-800 gap-2 flex-wrap">
        <div className="flex items-center gap-1.5">
          <StatusIcon className={`w-3.5 h-3.5 ${
            isCompleted ? 'text-emerald-400' : statusConfig.badge.includes('blue') ? 'text-blue-400' : 'text-violet-400'
          }`} />
          <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${statusConfig.badge}`}>
            {isCompleted ? '✓ Completed' : statusConfig.label}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {canStartTask && (
            <button
              onClick={() => onStatusUpdate(task._id, 'In Progress')}
              disabled={updating === task._id}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-[11px] font-bold transition-all"
            >
              {updating === task._id ? <RefreshCw className="w-3 h-3 animate-spin" /> : <PlayCircle className="w-3.5 h-3.5" />}
              Start Task
            </button>
          )}
          {canComplete && (
            <button
              onClick={() => onStatusUpdate(task._id, 'Completed')}
              disabled={updating === task._id}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-[11px] font-bold transition-all"
            >
              {updating === task._id ? <RefreshCw className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
              Mark Completed
            </button>
          )}
          <Link
            to={`/relief-requests/${task._id}`}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
            title="View Full Details"
          >
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
};

// ─── Main Page ───────────────────────────────────────────────────────────────

const MyTasks = () => {
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [updating, setUpdating] = useState(null);
  const [filter, setFilter] = useState('all');

  const fetchTasks = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      // Fetch fresh data from MongoDB using the dedicated volunteer my-tasks endpoint
      const res = await reliefRequestService.getMyTasks();
      const list = res?.reliefRequests || res?.tasks || res?.data?.reliefRequests || [];
      setTasks(list);
    } catch (err) {
      setError('Failed to load your assigned tasks from server.');
      toast.error(err?.message || 'Failed to load tasks');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const handleStatusUpdate = async (taskId, newStatus) => {
    setUpdating(taskId);
    try {
      // Use dedicated PUT /api/relief-requests/:id/status endpoint
      const res = await reliefRequestService.updateTaskStatus(taskId, newStatus);
      const updated = res?.reliefRequest || res?.data?.reliefRequest;
      if (updated) {
        setTasks((prev) =>
          prev.map((t) => (t._id === taskId ? { ...t, ...updated } : t))
        );
        toast.success(
          newStatus === 'Completed'
            ? 'Relief task marked as Completed!'
            : `Task status updated to "${newStatus}"`
        );
      }
    } catch (err) {
      toast.error(err?.message || 'Failed to update task status');
    } finally {
      setUpdating(null);
    }
  };

  const activeTasks = tasks.filter((t) => ['Assigned', 'In Progress'].includes(t.status));
  const completedTasks = tasks.filter((t) => t.status === 'Completed');

  const counts = {
    all: tasks.length,
    active: activeTasks.length,
    completed: completedTasks.length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">My Tasks</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Relief requests assigned to you — {counts.active} active · {counts.completed} completed
          </p>
        </div>
        <button
          onClick={fetchTasks}
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-all w-fit"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-xl p-1 w-fit">
        {[
          { key: 'all', label: `All (${counts.all})` },
          { key: 'active', label: `Active (${counts.active})` },
          { key: 'completed', label: `Completed (${counts.completed})` },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              filter === tab.key
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Loading state */}
      {loading ? (
        <div className="flex items-center justify-center h-48 gap-3 text-slate-400">
          <RefreshCw className="w-5 h-5 animate-spin text-blue-400" />
          <span className="text-sm">Loading your assigned tasks...</span>
        </div>
      ) : error ? (
        <div className="flex flex-col items-center justify-center h-48 gap-3 text-slate-500">
          <AlertTriangle className="w-10 h-10 text-rose-400 opacity-60" />
          <p className="text-sm text-rose-400">{error}</p>
          <button onClick={fetchTasks} className="text-xs text-blue-400 hover:text-blue-300 font-medium transition-colors">
            Try again
          </button>
        </div>
      ) : tasks.length === 0 ? (
        /* Entirely empty state */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 flex flex-col items-center justify-center text-center gap-3">
          <ClipboardList className="w-12 h-12 text-slate-600 opacity-50" />
          <h3 className="text-sm font-bold text-white">No tasks assigned yet.</h3>
          <p className="text-xs text-slate-500 max-w-sm">
            When an admin assigns you to a relief request, it will appear here. Check back soon.
          </p>
          <Link to="/disasters" className="mt-2 text-xs text-blue-400 hover:text-blue-300 font-medium transition-colors">
            View Active Disasters →
          </Link>
        </div>
      ) : (
        <div className="space-y-8">
          {/* ACTIVE TASKS SECTION */}
          {(filter === 'all' || filter === 'active') && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                <h2 className="text-base font-bold text-white tracking-tight">ACTIVE TASKS</h2>
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400">
                  {activeTasks.length}
                </span>
                <span className="text-xs text-slate-500 ml-auto">Tasks in Assigned or In Progress status</span>
              </div>

              {activeTasks.length === 0 ? (
                <div className="p-6 bg-slate-900/50 border border-slate-800/80 rounded-xl text-center text-xs text-slate-500">
                  No active tasks right now.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                  {activeTasks.map((task) => (
                    <TaskCard key={task._id} task={task} onStatusUpdate={handleStatusUpdate} updating={updating} />
                  ))}
                </div>
              )}
            </div>
          )}

          {/* COMPLETED TASKS SECTION */}
          {(filter === 'all' || filter === 'completed') && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                <h2 className="text-base font-bold text-white tracking-tight">COMPLETED TASKS</h2>
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400">
                  {completedTasks.length}
                </span>
                <span className="text-xs text-slate-500 ml-auto">Finished relief missions</span>
              </div>

              {completedTasks.length === 0 ? (
                <div className="p-6 bg-slate-900/50 border border-slate-800/80 rounded-xl text-center text-xs text-slate-500">
                  No completed tasks yet.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                  {completedTasks.map((task) => (
                    <TaskCard key={task._id} task={task} onStatusUpdate={handleStatusUpdate} updating={updating} />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default MyTasks;
