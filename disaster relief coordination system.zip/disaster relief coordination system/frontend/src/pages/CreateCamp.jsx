import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Tent, ArrowLeft, Loader2, Save, MapPin } from 'lucide-react';
import { campService } from '../services/campService';
import toast from 'react-hot-toast';

const inputCls = 'w-full px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-colors';
const FormGroup = ({ label, required, children }) => (
  <div className="space-y-1.5">
    <label className="block text-xs font-semibold text-slate-300">
      {label} {required && <span className="text-rose-400">*</span>}
    </label>
    {children}
  </div>
);

const CreateCamp = () => {
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    name: '',
    location: '',
    city: '',
    capacity: 100,
    contactNumber: '',
    foodAvailable: false,
    medicalFacility: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((f) => ({ ...f, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.location.trim() || !form.city.trim() || !form.contactNumber.trim()) {
      toast.error('Please fill all required fields');
      return;
    }
    try {
      setSubmitting(true);
      const res = await campService.createCamp(form);
      if (res.data?.success) {
        toast.success('Relief camp created successfully!');
        navigate('/camps');
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create camp');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Link
          to="/camps"
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">Create Relief Camp</h1>
          <p className="text-xs text-slate-400 mt-0.5">Register a new emergency shelter or relief station</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Camp Details */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 space-y-4">
          <h2 className="font-bold text-white text-sm flex items-center gap-2">
            <Tent className="w-4 h-4 text-teal-400" /> Shelter Details
          </h2>

          <FormGroup label="Relief Camp Name" required>
            <input
              name="name"
              value={form.name}
              onChange={handleChange}
              required
              placeholder="e.g. Community Center Evacuation Shelter"
              className={inputCls}
            />
          </FormGroup>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormGroup label="Full Address / Location" required>
              <input
                name="location"
                value={form.location}
                onChange={handleChange}
                required
                placeholder="e.g. 700 School Road, Sector 3"
                className={inputCls}
              />
            </FormGroup>
            <FormGroup label="City / Region" required>
              <input
                name="city"
                value={form.city}
                onChange={handleChange}
                required
                placeholder="e.g. Riverdale"
                className={inputCls}
              />
            </FormGroup>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <FormGroup label="Maximum Capacity (Persons)" required>
              <input
                name="capacity"
                type="number"
                min="1"
                value={form.capacity}
                onChange={handleChange}
                required
                className={inputCls}
              />
            </FormGroup>
            <FormGroup label="Contact Phone Number" required>
              <input
                name="contactNumber"
                value={form.contactNumber}
                onChange={handleChange}
                required
                placeholder="+1 (555) 000-0000"
                className={inputCls}
              />
            </FormGroup>
          </div>

          <div className="flex items-center gap-6 pt-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                name="foodAvailable"
                checked={form.foodAvailable}
                onChange={handleChange}
                className="w-4 h-4 rounded accent-teal-500 cursor-pointer"
              />
              <span className="text-xs text-slate-300">Food Available</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                name="medicalFacility"
                checked={form.medicalFacility}
                onChange={handleChange}
                className="w-4 h-4 rounded accent-rose-500 cursor-pointer"
              />
              <span className="text-xs text-slate-300">Medical Facility Available</span>
            </label>
          </div>
        </div>

        {/* Submit Actions */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <Link
            to="/camps"
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition-all"
          >
            Cancel
          </Link>
          <button
            type="submit"
            disabled={submitting}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 disabled:opacity-60 text-white text-xs font-semibold transition-all shadow-sm cursor-pointer"
          >
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            <span>{submitting ? 'Creating...' : 'Create Relief Camp'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateCamp;
