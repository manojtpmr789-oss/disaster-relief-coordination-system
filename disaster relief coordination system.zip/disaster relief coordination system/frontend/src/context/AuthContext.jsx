import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import authService from '../services/authService';
import userService from '../services/userService';
import toast from 'react-hot-toast';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [token, setToken] = useState(() => localStorage.getItem('token'));
  const [loading, setLoading] = useState(true);

  // Check auth and fetch current user
  const fetchCurrentUser = useCallback(async () => {
    const savedToken = localStorage.getItem('token');
    if (!savedToken) {
      setCurrentUser(null);
      setLoading(false);
      return null;
    }

    try {
      setLoading(true);
      const res = await authService.getMe();
      if (res && res.success && res.user) {
        setCurrentUser(res.user);
        return res.user;
      } else {
        localStorage.removeItem('token');
        setCurrentUser(null);
        return null;
      }
    } catch (error) {
      console.warn('Authentication token verification failed:', error.message);
      localStorage.removeItem('token');
      setCurrentUser(null);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCurrentUser();
  }, [fetchCurrentUser]);

  // Login handler
  const login = async (email, password) => {
    try {
      const res = await authService.login({ email, password });
      if (res.success && res.token) {
        localStorage.setItem('token', res.token);
        setToken(res.token);
        setCurrentUser(res.user);
        toast.success(`Welcome back, ${res.user.name}!`, {
          duration: 4000,
          position: 'top-right',
        });
        return { success: true, user: res.user };
      }
      return { success: false, message: res.message || 'Login failed' };
    } catch (error) {
      const errorMsg = error.message || 'Invalid credentials or server error';
      toast.error(errorMsg);
      return { success: false, message: errorMsg };
    }
  };

  // Register handler
  const register = async (userData) => {
    try {
      const res = await authService.register(userData);
      if (res.success) {
        toast.success('Registration successful! Please log in with your credentials.', {
          duration: 5000,
          position: 'top-right',
        });
        return { success: true, data: res };
      }
      return { success: false, message: res.message || 'Registration failed' };
    } catch (error) {
      const errorMsg = error.message || 'Registration failed';
      toast.error(errorMsg);
      return { success: false, message: errorMsg };
    }
  };

  // Profile update handler
  const updateUserProfile = async (profileData) => {
    try {
      const res = await userService.updateProfile(profileData);
      if (res.success && res.user) {
        setCurrentUser(res.user);
        toast.success('Profile updated successfully!');
        return { success: true, user: res.user };
      }
      return { success: false, message: res.message || 'Update failed' };
    } catch (error) {
      const errorMsg = error.message || 'Failed to update profile';
      toast.error(errorMsg);
      return { success: false, message: errorMsg };
    }
  };

  // Logout handler
  const logout = async () => {
    try {
      await authService.logout().catch(() => {});
    } finally {
      localStorage.removeItem('token');
      setToken(null);
      setCurrentUser(null);
      toast.success('Logged out successfully.');
    }
  };

  const value = {
    currentUser,
    user: currentUser,  // alias for new Part 2 components
    setCurrentUser,
    token,
    loading,
    isAuthenticated: !!currentUser && !!token,
    login,
    register,
    logout,
    updateUserProfile,
    fetchCurrentUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;
