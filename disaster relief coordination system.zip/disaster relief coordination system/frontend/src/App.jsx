import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import DashboardLayout from './layouts/DashboardLayout';
import { Toaster } from 'react-hot-toast';

// Auth Pages
import Login from './pages/Login';
import Register from './pages/Register';
import Unauthorized from './pages/Unauthorized';
import NotFound from './pages/NotFound';

// Core Pages
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import Users from './pages/Users';

// Disaster Module
import DisasterReports from './pages/DisasterReports';
import CreateDisaster from './pages/CreateDisaster';
import DisasterDetails from './pages/DisasterDetails';

// Relief Request Module
import ReliefRequests from './pages/ReliefRequests';
import CreateReliefRequest from './pages/CreateReliefRequest';
import ReliefRequestDetails from './pages/ReliefRequestDetails';

// Volunteer Module
import Volunteers from './pages/Volunteers';
import MyTasks from './pages/MyTasks';

// Resource Module
import Resources from './pages/Resources';

// Donation Module
import Donations from './pages/Donations';

// Notification & Reports
import Notifications from './pages/Notifications';
import Reports from './pages/Reports';

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#0f172a',
              color: '#f1f5f9',
              border: '1px solid #1e293b',
              borderRadius: '12px',
              fontSize: '13px',
            },
            success: { iconTheme: { primary: '#10b981', secondary: '#0f172a' } },
            error: { iconTheme: { primary: '#ef4444', secondary: '#0f172a' } },
          }}
        />
        <Routes>
          {/* Public Routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/unauthorized" element={<Unauthorized />} />

          {/* Protected Routes - wrapped in DashboardLayout */}
          <Route
            element={
              <ProtectedRoute>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/notifications" element={<Notifications />} />

            {/* Admin-only routes */}
            <Route
              path="/users"
              element={
                <ProtectedRoute allowedRoles={['admin']}>
                  <Users />
                </ProtectedRoute>
              }
            />
            <Route
              path="/reports"
              element={
                <ProtectedRoute allowedRoles={['admin']}>
                  <Reports />
                </ProtectedRoute>
              }
            />

            {/* Disaster Module */}
            <Route path="/disasters" element={<DisasterReports />} />
            <Route
              path="/disasters/create"
              element={
                <ProtectedRoute allowedRoles={['admin', 'affected_user']}>
                  <CreateDisaster />
                </ProtectedRoute>
              }
            />
            <Route path="/disasters/:id" element={<DisasterDetails />} />

            {/* Relief Request Module */}
            <Route path="/relief-requests" element={<ReliefRequests />} />
            <Route
              path="/relief-requests/create"
              element={
                <ProtectedRoute allowedRoles={['affected_user', 'admin']}>
                  <CreateReliefRequest />
                </ProtectedRoute>
              }
            />
            <Route path="/relief-requests/:id" element={<ReliefRequestDetails />} />
            {/* Alias for affected_user "my requests" sidebar link */}
            <Route path="/my-requests" element={<ReliefRequests />} />

            {/* Volunteer Module */}
            <Route
              path="/volunteers"
              element={
                <ProtectedRoute allowedRoles={['admin', 'volunteer']}>
                  <Volunteers />
                </ProtectedRoute>
              }
            />
            {/* Volunteer tasks - My Tasks page */}
            <Route
              path="/my-tasks"
              element={
                <ProtectedRoute allowedRoles={['volunteer', 'admin']}>
                  <MyTasks />
                </ProtectedRoute>
              }
            />

            {/* Resource Module */}
            <Route path="/resources" element={<Resources />} />

            {/* Donations Module */}
            <Route path="/donations" element={<Donations />} />
            {/* Alias for donor "my donations" sidebar link */}
            <Route path="/my-donations" element={<Donations />} />
          </Route>

          {/* 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
