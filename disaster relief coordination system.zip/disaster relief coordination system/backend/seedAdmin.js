require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

const seedAdmin = async () => {
  try {
    const mongoUri =
      process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/disaster_relief_db';

    await mongoose.connect(mongoUri);
    console.log(`[Seed Script] Connected to database: ${mongoUri}`);

    const adminEmail = (process.env.ADMIN_EMAIL || 'admin@disasterrelief.org').toLowerCase().trim();
    const adminPassword = process.env.ADMIN_PASSWORD || 'Admin@12345';
    const adminName = process.env.ADMIN_NAME || 'Emergency Coordinator Admin';

    const existingAdmin = await User.findOne({ email: adminEmail });

    if (existingAdmin) {
      console.log(`[Seed Script] Admin user '${adminEmail}' already exists (Role: ${existingAdmin.role}). Updating to ensure admin privileges.`);
      existingAdmin.role = 'admin';
      existingAdmin.name = adminName;
      existingAdmin.phone = existingAdmin.phone || '+1 (555) 019-2834';
      existingAdmin.city = existingAdmin.city || 'Command HQ';
      existingAdmin.address = existingAdmin.address || 'Emergency Response Center, Sector 4';
      existingAdmin.availability = 'available';
      if (!existingAdmin.skills || existingAdmin.skills.length === 0) {
        existingAdmin.skills = ['Crisis Coordination', 'Disaster Response', 'Resource Logistics'];
      }
      await existingAdmin.save();
      console.log('[Seed Script] Admin account verified and updated successfully.');
    } else {
      await User.create({
        name: adminName,
        email: adminEmail,
        password: adminPassword,
        phone: '+1 (555) 019-2834',
        address: 'Emergency Response Center, Sector 4',
        city: 'Command HQ',
        role: 'admin',
        skills: ['Crisis Coordination', 'Disaster Response', 'Resource Logistics'],
        availability: 'available',
      });
      console.log(`[Seed Script] Created default Administrator account successfully.`);
      console.log(`  -> Email: ${adminEmail}`);
      console.log(`  -> Password: ${adminPassword}`);
      console.log(`  -> Role: admin`);
    }

    // Also let's optionally seed one demo volunteer and one demo affected user for rich demo experience if not existing
    const demoVolunteerEmail = 'volunteer@disasterrelief.org';
    const existingVolunteer = await User.findOne({ email: demoVolunteerEmail });
    if (!existingVolunteer) {
      await User.create({
        name: 'Sarah Connor (First Responder)',
        email: demoVolunteerEmail,
        password: 'Volunteer@12345',
        phone: '+1 (555) 043-9821',
        address: '142 Shelter Avenue',
        city: 'Metropolis',
        role: 'volunteer',
        skills: ['First Aid / CPR', 'Search & Rescue', 'Emergency Driving'],
        availability: 'available',
      });
      console.log(`[Seed Script] Seeded demo volunteer: ${demoVolunteerEmail} / Volunteer@12345`);
    }

    const demoAffectedEmail = 'resident@disasterrelief.org';
    const existingAffected = await User.findOne({ email: demoAffectedEmail });
    if (!existingAffected) {
      await User.create({
        name: 'David Miller (Resident)',
        email: demoAffectedEmail,
        password: 'Resident@12345',
        phone: '+1 (555) 078-4312',
        address: '89 Riverside Boulevard, Zone B',
        city: 'Riverdale',
        role: 'affected_user',
        skills: [],
        availability: 'available',
      });
      console.log(`[Seed Script] Seeded demo affected user: ${demoAffectedEmail} / Resident@12345`);
    }

    const demoDonorEmail = 'donor@disasterrelief.org';
    const existingDonor = await User.findOne({ email: demoDonorEmail });
    if (!existingDonor) {
      await User.create({
        name: 'Global Aid Foundation (Donor)',
        email: demoDonorEmail,
        password: 'Donor@12345',
        phone: '+1 (555) 091-1122',
        address: '500 Philanthropy Way, Suite 100',
        city: 'Capital City',
        role: 'donor',
        skills: ['Medical Supplies Funding', 'Food Rations Aid'],
        availability: 'available',
      });
      console.log(`[Seed Script] Seeded demo donor: ${demoDonorEmail} / Donor@12345`);
    }

    await mongoose.connection.close();
    console.log('[Seed Script] Database seed process complete.');
    process.exit(0);
  } catch (error) {
    console.error(`[Seed Script Error]: ${error.message}`);
    process.exit(1);
  }
};

seedAdmin();
