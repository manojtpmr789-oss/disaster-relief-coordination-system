const testPart2Apis = async () => {
  const baseUrl = 'http://localhost:5000/api';
  console.log('=== RUNNING PART 2 BACKEND API VALIDATION SUITE ===\n');

  try {
    // 1. Admin Login
    const adminLogin = await fetch(`${baseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'admin@disasterrelief.org', password: 'Admin@12345' }),
    }).then((r) => r.json());
    const adminToken = adminLogin.token;

    // 2. Affected User Login
    const userLogin = await fetch(`${baseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'resident@disasterrelief.org', password: 'Resident@12345' }),
    }).then((r) => r.json());
    const userToken = userLogin.token;

    // 3. Disasters APIs
    const disastersRes = await fetch(`${baseUrl}/disasters`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log('✔ GET /api/disasters:', disastersRes.success && disastersRes.disasters.length >= 4 ? 'PASSED' : 'FAILED');

    // 4. Relief Requests APIs
    const requestsRes = await fetch(`${baseUrl}/relief-requests`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log('✔ GET /api/relief-requests:', requestsRes.success && requestsRes.reliefRequests.length >= 4 ? 'PASSED' : 'FAILED');

    // 5. Volunteers APIs
    const volunteersRes = await fetch(`${baseUrl}/volunteers`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log('✔ GET /api/volunteers:', volunteersRes.success && volunteersRes.volunteers.length >= 1 ? 'PASSED' : 'FAILED');

    // 6. Resources APIs
    const resourcesRes = await fetch(`${baseUrl}/resources`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log('✔ GET /api/resources:', resourcesRes.success && resourcesRes.resources.length >= 6 ? 'PASSED' : 'FAILED');

    // 7. Relief Camps APIs
    const campsRes = await fetch(`${baseUrl}/camps`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log('✔ GET /api/camps:', campsRes.success && campsRes.camps.length >= 3 ? 'PASSED' : 'FAILED');

    // 8. Donations APIs
    const donationsRes = await fetch(`${baseUrl}/donations`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log('✔ GET /api/donations:', donationsRes.success && donationsRes.donations.length >= 4 ? 'PASSED' : 'FAILED');

    // 9. Notifications APIs
    const notifsRes = await fetch(`${baseUrl}/notifications`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log('✔ GET /api/notifications:', notifsRes.success && notifsRes.unreadCount >= 0 ? 'PASSED' : 'FAILED');

    // 10. Dashboard Stats & Analytics
    const dashRes = await fetch(`${baseUrl}/dashboard/stats`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log(
      '✔ GET /api/dashboard/stats (Aggregated Metrics & Charts):',
      dashRes.success && dashRes.metrics.totalDisasters > 0 && dashRes.charts.disastersByType.length > 0
        ? 'PASSED'
        : 'FAILED'
    );

    // 11. Reports Summary API
    const reportRes = await fetch(`${baseUrl}/reports/summary?module=disasters`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log('✔ GET /api/reports/summary:', reportRes.success && reportRes.reportData.length > 0 ? 'PASSED' : 'FAILED');

    console.log('\n=== ALL 11 PART 2 API ENDPOINTS VERIFIED SUCCESSFULLY! ===\n');
  } catch (err) {
    console.error('API Verification error:', err);
  }
};

testPart2Apis();
