const mongoose = require('mongoose');
require('dotenv').config();

const User = require('./models/User');
const Volunteer = require('./models/Volunteer');
const ReliefRequest = require('./models/ReliefRequest');
const Notification = require('./models/Notification');

const runTestFlow = async () => {
  console.log('================================================================');
  console.log('🧪 RUNNING END-TO-END TEST: ASSIGN VOLUNTEER & MY TASKS FLOW');
  console.log('================================================================');

  const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/disaster_relief_db';
  await mongoose.connect(mongoUri);
  console.log('✔ MongoDB Connected');

  const baseUrl = 'http://localhost:5000/api';
  const timestamp = Date.now();

  // -------------------------------------------------------------
  // STEP 1: Register a new user with role volunteer
  // -------------------------------------------------------------
  console.log('\n--- STEP 1: Register New Volunteer ---');
  const volunteerPayload = {
    name: `Sarah Connor ${timestamp.toString().slice(-4)}`,
    email: `sarah_${timestamp}@metropolisrelief.org`,
    password: 'Volunteer@12345',
    phone: '+1 (555) 019-2834',
    address: '456 Industrial Boulevard',
    city: 'Metropolis',
    role: 'volunteer',
    skills: ['First Aid', 'Search & Rescue'],
    availability: 'available',
    emergencyContact: '+1 (555) 999-0000',
  };

  const regRes = await fetch(`${baseUrl}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(volunteerPayload),
  }).then((r) => r.json());

  if (!regRes.success || !regRes.user) {
    throw new Error(`Volunteer registration failed: ${JSON.stringify(regRes)}`);
  }
  const volunteerUserId = regRes.user._id || regRes.user.id;
  console.log(`✔ Volunteer registered successfully! User ID: ${volunteerUserId}`);

  // Verify in MongoDB
  const volunteerUserInDb = await User.findById(volunteerUserId);
  if (!volunteerUserInDb || volunteerUserInDb.role !== 'volunteer') {
    throw new Error('User role in MongoDB is not "volunteer"');
  }
  console.log(`✔ User exists in MongoDB with role: "${volunteerUserInDb.role}"`);

  // -------------------------------------------------------------
  // STEP 2: Login as Admin
  // -------------------------------------------------------------
  console.log('\n--- STEP 2: Login as Admin ---');
  const adminLoginRes = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: 'admin@disasterrelief.org',
      password: 'Admin@12345',
    }),
  }).then((r) => r.json());

  if (!adminLoginRes.success || !adminLoginRes.token) {
    throw new Error(`Admin login failed: ${JSON.stringify(adminLoginRes)}`);
  }
  const adminToken = adminLoginRes.token;
  console.log('✔ Admin logged in successfully');

  // -------------------------------------------------------------
  // STEP 3: Create / Identify a pending relief request
  // -------------------------------------------------------------
  console.log('\n--- STEP 3: Ensure Pending Relief Request Exists ---');
  let reliefRequest = await ReliefRequest.findOne({ status: 'Pending' });
  if (!reliefRequest) {
    reliefRequest = await ReliefRequest.create({
      requester: volunteerUserId,
      requestType: 'Medicine',
      description: 'Emergency antibiotics and insulin needed for stranded clinic patients.',
      quantity: 15,
      priority: 'High',
      location: 'Metropolis General Outpost 4',
      city: 'Metropolis',
      contactNumber: '+1 (555) 321-4567',
      status: 'Pending',
    });
    console.log(`✔ Created fresh pending relief request: ${reliefRequest._id}`);
  } else {
    console.log(`✔ Found existing pending relief request: ${reliefRequest._id}`);
  }

  // -------------------------------------------------------------
  // STEP 4: Admin fetches registered volunteers list (GET /api/volunteers)
  // -------------------------------------------------------------
  console.log('\n--- STEP 4: Admin Fetches Registered Volunteers ---');
  const volunteersListRes = await fetch(`${baseUrl}/volunteers`, {
    headers: { Authorization: `Bearer ${adminToken}` },
  }).then((r) => r.json());

  if (!volunteersListRes.success || !Array.isArray(volunteersListRes.volunteers)) {
    throw new Error(`Failed to fetch volunteers list: ${JSON.stringify(volunteersListRes)}`);
  }

  const foundInList = volunteersListRes.volunteers.find(
    (v) => (v.user?._id || v.user?.id || v._id) === volunteerUserId.toString()
  );
  if (!foundInList) {
    throw new Error(`Newly registered volunteer ${volunteerUserId} not found in Admin volunteers list!`);
  }
  console.log(`✔ Newly registered volunteer found in Admin dropdown list: ${foundInList.user?.name || foundInList.name}`);

  // -------------------------------------------------------------
  // STEP 5: Admin assigns relief request to volunteer (PUT /api/relief-requests/:id/assign)
  // -------------------------------------------------------------
  console.log('\n--- STEP 5: Admin Assigns Volunteer to Relief Request ---');
  const assignRes = await fetch(`${baseUrl}/relief-requests/${reliefRequest._id}/assign`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${adminToken}`,
    },
    body: JSON.stringify({
      volunteerId: volunteerUserId,
    }),
  });

  const assignData = await assignRes.json();
  if (assignRes.status !== 200 || !assignData.success) {
    throw new Error(`Assign API failed (${assignRes.status}): ${JSON.stringify(assignData)}`);
  }
  console.log('✔ Assign volunteer API returned 200 OK');

  // -------------------------------------------------------------
  // STEP 6: Verify in MongoDB: assignedVolunteer & status
  // -------------------------------------------------------------
  console.log('\n--- STEP 6: Verify MongoDB State After Assignment ---');
  const updatedRequestInDb = await ReliefRequest.findById(reliefRequest._id);
  if (!updatedRequestInDb.assignedVolunteer) {
    throw new Error('assignedVolunteer is null in MongoDB!');
  }
  if (updatedRequestInDb.assignedVolunteer.toString() !== volunteerUserId.toString()) {
    throw new Error(
      `assignedVolunteer (${updatedRequestInDb.assignedVolunteer}) does NOT match volunteer User ID (${volunteerUserId})!`
    );
  }
  if (updatedRequestInDb.status !== 'Assigned') {
    throw new Error(`Status in MongoDB is "${updatedRequestInDb.status}", expected "Assigned"!`);
  }
  console.log(`✔ MongoDB ReliefRequest.assignedVolunteer = ${updatedRequestInDb.assignedVolunteer}`);
  console.log(`✔ MongoDB ReliefRequest.status = "${updatedRequestInDb.status}"`);

  // Verify Notification
  const notificationInDb = await Notification.findOne({
    recipient: volunteerUserId,
    relatedId: reliefRequest._id.toString(),
  });
  console.log('✔ In-app notification created in MongoDB for volunteer:', !!notificationInDb);

  // -------------------------------------------------------------
  // STEP 7: Volunteer Login
  // -------------------------------------------------------------
  console.log('\n--- STEP 7: Volunteer Login ---');
  const volunteerLoginRes = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: volunteerPayload.email,
      password: volunteerPayload.password,
    }),
  }).then((r) => r.json());

  if (!volunteerLoginRes.success || !volunteerLoginRes.token) {
    throw new Error(`Volunteer login failed: ${JSON.stringify(volunteerLoginRes)}`);
  }
  const volunteerToken = volunteerLoginRes.token;
  console.log('✔ Volunteer logged in successfully');

  // -------------------------------------------------------------
  // STEP 8: Volunteer fetches My Tasks (GET /api/relief-requests/my-tasks)
  // -------------------------------------------------------------
  console.log('\n--- STEP 8: Volunteer Calls GET /api/relief-requests/my-tasks ---');
  const myTasksRes = await fetch(`${baseUrl}/relief-requests/my-tasks`, {
    headers: { Authorization: `Bearer ${volunteerToken}` },
  });
  const myTasksData = await myTasksRes.json();

  if (myTasksRes.status !== 200 || !myTasksData.success) {
    throw new Error(`My Tasks API failed (${myTasksRes.status}): ${JSON.stringify(myTasksData)}`);
  }

  const tasksList = myTasksData.reliefRequests || myTasksData.tasks || [];
  const assignedTask = tasksList.find((t) => t._id.toString() === reliefRequest._id.toString());

  if (!assignedTask) {
    throw new Error(`CRITICAL: Assigned request ${reliefRequest._id} did NOT appear in My Tasks!`);
  }
  console.log(`✔ Assigned task appeared in My Tasks! (Total tasks: ${tasksList.length})`);
  console.log(`  Task Type: ${assignedTask.requestType}`);
  console.log(`  Priority: ${assignedTask.priority}`);
  console.log(`  Status: ${assignedTask.status}`);

  // -------------------------------------------------------------
  // STEP 9: Check Volunteer Dashboard Counts (GET /api/dashboard/volunteer-stats)
  // -------------------------------------------------------------
  console.log('\n--- STEP 9: Volunteer Dashboard Stats (Status: Assigned) ---');
  const dashStatsRes = await fetch(`${baseUrl}/dashboard/volunteer-stats`, {
    headers: { Authorization: `Bearer ${volunteerToken}` },
  }).then((r) => r.json());

  console.log('  Assigned To Me:', dashStatsRes.metrics?.assignedToMe);
  console.log('  Completed By Me:', dashStatsRes.metrics?.completedByMe);

  if (dashStatsRes.metrics?.assignedToMe < 1) {
    throw new Error(`Expected assignedToMe >= 1, got ${dashStatsRes.metrics?.assignedToMe}`);
  }

  // -------------------------------------------------------------
  // STEP 10: Volunteer updates task: Assigned -> In Progress
  // -------------------------------------------------------------
  console.log('\n--- STEP 10: Volunteer Changes Status: Assigned -> In Progress ---');
  const inProgressRes = await fetch(`${baseUrl}/relief-requests/${reliefRequest._id}/status`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${volunteerToken}`,
    },
    body: JSON.stringify({ status: 'In Progress' }),
  });
  const inProgressData = await inProgressRes.json();

  if (inProgressRes.status !== 200 || !inProgressData.success) {
    throw new Error(`Update to In Progress failed: ${JSON.stringify(inProgressData)}`);
  }
  const inProgressDb = await ReliefRequest.findById(reliefRequest._id);
  if (inProgressDb.status !== 'In Progress') {
    throw new Error(`MongoDB status is not "In Progress", got: ${inProgressDb.status}`);
  }
  console.log('✔ Relief request updated to "In Progress" in MongoDB');

  // -------------------------------------------------------------
  // STEP 11: Volunteer updates task: In Progress -> Completed
  // -------------------------------------------------------------
  console.log('\n--- STEP 11: Volunteer Changes Status: In Progress -> Completed ---');
  const completedRes = await fetch(`${baseUrl}/relief-requests/${reliefRequest._id}/status`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${volunteerToken}`,
    },
    body: JSON.stringify({ status: 'Completed' }),
  });
  const completedData = await completedRes.json();

  if (completedRes.status !== 200 || !completedData.success) {
    throw new Error(`Update to Completed failed: ${JSON.stringify(completedData)}`);
  }
  const completedDb = await ReliefRequest.findById(reliefRequest._id);
  if (completedDb.status !== 'Completed') {
    throw new Error(`MongoDB status is not "Completed", got: ${completedDb.status}`);
  }
  console.log('✔ Relief request updated to "Completed" in MongoDB');

  // -------------------------------------------------------------
  // STEP 12: Verify Volunteer Dashboard Counts After Completion
  // -------------------------------------------------------------
  console.log('\n--- STEP 12: Verify Volunteer Dashboard Counts After Completion ---');
  const finalDashStats = await fetch(`${baseUrl}/dashboard/volunteer-stats`, {
    headers: { Authorization: `Bearer ${volunteerToken}` },
  }).then((r) => r.json());

  console.log('  Assigned To Me (expected 0):', finalDashStats.metrics?.assignedToMe);
  console.log('  Completed By Me (expected >= 1):', finalDashStats.metrics?.completedByMe);

  if (finalDashStats.metrics?.completedByMe < 1) {
    throw new Error(`Expected completedByMe >= 1, got ${finalDashStats.metrics?.completedByMe}`);
  }

  // -------------------------------------------------------------
  // STEP 13: Volunteer Authorization Safety Check (Forbidden update)
  // -------------------------------------------------------------
  console.log('\n--- STEP 13: Security Check - Forbidden Update by Unauthorized User ---');
  const otherRequest = await ReliefRequest.create({
    requester: volunteerUserId,
    requestType: 'Water',
    description: 'Fresh drinking water bottles',
    quantity: 10,
    priority: 'Low',
    location: 'Zone 9',
    city: 'Metropolis',
    contactNumber: '+1 555-999-8888',
    status: 'Assigned',
    assignedVolunteer: new mongoose.Types.ObjectId(), // completely different ID
  });

  const forbiddenRes = await fetch(`${baseUrl}/relief-requests/${otherRequest._id}/status`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${volunteerToken}`,
    },
    body: JSON.stringify({ status: 'In Progress' }),
  });

  if (forbiddenRes.status !== 403) {
    throw new Error(`Expected 403 Forbidden for unauthorized volunteer, got: ${forbiddenRes.status}`);
  }
  console.log('✔ Unauthorized status update rejected with 403 Forbidden as expected');

  // Clean up otherRequest
  await ReliefRequest.findByIdAndDelete(otherRequest._id);

  console.log('\n================================================================');
  console.log('🎉 ALL 15 END-TO-END FLOW CHECKS PASSED PERFECTLY!');
  console.log('================================================================');

  await mongoose.disconnect();
  process.exit(0);
};

runTestFlow().catch((err) => {
  console.error('\n❌ TEST FAILED:', err.message);
  process.exit(1);
});
