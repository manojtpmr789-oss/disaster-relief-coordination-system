const Resource = require('../models/Resource');
const createNotification = require('../utils/createNotification');

// @desc    Create new inventory resource
// @route   POST /api/resources
// @access  Private (Admin / Coordinator)
const createResource = async (req, res, next) => {
  try {
    const {
      name,
      category,
      quantity,
      unit,
      location,
      city,
      minimumStock,
      expiryDate,
      donatedBy,
    } = req.body;

    if (!name || !category || quantity === undefined || !location || !city) {
      return res.status(400).json({
        success: false,
        message: 'Please provide required fields: name, category, quantity, location, and city',
      });
    }

    const resource = await Resource.create({
      name: name.trim(),
      category,
      quantity: Number(quantity),
      unit: unit ? unit.trim() : 'units',
      location: location.trim(),
      city: city.trim(),
      minimumStock: minimumStock !== undefined ? Number(minimumStock) : 10,
      expiryDate: expiryDate || null,
      donatedBy: donatedBy ? donatedBy.trim() : 'Emergency Relief Reserve',
    });

    return res.status(201).json({
      success: true,
      message: 'Resource stock recorded successfully',
      resource,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all resources with search & filters
// @route   GET /api/resources
// @access  Private
const getResources = async (req, res, next) => {
  try {
    const { search, category, status, city } = req.query;

    const query = {};

    if (category && category !== 'all') {
      query.category = category;
    }
    if (status && status !== 'all') {
      query.status = status;
    }
    if (city && city !== 'all') {
      query.city = new RegExp(city.trim(), 'i');
    }

    if (search && search.trim() !== '') {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { name: searchRegex },
        { location: searchRegex },
        { city: searchRegex },
        { donatedBy: searchRegex },
      ];
    }

    const resources = await Resource.find(query).sort({ createdAt: -1 });

    // Stock metrics summary
    const [totalResources, lowStockCount, outOfStockCount] = await Promise.all([
      Resource.countDocuments(),
      Resource.countDocuments({ status: 'Low Stock' }),
      Resource.countDocuments({ status: 'Out of Stock' }),
    ]);

    return res.status(200).json({
      success: true,
      count: resources.length,
      summary: {
        totalResources,
        lowStockCount,
        outOfStockCount,
        availableCount: totalResources - lowStockCount - outOfStockCount,
      },
      resources,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single resource by ID
// @route   GET /api/resources/:id
// @access  Private
const getResourceById = async (req, res, next) => {
  try {
    const resource = await Resource.findById(req.params.id);

    if (!resource) {
      return res.status(404).json({
        success: false,
        message: 'Resource item not found',
      });
    }

    return res.status(200).json({
      success: true,
      resource,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update resource details
// @route   PUT /api/resources/:id
// @access  Private
const updateResource = async (req, res, next) => {
  try {
    const resource = await Resource.findById(req.params.id);

    if (!resource) {
      return res.status(404).json({
        success: false,
        message: 'Resource not found',
      });
    }

    const {
      name,
      category,
      quantity,
      unit,
      location,
      city,
      minimumStock,
      expiryDate,
      donatedBy,
    } = req.body;

    if (name !== undefined) resource.name = name.trim();
    if (category !== undefined) resource.category = category;
    if (quantity !== undefined) resource.quantity = Number(quantity);
    if (unit !== undefined) resource.unit = unit.trim();
    if (location !== undefined) resource.location = location.trim();
    if (city !== undefined) resource.city = city.trim();
    if (minimumStock !== undefined) resource.minimumStock = Number(minimumStock);
    if (expiryDate !== undefined) resource.expiryDate = expiryDate;
    if (donatedBy !== undefined) resource.donatedBy = donatedBy.trim();

    const updated = await resource.save();

    // Check if stock is low or out
    if (updated.status === 'Low Stock' || updated.status === 'Out of Stock') {
      await createNotification({
        notifyAdmins: true,
        title: `⚠️ Resource Alert: ${updated.name} (${updated.status})`,
        message: `Current stock at ${updated.quantity} ${updated.unit} (Minimum threshold: ${updated.minimumStock}). Storage: ${updated.location}, ${updated.city}.`,
        type: 'Resource',
        relatedId: updated._id,
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Resource inventory updated successfully',
      resource: updated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Adjust quantity / distribute stock
// @route   PUT /api/resources/:id/quantity
// @access  Private
const updateResourceQuantity = async (req, res, next) => {
  try {
    const { action, amount } = req.body; // action: 'add' or 'deduct' or 'set'
    const resource = await Resource.findById(req.params.id);

    if (!resource) {
      return res.status(404).json({ success: false, message: 'Resource not found' });
    }

    const changeAmount = Number(amount) || 0;

    if (action === 'add') {
      resource.quantity += changeAmount;
    } else if (action === 'deduct') {
      if (resource.quantity < changeAmount) {
        return res.status(400).json({
          success: false,
          message: `Cannot deduct ${changeAmount} ${resource.unit}. Available stock is only ${resource.quantity} ${resource.unit}.`,
        });
      }
      resource.quantity = Math.max(0, resource.quantity - changeAmount);
    } else if (action === 'set') {
      resource.quantity = Math.max(0, changeAmount);
    }

    const updated = await resource.save();

    if (updated.status === 'Low Stock' || updated.status === 'Out of Stock') {
      await createNotification({
        notifyAdmins: true,
        title: `⚠️ Low Stock Warning: ${updated.name}`,
        message: `Inventory reduced to ${updated.quantity} ${updated.unit} at ${updated.city}.`,
        type: 'Resource',
        relatedId: updated._id,
      });
    }

    return res.status(200).json({
      success: true,
      message: `Stock quantity updated to ${updated.quantity} ${updated.unit}`,
      resource: updated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete resource item
// @route   DELETE /api/resources/:id
// @access  Private (Admin only)
const deleteResource = async (req, res, next) => {
  try {
    const resource = await Resource.findById(req.params.id);

    if (!resource) {
      return res.status(404).json({
        success: false,
        message: 'Resource not found',
      });
    }

    await Resource.findByIdAndDelete(req.params.id);

    return res.status(200).json({
      success: true,
      message: 'Resource item removed from database',
      deletedId: req.params.id,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createResource,
  getResources,
  getResourceById,
  updateResource,
  updateResourceQuantity,
  deleteResource,
};
