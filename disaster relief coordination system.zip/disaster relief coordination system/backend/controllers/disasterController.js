const mongoose = require('mongoose');
const Disaster = require('../models/Disaster');

// @desc    Create a new disaster report
// @route   POST /api/disasters
// @access  Private (Authenticated users: affected_user, volunteer, admin)
const createDisaster = async (req, res, next) => {
  try {
    const {
      title,
      disasterType,
      description,
      location,
      city,
      severity,
      latitude,
      longitude,
      images,
    } = req.body;

    // Validate required fields
    if (!title || !title.trim()) {
      return res.status(400).json({ success: false, message: 'Incident title is required' });
    }
    if (!disasterType) {
      return res.status(400).json({ success: false, message: 'Disaster type is required' });
    }
    if (!description || !description.trim()) {
      return res.status(400).json({ success: false, message: 'Description is required' });
    }
    if (!location || !location.trim()) {
      return res.status(400).json({ success: false, message: 'Location is required' });
    }
    if (!city || !city.trim()) {
      return res.status(400).json({ success: false, message: 'City is required' });
    }
    if (!severity) {
      return res.status(400).json({ success: false, message: 'Severity level is required' });
    }

    const validDisasterTypes = [
      'Flood',
      'Earthquake',
      'Cyclone',
      'Landslide',
      'Fire',
      'Tsunami',
      'Drought',
      'Other',
    ];
    if (!validDisasterTypes.includes(disasterType)) {
      return res.status(400).json({
        success: false,
        message: `Invalid disaster type. Must be one of: ${validDisasterTypes.join(', ')}`,
      });
    }

    const validSeverities = ['Low', 'Medium', 'High', 'Critical'];
    if (!validSeverities.includes(severity)) {
      return res.status(400).json({
        success: false,
        message: `Invalid severity level. Must be one of: ${validSeverities.join(', ')}`,
      });
    }

    // Ensure authenticated user exists
    if (!req.user || !req.user._id) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required. Please log in to submit a report.',
      });
    }

    // Only admin and affected_user can create disaster reports; volunteers cannot
    if (req.user.role === 'volunteer') {
      return res.status(403).json({
        success: false,
        message: 'Volunteers are not authorized to create disaster reports. Please contact an admin.',
      });
    }

    // Parse optional numeric coordinates
    let lat = null;
    let lng = null;
    if (latitude !== undefined && latitude !== null && latitude !== '') {
      const parsedLat = Number(latitude);
      if (isNaN(parsedLat) || parsedLat < -90 || parsedLat > 90) {
        return res.status(400).json({ success: false, message: 'Latitude must be between -90 and 90' });
      }
      lat = parsedLat;
    }
    if (longitude !== undefined && longitude !== null && longitude !== '') {
      const parsedLng = Number(longitude);
      if (isNaN(parsedLng) || parsedLng < -180 || parsedLng > 180) {
        return res.status(400).json({ success: false, message: 'Longitude must be between -180 and 180' });
      }
      lng = parsedLng;
    }

    const newDisaster = await Disaster.create({
      title: title.trim(),
      disasterType,
      description: description.trim(),
      location: location.trim(),
      city: city.trim(),
      severity,
      latitude: lat,
      longitude: lng,
      images: Array.isArray(images) ? images : [],
      reportedBy: req.user._id,
      status: 'Pending',
    });

    const populatedDisaster = await Disaster.findById(newDisaster._id).populate(
      'reportedBy',
      'name email role'
    );

    return res.status(201).json({
      success: true,
      message: 'Disaster report submitted successfully',
      disaster: populatedDisaster,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all disaster reports with optional filtering & search
// @route   GET /api/disasters
// @access  Private (Authenticated users)
const getDisasters = async (req, res, next) => {
  try {
    const { search, type, disasterType, severity, status, city, page, limit } = req.query;

    const query = {};

    // Search filter across title, description, city, and location
    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { title: searchRegex },
        { description: searchRegex },
        { city: searchRegex },
        { location: searchRegex },
      ];
    }

    // Type filter
    const selectedType = type || disasterType;
    if (selectedType && selectedType !== 'all') {
      query.disasterType = selectedType;
    }

    // Severity filter
    if (severity && severity !== 'all') {
      query.severity = severity;
    }

    // Status filter
    if (status && status !== 'all') {
      query.status = status;
    }

    // City filter
    if (city && city !== 'all') {
      query.city = new RegExp(`^${city.trim()}$`, 'i');
    }

    const total = await Disaster.countDocuments(query);

    let queryBuilder = Disaster.find(query)
      .populate('reportedBy', 'name email role')
      .sort({ createdAt: -1 });

    if (page && limit) {
      const pageNum = parseInt(page, 10) || 1;
      const limitNum = parseInt(limit, 10) || 10;
      queryBuilder = queryBuilder.skip((pageNum - 1) * limitNum).limit(limitNum);
    }

    const disasters = await queryBuilder;

    return res.status(200).json({
      success: true,
      count: disasters.length,
      total,
      disasters,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get a single disaster report by ID
// @route   GET /api/disasters/:id
// @access  Private (Authenticated users)
const getDisasterById = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({
        success: false,
        message: 'Disaster report not found',
      });
    }

    const disaster = await Disaster.findById(id).populate('reportedBy', 'name email role');

    if (!disaster) {
      return res.status(404).json({
        success: false,
        message: 'Disaster report not found',
      });
    }

    return res.status(200).json({
      success: true,
      disaster,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update a disaster report
// @route   PUT /api/disasters/:id
// @access  Private (Admin, Volunteer, or Reporter)
const updateDisaster = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({
        success: false,
        message: 'Disaster report not found',
      });
    }

    const disaster = await Disaster.findById(id);
    if (!disaster) {
      return res.status(404).json({
        success: false,
        message: 'Disaster report not found',
      });
    }

    // Role check: Only admin, volunteer, or the reporter can update
    const isReporter = disaster.reportedBy && disaster.reportedBy.toString() === req.user._id.toString();
    const isAdminOrVolunteer = ['admin', 'volunteer'].includes(req.user.role);

    if (!isReporter && !isAdminOrVolunteer) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this disaster report',
      });
    }

    const {
      title,
      disasterType,
      description,
      location,
      city,
      severity,
      status,
      latitude,
      longitude,
      images,
    } = req.body;

    const updates = {};

    if (title !== undefined) updates.title = title.trim();
    if (description !== undefined) updates.description = description.trim();
    if (location !== undefined) updates.location = location.trim();
    if (city !== undefined) updates.city = city.trim();

    if (disasterType !== undefined) {
      const validTypes = ['Flood', 'Earthquake', 'Cyclone', 'Landslide', 'Fire', 'Tsunami', 'Drought', 'Other'];
      if (!validTypes.includes(disasterType)) {
        return res.status(400).json({ success: false, message: 'Invalid disaster type' });
      }
      updates.disasterType = disasterType;
    }

    if (severity !== undefined) {
      const validSeverities = ['Low', 'Medium', 'High', 'Critical'];
      if (!validSeverities.includes(severity)) {
        return res.status(400).json({ success: false, message: 'Invalid severity level' });
      }
      updates.severity = severity;
    }

    if (status !== undefined) {
      const validStatuses = ['Pending', 'Verified', 'Active', 'Resolved'];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ success: false, message: 'Invalid status' });
      }
      updates.status = status;
    }

    if (latitude !== undefined) {
      updates.latitude = latitude === '' || latitude === null ? null : Number(latitude);
    }

    if (longitude !== undefined) {
      updates.longitude = longitude === '' || longitude === null ? null : Number(longitude);
    }

    if (images !== undefined) {
      updates.images = Array.isArray(images) ? images : disaster.images;
    }

    const updatedDisaster = await Disaster.findByIdAndUpdate(
      id,
      { $set: updates },
      { new: true, runValidators: true }
    ).populate('reportedBy', 'name email role');

    return res.status(200).json({
      success: true,
      message: 'Disaster report updated successfully',
      disaster: updatedDisaster,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a disaster report
// @route   DELETE /api/disasters/:id
// @access  Private (Admin or Original Reporter)
const deleteDisaster = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({
        success: false,
        message: 'Disaster report not found',
      });
    }

    const disaster = await Disaster.findById(id);
    if (!disaster) {
      return res.status(404).json({
        success: false,
        message: 'Disaster report not found',
      });
    }

    const isReporter = disaster.reportedBy && disaster.reportedBy.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';

    if (!isReporter && !isAdmin) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this disaster report',
      });
    }

    await Disaster.findByIdAndDelete(id);

    return res.status(200).json({
      success: true,
      message: 'Disaster report deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createDisaster,
  getDisasters,
  getDisasterById,
  updateDisaster,
  deleteDisaster,
};