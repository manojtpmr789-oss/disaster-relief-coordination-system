const User = require('../models/User');
const Disaster = require('../models/Disaster');
const ReliefRequest = require('../models/ReliefRequest');
const Volunteer = require('../models/Volunteer');
const Resource = require('../models/Resource');
const ReliefCamp = require('../models/ReliefCamp');
const Donation = require('../models/Donation');

// @desc    Get consolidated live system dashboard metrics and charts data
// @route   GET /api/dashboard/stats
// @access  Private
const getDashboardStats = async (req, res, next) => {
  try {
    const [
      totalUsers,
      totalVolunteers,
      verifiedVolunteers,
      totalAffected,
      totalDonors,
      totalAdmins,
      totalDisasters,
      activeDisasters,
      pendingDisasterReports,
      verifiedDisasters,
      resolvedDisasters,
      totalReliefRequests,
      pendingReliefRequests,
      approvedReliefRequests,
      inProgressReliefRequests,
      completedReliefRequests,
      criticalReliefRequests,
      totalResources,
      lowStockResources,
      outOfStockResources,
      camps,
      allDonations,
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ role: 'volunteer' }),
      Volunteer.countDocuments({ verificationStatus: 'Verified' }),
      User.countDocuments({ role: 'affected_user' }),
      User.countDocuments({ role: 'donor' }),
      User.countDocuments({ role: 'admin' }),
      Disaster.countDocuments(),
      Disaster.countDocuments({ status: 'Active' }),
      Disaster.countDocuments({ status: 'Pending' }),
      Disaster.countDocuments({ status: 'Verified' }),
      Disaster.countDocuments({ status: 'Resolved' }),
      ReliefRequest.countDocuments(),
      ReliefRequest.countDocuments({ status: 'Pending' }),
      ReliefRequest.countDocuments({ status: 'Approved' }),
      ReliefRequest.countDocuments({ status: 'In Progress' }),
      ReliefRequest.countDocuments({ status: 'Completed' }),
      ReliefRequest.countDocuments({ priority: 'Critical' }),
      Resource.countDocuments(),
      Resource.countDocuments({ status: 'Low Stock' }),
      Resource.countDocuments({ status: 'Out of Stock' }),
      ReliefCamp.find(),
      Donation.find(),
    ]);

    // Camp capacity aggregations
    const totalReliefCamps = camps.length;
    const totalCapacity = camps.reduce((sum, c) => sum + (c.capacity || 0), 0);
    const totalOccupancy = camps.reduce((sum, c) => sum + (c.currentOccupancy || 0), 0);
    const availableBeds = Math.max(0, totalCapacity - totalOccupancy);

    // Donation aggregations
    const totalMoneyDonations = allDonations
      .filter((d) => d.donationType === 'Money' && d.status !== 'Rejected')
      .reduce((sum, d) => sum + (d.amount || 0), 0);

    const totalMaterialsCount = allDonations
      .filter((d) => d.donationType !== 'Money' && d.status !== 'Rejected')
      .reduce((sum, d) => sum + (d.quantity || 1), 0);

    const receivedDonations = allDonations.filter((d) => d.status === 'Received').length;
    const distributedDonations = allDonations.filter((d) => d.status === 'Distributed').length;
    const pendingDonations = allDonations.filter((d) => d.status === 'Pending').length;

    // Charts Aggregations using Mongoose pipeline
    const [disastersByType, disastersBySeverity, requestsByStatus, requestsByPriority, resourcesByCategory] =
      await Promise.all([
        Disaster.aggregate([
          { $group: { _id: '$disasterType', count: { $sum: 1 } } },
          { $project: { type: '$_id', count: 1, _id: 0 } },
        ]),
        Disaster.aggregate([
          { $group: { _id: '$severity', count: { $sum: 1 } } },
          { $project: { severity: '$_id', count: 1, _id: 0 } },
        ]),
        ReliefRequest.aggregate([
          { $group: { _id: '$status', count: { $sum: 1 } } },
          { $project: { status: '$_id', count: 1, _id: 0 } },
        ]),
        ReliefRequest.aggregate([
          { $group: { _id: '$priority', count: { $sum: 1 } } },
          { $project: { priority: '$_id', count: 1, _id: 0 } },
        ]),
        Resource.aggregate([
          {
            $group: {
              _id: '$category',
              totalStock: { $sum: '$quantity' },
              itemCount: { $sum: 1 },
            },
          },
          { $project: { category: '$_id', totalStock: 1, itemCount: 1, _id: 0 } },
        ]),
      ]);

    // Donations by category aggregation
    const donationsByType = [
      { name: 'Monetary ($)', value: totalMoneyDonations },
      { name: 'Food & Rations', value: allDonations.filter((d) => d.donationType === 'Food').length },
      { name: 'Medical Supplies', value: allDonations.filter((d) => d.donationType === 'Medicine').length },
      { name: 'Clothing & Blankets', value: allDonations.filter((d) => d.donationType === 'Clothing').length },
      { name: 'Equipment & Other', value: allDonations.filter((d) => ['Equipment', 'Water', 'Other'].includes(d.donationType)).length },
    ];

    // Recent items
    const [recentDisasters, recentRequests] = await Promise.all([
      Disaster.find().sort({ createdAt: -1 }).limit(6).populate('reportedBy', 'name email phone'),
      ReliefRequest.find().sort({ createdAt: -1 }).limit(6).populate('requester', 'name email city'),
    ]);

    return res.status(200).json({
      success: true,
      metrics: {
        totalUsers,
        totalVolunteers,
        verifiedVolunteers,
        totalAffected,
        totalDonors,
        totalAdmins,
        totalDisasters,
        activeDisasters,
        pendingDisasterReports,
        verifiedDisasters,
        resolvedDisasters,
        totalReliefRequests,
        pendingReliefRequests,
        approvedReliefRequests,
        inProgressReliefRequests,
        completedReliefRequests,
        criticalReliefRequests,
        totalResources,
        lowStockResources,
        outOfStockResources,
        totalReliefCamps,
        totalCapacity,
        totalOccupancy,
        availableBeds,
        totalDonations: allDonations.length,
        totalMoneyDonations,
        totalMaterialsCount,
        receivedDonations,
        distributedDonations,
        pendingDonations,
      },
      charts: {
        disastersByType,
        disastersBySeverity,
        requestsByStatus,
        requestsByPriority,
        resourcesByCategory,
        donationsByType,
      },
      recentDisasters,
      recentRequests,
      campsSummary: camps.slice(0, 6),
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get volunteer-specific dashboard stats
// @route   GET /api/dashboard/volunteer-stats
// @access  Private (Volunteer / Admin)
const getVolunteerDashboardStats = async (req, res, next) => {
  try {
    const volunteerId = req.user._id;

    const [activeDisasters, pendingReliefRequests, assignedToMe, completedByMe] = await Promise.all([
      Disaster.countDocuments({ status: 'Active' }),
      ReliefRequest.countDocuments({ status: 'Pending' }),
      ReliefRequest.countDocuments({
        assignedVolunteer: volunteerId,
        status: { $in: ['Assigned', 'In Progress'] },
      }),
      ReliefRequest.countDocuments({
        assignedVolunteer: volunteerId,
        status: 'Completed',
      }),
    ]);

    return res.status(200).json({
      success: true,
      metrics: {
        activeDisasters,
        pendingReliefRequests,
        assignedToMe,
        completedByMe,
      },
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getDashboardStats,
  getVolunteerDashboardStats,
};
