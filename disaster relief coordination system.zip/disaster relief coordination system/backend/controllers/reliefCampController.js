const ReliefCamp = require('../models/ReliefCamp');

// @desc    Create new relief camp / shelter
// @route   POST /api/camps
// @access  Private (Admin / Coordinator)
const createReliefCamp = async (req, res, next) => {
  try {
    const {
      name,
      location,
      city,
      latitude,
      longitude,
      capacity,
      currentOccupancy,
      foodAvailable,
      medicalFacility,
      contactNumber,
      status,
    } = req.body;

    if (!name || !location || !city || !capacity || !contactNumber) {
      return res.status(400).json({
        success: false,
        message: 'Please provide required fields: name, location, city, capacity, and contactNumber',
      });
    }

    const camp = await ReliefCamp.create({
      name: name.trim(),
      location: location.trim(),
      city: city.trim(),
      latitude: Number(latitude) || 0,
      longitude: Number(longitude) || 0,
      capacity: Number(capacity),
      currentOccupancy: Number(currentOccupancy) || 0,
      foodAvailable: foodAvailable !== undefined ? Boolean(foodAvailable) : true,
      medicalFacility: medicalFacility !== undefined ? Boolean(medicalFacility) : true,
      contactNumber: contactNumber.trim(),
      status: status || 'Open',
    });

    return res.status(201).json({
      success: true,
      message: 'Relief camp created successfully',
      camp,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all relief camps with search & filters
// @route   GET /api/camps
// @access  Public / Private
const getReliefCamps = async (req, res, next) => {
  try {
    const { search, city, status, medical, food } = req.query;

    const query = {};

    if (status && status !== 'all') {
      query.status = status;
    }
    if (city && city !== 'all') {
      query.city = new RegExp(city.trim(), 'i');
    }
    if (medical === 'true') {
      query.medicalFacility = true;
    }
    if (food === 'true') {
      query.foodAvailable = true;
    }

    if (search && search.trim() !== '') {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { name: searchRegex },
        { location: searchRegex },
        { city: searchRegex },
        { contactNumber: searchRegex },
      ];
    }

    const camps = await ReliefCamp.find(query).sort({ createdAt: -1 });

    // Calculate aggregated capacity
    const totalCapacity = camps.reduce((acc, c) => acc + c.capacity, 0);
    const totalOccupancy = camps.reduce((acc, c) => acc + c.currentOccupancy, 0);
    const totalAvailableBeds = camps.reduce((acc, c) => acc + c.availableBeds, 0);

    return res.status(200).json({
      success: true,
      count: camps.length,
      metrics: {
        totalCamps: camps.length,
        totalCapacity,
        totalOccupancy,
        totalAvailableBeds,
      },
      camps,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single relief camp details
// @route   GET /api/camps/:id
// @access  Public / Private
const getReliefCampById = async (req, res, next) => {
  try {
    const camp = await ReliefCamp.findById(req.params.id);

    if (!camp) {
      return res.status(404).json({
        success: false,
        message: 'Relief camp not found',
      });
    }

    return res.status(200).json({
      success: true,
      camp,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update relief camp details
// @route   PUT /api/camps/:id
// @access  Private
const updateReliefCamp = async (req, res, next) => {
  try {
    const camp = await ReliefCamp.findById(req.params.id);

    if (!camp) {
      return res.status(404).json({
        success: false,
        message: 'Relief camp not found',
      });
    }

    const {
      name,
      location,
      city,
      latitude,
      longitude,
      capacity,
      currentOccupancy,
      foodAvailable,
      medicalFacility,
      contactNumber,
      status,
    } = req.body;

    if (name !== undefined) camp.name = name.trim();
    if (location !== undefined) camp.location = location.trim();
    if (city !== undefined) camp.city = city.trim();
    if (latitude !== undefined) camp.latitude = Number(latitude);
    if (longitude !== undefined) camp.longitude = Number(longitude);
    if (capacity !== undefined) camp.capacity = Number(capacity);
    if (currentOccupancy !== undefined) camp.currentOccupancy = Number(currentOccupancy);
    if (foodAvailable !== undefined) camp.foodAvailable = Boolean(foodAvailable);
    if (medicalFacility !== undefined) camp.medicalFacility = Boolean(medicalFacility);
    if (contactNumber !== undefined) camp.contactNumber = contactNumber.trim();
    if (status !== undefined) camp.status = status;

    const updated = await camp.save();

    return res.status(200).json({
      success: true,
      message: 'Relief camp updated successfully',
      camp: updated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Quick occupancy update
// @route   PUT /api/camps/:id/occupancy
// @access  Private
const updateOccupancy = async (req, res, next) => {
  try {
    const { occupancy } = req.body;
    const camp = await ReliefCamp.findById(req.params.id);

    if (!camp) {
      return res.status(404).json({ success: false, message: 'Relief camp not found' });
    }

    const newOccupancy = Number(occupancy);
    if (isNaN(newOccupancy) || newOccupancy < 0) {
      return res.status(400).json({ success: false, message: 'Occupancy must be a valid positive number' });
    }

    if (newOccupancy > camp.capacity) {
      return res.status(400).json({
        success: false,
        message: `Occupancy (${newOccupancy}) cannot exceed shelter capacity (${camp.capacity} beds).`,
      });
    }

    camp.currentOccupancy = newOccupancy;
    const updated = await camp.save();

    return res.status(200).json({
      success: true,
      message: `Occupancy updated to ${updated.currentOccupancy} / ${updated.capacity} (${updated.availableBeds} beds free)`,
      camp: updated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete relief camp
// @route   DELETE /api/camps/:id
// @access  Private (Admin only)
const deleteReliefCamp = async (req, res, next) => {
  try {
    const camp = await ReliefCamp.findById(req.params.id);

    if (!camp) {
      return res.status(404).json({
        success: false,
        message: 'Relief camp not found',
      });
    }

    await ReliefCamp.findByIdAndDelete(req.params.id);

    return res.status(200).json({
      success: true,
      message: 'Relief camp shelter deleted',
      deletedId: req.params.id,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createReliefCamp,
  getReliefCamps,
  getReliefCampById,
  updateReliefCamp,
  updateOccupancy,
  deleteReliefCamp,
};
