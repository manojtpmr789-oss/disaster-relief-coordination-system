const { validationResult } = require('express-validator');
const User = require('../models/User');
const Volunteer = require('../models/Volunteer');
const generateToken = require('../utils/generateToken');

// @desc    Register a new user (Affected User or Volunteer)
// @route   POST /api/auth/register
// @access  Public
const register = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: errors.array()[0].msg,
        errors: errors.array(),
      });
    }

    const {
      name,
      email,
      password,
      phone,
      address,
      city,
      role,
      skills,
      availability,
      emergencyContact,
    } = req.body;

    // Security: Restrict public registration to affected_user or volunteer
    let assignedRole = 'affected_user';
    if (role === 'volunteer') {
      assignedRole = 'volunteer';
    } else if (role === 'admin' || role === 'donor') {
      return res.status(403).json({
        success: false,
        message: 'Direct registration for this role is not permitted',
      });
    }

    // Check if user already exists
    const userExists = await User.findOne({ email: email.toLowerCase().trim() });
    if (userExists) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email address already exists',
      });
    }

    // Format skills if provided
    let parsedSkills = [];
    if (Array.isArray(skills)) {
      parsedSkills = skills.map((s) => String(s).trim()).filter(Boolean);
    } else if (typeof skills === 'string' && skills.trim()) {
      parsedSkills = skills.split(',').map((s) => s.trim()).filter(Boolean);
    }

    const parsedAvailability = ['available', 'busy', 'unavailable'].includes(availability)
      ? availability
      : 'available';

    // 1. Create the User document
    const user = await User.create({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password,
      phone: phone.trim(),
      address: address.trim(),
      city: city.trim(),
      role: assignedRole,
      skills: parsedSkills,
      availability: parsedAvailability,
    });

    // 2. If registering as Volunteer, create corresponding Volunteer document
    let volunteerProfile = null;
    if (assignedRole === 'volunteer') {
      volunteerProfile = await Volunteer.create({
        user: user._id,
        skills: parsedSkills,
        availability: parsedAvailability,
        location: address.trim(),
        city: city.trim(),
        emergencyContact: (emergencyContact && emergencyContact.trim()) || phone.trim(),
        verificationStatus: 'Pending',
        assignedTasks: [],
        completedTasks: [],
      });
    }

    const token = generateToken(user._id);

    return res.status(201).json({
      success: true,
      message:
        assignedRole === 'volunteer'
          ? 'Volunteer registration submitted successfully. Your profile is pending verification.'
          : 'Registration successful',
      user: user.toJSON(),
      volunteer: volunteerProfile,
      token,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Authenticate user & get token
// @route   POST /api/auth/login
// @access  Public
const login = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: errors.array()[0].msg,
        errors: errors.array(),
      });
    }

    const { email, password } = req.body;

    // Find user with password included explicitly
    const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password',
      });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password',
      });
    }

    const token = generateToken(user._id);

    return res.status(200).json({
      success: true,
      message: 'Login successful',
      user: user.toJSON(),
      token,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get currently logged in user
// @route   GET /api/auth/me
// @access  Private
const getMe = async (req, res, next) => {
  try {
    return res.status(200).json({
      success: true,
      user: req.user,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Log out user / clear session
// @route   POST /api/auth/logout
// @access  Public / Private
const logout = async (req, res, next) => {
  try {
    return res.status(200).json({
      success: true,
      message: 'Logged out successfully',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  register,
  login,
  getMe,
  logout,
};
