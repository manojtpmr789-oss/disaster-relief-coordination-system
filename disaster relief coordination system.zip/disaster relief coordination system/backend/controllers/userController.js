const User = require('../models/User');

// ==========================================
// USER PROFILE CONTROLLERS (Private to user)
// ==========================================

// @desc    Get current user profile
// @route   GET /api/users/profile
// @access  Private
const getProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User profile not found',
      });
    }

    return res.status(200).json({
      success: true,
      user,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update current user profile
// @route   PUT /api/users/profile
// @access  Private
const updateProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User profile not found',
      });
    }

    // Editable fields for personal profile
    const { name, phone, address, city, skills, availability } = req.body;

    if (name !== undefined) user.name = name.trim();
    if (phone !== undefined) user.phone = phone.trim();
    if (address !== undefined) user.address = address.trim();
    if (city !== undefined) user.city = city.trim();
    if (skills !== undefined) {
      user.skills = Array.isArray(skills)
        ? skills
        : skills.split(',').map((s) => s.trim()).filter(Boolean);
    }
    if (availability !== undefined) user.availability = availability;

    // Note: email and role are strictly immutable from user profile endpoint

    const updatedUser = await user.save();

    return res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      user: updatedUser,
    });
  } catch (error) {
    next(error);
  }
};

// ==========================================
// ADMIN USER MANAGEMENT (Admin Only)
// ==========================================

// @desc    Get all users with search, filter, and pagination
// @route   GET /api/users
// @access  Private (Admin only)
const getAllUsers = async (req, res, next) => {
  try {
    const { search, role, page = 1, limit = 50 } = req.query;

    const query = {};

    // Filter by role if provided
    if (role && role !== 'all') {
      query.role = role;
    }

    // Search by name, email, or city
    if (search && search.trim() !== '') {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { name: searchRegex },
        { email: searchRegex },
        { city: searchRegex },
        { phone: searchRegex },
      ];
    }

    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 50;
    const skip = (pageNum - 1) * limitNum;

    const [users, total] = await Promise.all([
      User.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limitNum),
      User.countDocuments(query),
    ]);

    // Role breakdown stats
    const [totalUsers, totalVolunteers, totalAffected, totalDonors, totalAdmins] =
      await Promise.all([
        User.countDocuments(),
        User.countDocuments({ role: 'volunteer' }),
        User.countDocuments({ role: 'affected_user' }),
        User.countDocuments({ role: 'donor' }),
        User.countDocuments({ role: 'admin' }),
      ]);

    return res.status(200).json({
      success: true,
      count: users.length,
      total,
      totalPages: Math.ceil(total / limitNum),
      currentPage: pageNum,
      breakdown: {
        totalUsers,
        totalVolunteers,
        totalAffected,
        totalDonors,
        totalAdmins,
      },
      users,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single user by ID
// @route   GET /api/users/:id
// @access  Private (Admin only)
const getUserById = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    return res.status(200).json({
      success: true,
      user,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update user details and role
// @route   PUT /api/users/:id
// @access  Private (Admin only)
const updateUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    const { name, phone, address, city, role, skills, availability } = req.body;

    // If changing role of an admin, verify there is at least one admin remaining
    if (role && role !== user.role && user.role === 'admin') {
      const adminCount = await User.countDocuments({ role: 'admin' });
      if (adminCount <= 1) {
        return res.status(400).json({
          success: false,
          message: 'Cannot change role. At least one system administrator is required.',
        });
      }
    }

    if (name !== undefined) user.name = name.trim();
    if (phone !== undefined) user.phone = phone.trim();
    if (address !== undefined) user.address = address.trim();
    if (city !== undefined) user.city = city.trim();
    if (role !== undefined) user.role = role;
    if (skills !== undefined) {
      user.skills = Array.isArray(skills)
        ? skills
        : skills.split(',').map((s) => s.trim()).filter(Boolean);
    }
    if (availability !== undefined) user.availability = availability;

    const updatedUser = await user.save();

    return res.status(200).json({
      success: true,
      message: 'User updated successfully',
      user: updatedUser,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a user
// @route   DELETE /api/users/:id
// @access  Private (Admin only)
const deleteUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Safety check: Prevent deleting oneself
    if (user._id.toString() === req.user._id.toString()) {
      return res.status(400).json({
        success: false,
        message: 'Security protection: You cannot delete your own administrative account.',
      });
    }

    // Safety check: Prevent deleting last admin
    if (user.role === 'admin') {
      const adminCount = await User.countDocuments({ role: 'admin' });
      if (adminCount <= 1) {
        return res.status(400).json({
          success: false,
          message: 'Security protection: Cannot delete the last remaining administrator account.',
        });
      }
    }

    await User.findByIdAndDelete(req.params.id);

    return res.status(200).json({
      success: true,
      message: 'User account removed successfully',
      deletedId: req.params.id,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get dashboard metrics & summary
// @route   GET /api/users/stats/summary
// @access  Private
const getDashboardStats = async (req, res, next) => {
  try {
    const [totalUsers, totalVolunteers, totalAffected, totalDonors, totalAdmins] =
      await Promise.all([
        User.countDocuments(),
        User.countDocuments({ role: 'volunteer' }),
        User.countDocuments({ role: 'affected_user' }),
        User.countDocuments({ role: 'donor' }),
        User.countDocuments({ role: 'admin' }),
      ]);

    // Real dynamic user stats + placeholder zero counters for Part 2 disaster modules
    return res.status(200).json({
      success: true,
      stats: {
        totalUsers,
        totalVolunteers,
        totalAffected,
        totalDonors,
        totalAdmins,
        activeDisasters: 0,
        pendingReliefRequests: 0,
        availableResources: 0,
        reliefCamps: 0,
      },
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getProfile,
  updateProfile,
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getDashboardStats,
};
