const Volunteer = require('../models/Volunteer');
const User = require('../models/User');
const ReliefRequest = require('../models/ReliefRequest');
const createNotification = require('../utils/createNotification');

// @desc    Get all volunteers with filters
// @route   GET /api/volunteers
// @access  Private
const getVolunteers = async (req, res, next) => {
  try {
    const { search, skill, city, availability, verification } = req.query;

    // Ensure all registered users with role 'volunteer' have a corresponding Volunteer document
    const volunteerUsers = await User.find({ role: 'volunteer' }).select('-password');
    for (const u of volunteerUsers) {
      const exists = await Volunteer.exists({ user: u._id });
      if (!exists) {
        await Volunteer.create({
          user: u._id,
          skills: u.skills || [],
          availability: u.availability || 'available',
          city: u.city || '',
          location: u.address || '',
          emergencyContact: u.phone || '',
          verificationStatus: 'Pending',
        });
      }
    }

    const query = {};

    if (availability && availability !== 'all') {
      query.availability = availability;
    }
    if (verification && verification !== 'all') {
      query.verificationStatus = verification;
    }
    if (city && city !== 'all') {
      query.city = new RegExp(city.trim(), 'i');
    }
    if (skill && skill !== 'all') {
      query.skills = { $in: [new RegExp(skill.trim(), 'i')] };
    }

    let volunteers = await Volunteer.find(query)
      .populate('user', 'name email phone city address role')
      .populate({
        path: 'assignedTasks',
        select: 'requestType priority status location city',
      })
      .populate({
        path: 'completedTasks',
        select: 'requestType priority status location city',
      })
      .sort({ createdAt: -1 });

    // In-memory filter for search across populated user name / email
    if (search && search.trim() !== '') {
      const regex = new RegExp(search.trim(), 'i');
      volunteers = volunteers.filter(
        (v) =>
          (v.user && (regex.test(v.user.name) || regex.test(v.user.email))) ||
          regex.test(v.city) ||
          regex.test(v.location) ||
          (v.skills && v.skills.some((s) => regex.test(s)))
      );
    }

    return res.status(200).json({
      success: true,
      count: volunteers.length,
      volunteers,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single volunteer details
// @route   GET /api/volunteers/:id
// @access  Private
const getVolunteerById = async (req, res, next) => {
  try {
    const volunteer = await Volunteer.findById(req.params.id)
      .populate('user', 'name email phone city address')
      .populate('assignedTasks')
      .populate('completedTasks');

    if (!volunteer) {
      return res.status(404).json({
        success: false,
        message: 'Volunteer profile not found',
      });
    }

    return res.status(200).json({
      success: true,
      volunteer,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get or create current logged-in user volunteer profile
// @route   GET /api/volunteers/profile/me
// @access  Private
const getMyVolunteerProfile = async (req, res, next) => {
  try {
    let volunteer = await Volunteer.findOne({ user: req.user._id })
      .populate('user', 'name email phone city address')
      .populate('assignedTasks')
      .populate('completedTasks');

    if (!volunteer && (req.user.role === 'volunteer' || req.user.role === 'admin')) {
      volunteer = await Volunteer.create({
        user: req.user._id,
        skills: req.user.skills || [],
        availability: req.user.availability || 'available',
        city: req.user.city || '',
        location: req.user.address || '',
        emergencyContact: req.user.phone || '',
        verificationStatus: req.user.role === 'admin' ? 'Verified' : 'Pending',
      });
      volunteer = await Volunteer.findById(volunteer._id).populate('user', 'name email phone city address');
    }

    return res.status(200).json({
      success: true,
      volunteer,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update current volunteer profile
// @route   PUT /api/volunteers/profile/me
// @access  Private
const updateMyVolunteerProfile = async (req, res, next) => {
  try {
    const { skills, availability, location, city, emergencyContact } = req.body;

    let volunteer = await Volunteer.findOne({ user: req.user._id });

    if (!volunteer) {
      volunteer = new Volunteer({ user: req.user._id });
    }

    if (skills !== undefined) {
      volunteer.skills = Array.isArray(skills)
        ? skills
        : skills.split(',').map((s) => s.trim()).filter(Boolean);
    }
    if (availability !== undefined) volunteer.availability = availability;
    if (location !== undefined) volunteer.location = location.trim();
    if (city !== undefined) volunteer.city = city.trim();
    if (emergencyContact !== undefined) volunteer.emergencyContact = emergencyContact.trim();

    await volunteer.save();

    // Also sync with User document
    await User.findByIdAndUpdate(req.user._id, {
      skills: volunteer.skills,
      availability: volunteer.availability,
    });

    const populated = await Volunteer.findById(volunteer._id)
      .populate('user', 'name email phone city address')
      .populate('assignedTasks')
      .populate('completedTasks');

    return res.status(200).json({
      success: true,
      message: 'Volunteer profile updated successfully',
      volunteer: populated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Admin: Verify or reject volunteer
// @route   PUT /api/volunteers/:id/verify
// @access  Private (Admin only)
const verifyVolunteer = async (req, res, next) => {
  try {
    const { verificationStatus } = req.body;

    if (!['Pending', 'Verified', 'Rejected'].includes(verificationStatus)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid verification status',
      });
    }

    const volunteer = await Volunteer.findById(req.params.id);
    if (!volunteer) {
      return res.status(404).json({
        success: false,
        message: 'Volunteer not found',
      });
    }

    volunteer.verificationStatus = verificationStatus;
    await volunteer.save();

    // Notify the volunteer
    await createNotification({
      recipientId: volunteer.user,
      title: `Volunteer Verification Status: ${verificationStatus}`,
      message: `Your responder clearance has been set to "${verificationStatus}".`,
      type: 'Volunteer',
      relatedId: volunteer._id,
    });

    const populated = await Volunteer.findById(volunteer._id).populate(
      'user',
      'name email phone city'
    );

    return res.status(200).json({
      success: true,
      message: `Volunteer marked as ${verificationStatus}`,
      volunteer: populated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Admin: Assign task to volunteer
// @route   PUT /api/volunteers/:id/assign
// @access  Private (Admin only)
const assignTaskToVolunteer = async (req, res, next) => {
  try {
    const { taskId } = req.body;

    let [volunteer, reliefRequest] = await Promise.all([
      Volunteer.findById(req.params.id),
      ReliefRequest.findById(taskId),
    ]);

    if (!volunteer) {
      volunteer = await Volunteer.findOne({ user: req.params.id });
    }

    if (!volunteer) {
      return res.status(404).json({ success: false, message: 'Volunteer not found' });
    }
    if (!reliefRequest) {
      return res.status(404).json({ success: false, message: 'Relief task not found' });
    }

    reliefRequest.assignedVolunteer = volunteer.user;
    reliefRequest.status = 'Assigned';
    await reliefRequest.save();

    if (!volunteer.assignedTasks.includes(reliefRequest._id)) {
      volunteer.assignedTasks.push(reliefRequest._id);
      await volunteer.save();
    }

    // Notify volunteer
    await createNotification({
      recipientId: volunteer.user,
      title: `🚨 Emergency Task Assigned`,
      message: `You have been assigned to ${reliefRequest.requestType} in ${reliefRequest.city}.`,
      type: 'Relief Request',
      relatedId: reliefRequest._id,
    });

    return res.status(200).json({
      success: true,
      message: 'Task assigned to volunteer successfully',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getVolunteers,
  getVolunteerById,
  getMyVolunteerProfile,
  updateMyVolunteerProfile,
  verifyVolunteer,
  assignTaskToVolunteer,
};
