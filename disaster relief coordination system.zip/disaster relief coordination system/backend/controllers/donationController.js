const Donation = require('../models/Donation');
const createNotification = require('../utils/createNotification');

// @desc    Create new donation
// @route   POST /api/donations
// @access  Private
const createDonation = async (req, res, next) => {
  try {
    const {
      donationType,
      amount,
      itemName,
      quantity,
      description,
      disaster,
    } = req.body;

    if (!donationType || !description) {
      return res.status(400).json({
        success: false,
        message: 'Please provide donationType and description',
      });
    }

    if (donationType === 'Money' && (!amount || Number(amount) <= 0)) {
      return res.status(400).json({
        success: false,
        message: 'Please specify a valid monetary donation amount',
      });
    }

    const donation = await Donation.create({
      donor: req.user._id,
      donationType,
      amount: donationType === 'Money' ? Number(amount) : 0,
      itemName: itemName ? itemName.trim() : '',
      quantity: donationType !== 'Money' ? Number(quantity) || 1 : 0,
      description: description.trim(),
      disaster: disaster || null,
      status: 'Pending',
    });

    // Notify administrators
    await createNotification({
      notifyAdmins: true,
      title: `💝 New Aid Donation Submitted`,
      message: `${req.user.name} pledged ${donation.donationType === 'Money' ? `$${donation.amount}` : `${donation.quantity} ${donation.itemName || donation.donationType}`}.`,
      type: 'Donation',
      relatedId: donation._id,
    });

    const populated = await Donation.findById(donation._id)
      .populate('donor', 'name email phone')
      .populate('disaster', 'title disasterType city');

    return res.status(201).json({
      success: true,
      message: 'Donation recorded successfully. Thank you for your support!',
      donation: populated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all donations with search & filters
// @route   GET /api/donations
// @access  Private
const getDonations = async (req, res, next) => {
  try {
    const { search, type, status, myDonations } = req.query;

    const query = {};

    if (myDonations === 'true' || req.user.role === 'donor') {
      query.donor = req.user._id;
    }

    if (type && type !== 'all') {
      query.donationType = type;
    }
    if (status && status !== 'all') {
      query.status = status;
    }

    if (search && search.trim() !== '') {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { description: searchRegex },
        { itemName: searchRegex },
      ];
    }

    const donations = await Donation.find(query)
      .populate('donor', 'name email phone city')
      .populate('disaster', 'title disasterType city')
      .sort({ createdAt: -1 });

    // Aggregations
    const allDonations = await Donation.find();
    const totalMonetary = allDonations
      .filter((d) => d.donationType === 'Money' && d.status !== 'Rejected')
      .reduce((sum, d) => sum + (d.amount || 0), 0);

    const totalMaterialsCount = allDonations
      .filter((d) => d.donationType !== 'Money' && d.status !== 'Rejected')
      .reduce((sum, d) => sum + (d.quantity || 1), 0);

    const receivedCount = allDonations.filter((d) => d.status === 'Received').length;
    const distributedCount = allDonations.filter((d) => d.status === 'Distributed').length;
    const pendingCount = allDonations.filter((d) => d.status === 'Pending').length;

    return res.status(200).json({
      success: true,
      count: donations.length,
      summary: {
        totalDonations: allDonations.length,
        totalMonetary,
        totalMaterialsCount,
        receivedCount,
        distributedCount,
        pendingCount,
      },
      donations,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single donation by ID
// @route   GET /api/donations/:id
// @access  Private
const getDonationById = async (req, res, next) => {
  try {
    const donation = await Donation.findById(req.params.id)
      .populate('donor', 'name email phone city')
      .populate('disaster', 'title disasterType city severity');

    if (!donation) {
      return res.status(404).json({
        success: false,
        message: 'Donation record not found',
      });
    }

    return res.status(200).json({
      success: true,
      donation,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update donation status
// @route   PUT /api/donations/:id
// @access  Private (Admin only)
const updateDonation = async (req, res, next) => {
  try {
    const donation = await Donation.findById(req.params.id);

    if (!donation) {
      return res.status(404).json({
        success: false,
        message: 'Donation record not found',
      });
    }

    const { status, description, amount, itemName, quantity, donationType } = req.body;

    if (status !== undefined && req.user.role === 'admin') {
      const prevStatus = donation.status;
      donation.status = status;

      if (prevStatus !== status) {
        await createNotification({
          recipientId: donation.donor,
          title: `Donation Status Update: ${status}`,
          message: `Your aid donation of ${donation.donationType === 'Money' ? `$${donation.amount}` : donation.itemName || donation.donationType} has been marked as "${status}".`,
          type: 'Donation',
          relatedId: donation._id,
        });
      }
    }

    if (description !== undefined) donation.description = description.trim();
    if (amount !== undefined) donation.amount = Number(amount);
    if (itemName !== undefined) donation.itemName = itemName.trim();
    if (quantity !== undefined) donation.quantity = Number(quantity);
    if (donationType !== undefined) donation.donationType = donationType;

    const updated = await donation.save();
    const populated = await Donation.findById(updated._id)
      .populate('donor', 'name email phone city')
      .populate('disaster', 'title disasterType city');

    return res.status(200).json({
      success: true,
      message: 'Donation record updated successfully',
      donation: populated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete donation
// @route   DELETE /api/donations/:id
// @access  Private (Admin or Donor if Pending)
const deleteDonation = async (req, res, next) => {
  try {
    const donation = await Donation.findById(req.params.id);

    if (!donation) {
      return res.status(404).json({
        success: false,
        message: 'Donation not found',
      });
    }

    if (
      req.user.role !== 'admin' &&
      donation.donor.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this donation record',
      });
    }

    await Donation.findByIdAndDelete(req.params.id);

    return res.status(200).json({
      success: true,
      message: 'Donation record deleted',
      deletedId: req.params.id,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createDonation,
  getDonations,
  getDonationById,
  updateDonation,
  deleteDonation,
};
