const Disaster = require('../models/Disaster');
const ReliefRequest = require('../models/ReliefRequest');
const Volunteer = require('../models/Volunteer');
const Resource = require('../models/Resource');
const ReliefCamp = require('../models/ReliefCamp');
const Donation = require('../models/Donation');

// @desc    Get detailed report dataset with multi-criteria filtering
// @route   GET /api/reports/summary
// @access  Private (Admin / Coordinator)
const getReportSummary = async (req, res, next) => {
  try {
    const {
      module = 'disasters',
      city,
      type,
      severity,
      status,
      priority,
      startDate,
      endDate,
    } = req.query;

    const dateQuery = {};
    if (startDate || endDate) {
      dateQuery.createdAt = {};
      if (startDate) dateQuery.createdAt.$gte = new Date(startDate);
      if (endDate) dateQuery.createdAt.$lte = new Date(endDate);
    }

    let reportData = [];
    let columns = [];

    switch (module) {
      case 'disasters': {
        const query = { ...dateQuery };
        if (city && city !== 'all') query.city = new RegExp(city.trim(), 'i');
        if (type && type !== 'all') query.disasterType = type;
        if (severity && severity !== 'all') query.severity = severity;
        if (status && status !== 'all') query.status = status;

        const disasters = await Disaster.find(query)
          .populate('reportedBy', 'name email phone')
          .sort({ createdAt: -1 });

        columns = ['Title', 'Type', 'City', 'Location', 'Severity', 'Status', 'Reported By', 'Created At'];
        reportData = disasters.map((d) => ({
          _id: d._id,
          Title: d.title,
          Type: d.disasterType,
          City: d.city,
          Location: d.location,
          Severity: d.severity,
          Status: d.status,
          'Reported By': d.reportedBy?.name || 'Anonymous',
          'Created At': new Date(d.createdAt).toISOString().split('T')[0],
        }));
        break;
      }

      case 'requests': {
        const query = { ...dateQuery };
        if (city && city !== 'all') query.city = new RegExp(city.trim(), 'i');
        if (type && type !== 'all') query.requestType = type;
        if (priority && priority !== 'all') query.priority = priority;
        if (status && status !== 'all') query.status = status;

        const requests = await ReliefRequest.find(query)
          .populate('requester', 'name email phone')
          .populate('assignedVolunteer', 'name email')
          .sort({ createdAt: -1 });

        columns = ['Request Type', 'Quantity', 'Priority', 'Status', 'City', 'Location', 'Contact', 'Requester', 'Assigned Volunteer', 'Date'];
        reportData = requests.map((r) => ({
          _id: r._id,
          'Request Type': r.requestType,
          Quantity: r.quantity,
          Priority: r.priority,
          Status: r.status,
          City: r.city,
          Location: r.location,
          Contact: r.contactNumber,
          Requester: r.requester?.name || 'N/A',
          'Assigned Volunteer': r.assignedVolunteer?.name || 'Unassigned',
          Date: new Date(r.createdAt).toISOString().split('T')[0],
        }));
        break;
      }

      case 'volunteers': {
        const query = { ...dateQuery };
        if (city && city !== 'all') query.city = new RegExp(city.trim(), 'i');
        if (status && status !== 'all') query.verificationStatus = status;

        const volunteers = await Volunteer.find(query)
          .populate('user', 'name email phone city')
          .populate('assignedTasks', 'requestType priority')
          .populate('completedTasks', 'requestType priority');

        columns = ['Volunteer Name', 'Email', 'Phone', 'City', 'Verification', 'Availability', 'Skills', 'Active Tasks', 'Completed Tasks'];
        reportData = volunteers.map((v) => ({
          _id: v._id,
          'Volunteer Name': v.user?.name || 'Unknown',
          Email: v.user?.email || 'N/A',
          Phone: v.user?.phone || 'N/A',
          City: v.city || v.user?.city || 'N/A',
          Verification: v.verificationStatus,
          Availability: v.availability,
          Skills: v.skills?.join(', ') || 'General Aid',
          'Active Tasks': v.assignedTasks?.length || 0,
          'Completed Tasks': v.completedTasks?.length || 0,
        }));
        break;
      }

      case 'resources': {
        const query = { ...dateQuery };
        if (city && city !== 'all') query.city = new RegExp(city.trim(), 'i');
        if (type && type !== 'all') query.category = type;
        if (status && status !== 'all') query.status = status;

        const resources = await Resource.find(query).sort({ category: 1 });

        columns = ['Resource Item', 'Category', 'Quantity', 'Unit', 'City', 'Storage Location', 'Min Stock Threshold', 'Stock Status', 'Donated By'];
        reportData = resources.map((r) => ({
          _id: r._id,
          'Resource Item': r.name,
          Category: r.category,
          Quantity: r.quantity,
          Unit: r.unit,
          City: r.city,
          'Storage Location': r.location,
          'Min Stock Threshold': r.minimumStock,
          'Stock Status': r.status,
          'Donated By': r.donatedBy,
        }));
        break;
      }

      case 'camps': {
        const query = { ...dateQuery };
        if (city && city !== 'all') query.city = new RegExp(city.trim(), 'i');
        if (status && status !== 'all') query.status = status;

        const camps = await ReliefCamp.find(query).sort({ currentOccupancy: -1 });

        columns = ['Camp Name', 'City', 'Location', 'Capacity', 'Current Occupancy', 'Available Beds', 'Food Ready', 'Medical Clinic', 'Status', 'Contact'];
        reportData = camps.map((c) => ({
          _id: c._id,
          'Camp Name': c.name,
          City: c.city,
          Location: c.location,
          Capacity: c.capacity,
          'Current Occupancy': c.currentOccupancy,
          'Available Beds': c.availableBeds,
          'Food Ready': c.foodAvailable ? 'YES' : 'NO',
          'Medical Clinic': c.medicalFacility ? 'YES' : 'NO',
          Status: c.status,
          Contact: c.contactNumber,
        }));
        break;
      }

      case 'donations': {
        const query = { ...dateQuery };
        if (type && type !== 'all') query.donationType = type;
        if (status && status !== 'all') query.status = status;

        const donations = await Donation.find(query)
          .populate('donor', 'name email phone')
          .sort({ createdAt: -1 });

        columns = ['Donor Name', 'Type', 'Amount ($)', 'Item Name', 'Quantity', 'Status', 'Date', 'Description'];
        reportData = donations.map((d) => ({
          _id: d._id,
          'Donor Name': d.donor?.name || 'Anonymous',
          Type: d.donationType,
          'Amount ($)': d.donationType === 'Money' ? `$${d.amount}` : '—',
          'Item Name': d.itemName || '—',
          Quantity: d.quantity || '—',
          Status: d.status,
          Date: new Date(d.createdAt).toISOString().split('T')[0],
          Description: d.description,
        }));
        break;
      }

      default:
        break;
    }

    return res.status(200).json({
      success: true,
      module,
      count: reportData.length,
      columns,
      reportData,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getReportSummary,
};
