const ReliefRequest = require('../models/ReliefRequest');
const Volunteer = require('../models/Volunteer');
const User = require('../models/User');
const createNotification = require('../utils/createNotification');

// @desc    Create relief request
// @route   POST /api/relief-requests
// @access  Private
const createReliefRequest = async (req, res, next) => {
  try {
    const {
      disaster,
      requestType,
      description,
      quantity,
      priority,
      location,
      city,
      contactNumber,
    } = req.body;

    if (!requestType || !description || !location || !city || !contactNumber) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields: requestType, description, location, city, and contactNumber',
      });
    }

    const reliefRequest = await ReliefRequest.create({
      requester: req.user._id,
      disaster: disaster || null,
      requestType,
      description: description.trim(),
      quantity: Number(quantity) || 1,
      priority: priority || 'Medium',
      location: location.trim(),
      city: city.trim(),
      contactNumber: contactNumber.trim(),
      status: 'Pending',
    });

    // Notify administrators of new emergency aid request
    await createNotification({
      notifyAdmins: true,
      title: `🆘 Emergency Aid Request (${reliefRequest.priority} Priority)`,
      message: `${req.user.name} requested ${reliefRequest.requestType} in ${reliefRequest.city}.`,
      type: 'Relief Request',
      relatedId: reliefRequest._id,
    });

    const populated = await ReliefRequest.findById(reliefRequest._id)
      .populate('requester', 'name email phone')
      .populate('disaster', 'title disasterType severity');

    return res.status(201).json({
      success: true,
      message: 'Relief request submitted successfully',
      reliefRequest: populated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all relief requests with search & filters
// @route   GET /api/relief-requests
// @access  Private
const getReliefRequests = async (req, res, next) => {
  try {
    const {
      search,
      requestType,
      priority,
      status,
      city,
      myRequests,
      myAssigned,
    } = req.query;

    const query = {};

    // If regular citizen requested own, or query specifies myRequests
    if (myRequests === 'true' || req.user.role === 'affected_user') {
      query.requester = req.user._id;
    }

    // If volunteer asks for their assigned tasks
    if (myAssigned === 'true' || (req.user.role === 'volunteer' && myRequests !== 'true' && !req.query.all)) {
      query.assignedVolunteer = req.user._id;
    }

    if (requestType && requestType !== 'all') {
      query.requestType = requestType;
    }
    if (priority && priority !== 'all') {
      query.priority = priority;
    }
    if (status && status !== 'all') {
      query.status = status;
    }
    if (city && city !== 'all') {
      query.city = new RegExp(city.trim(), 'i');
    }

    if (search && search.trim() !== '') {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { description: searchRegex },
        { location: searchRegex },
        { city: searchRegex },
        { contactNumber: searchRegex },
      ];
    }

    const reliefRequests = await ReliefRequest.find(query)
      .populate('requester', 'name email phone city')
      .populate('disaster', 'title disasterType severity')
      .populate('assignedVolunteer', 'name email phone')
      .sort({ createdAt: -1 });

    return res.status(200).json({
      success: true,
      count: reliefRequests.length,
      reliefRequests,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single relief request details
// @route   GET /api/relief-requests/:id
// @access  Private
const getReliefRequestById = async (req, res, next) => {
  try {
    const reliefRequest = await ReliefRequest.findById(req.params.id)
      .populate('requester', 'name email phone city address')
      .populate('disaster', 'title disasterType severity location city')
      .populate('assignedVolunteer', 'name email phone');

    if (!reliefRequest) {
      return res.status(404).json({
        success: false,
        message: 'Relief request not found',
      });
    }

    return res.status(200).json({
      success: true,
      reliefRequest,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update relief request (Approve, Assign volunteer, Change status)
// @route   PUT /api/relief-requests/:id
// @access  Private
const updateReliefRequest = async (req, res, next) => {
  try {
    const reliefRequest = await ReliefRequest.findById(req.params.id);

    if (!reliefRequest) {
      return res.status(404).json({
        success: false,
        message: 'Relief request not found',
      });
    }

    const {
      status,
      assignedVolunteer,
      priority,
      description,
      quantity,
      location,
      city,
      contactNumber,
      requestType,
    } = req.body;

    const isRequester = reliefRequest.requester.toString() === req.user._id.toString();
    const isAssignedVolunteer =
      reliefRequest.assignedVolunteer &&
      reliefRequest.assignedVolunteer.toString() === req.user._id.toString();
    const isAdmin = req.user.role === 'admin';
    const isVolunteer = req.user.role === 'volunteer';

    // Block volunteer from modifying a task not assigned to them
    if (isVolunteer && !isAssignedVolunteer && !isRequester) {
      return res.status(403).json({
        success: false,
        message: 'You are not authorized to update this relief request.',
      });
    }

    // Requester can update description/quantity if still pending
    if (isRequester && reliefRequest.status === 'Pending') {
      if (description !== undefined) reliefRequest.description = description.trim();
      if (quantity !== undefined) reliefRequest.quantity = Number(quantity);
      if (location !== undefined) reliefRequest.location = location.trim();
      if (city !== undefined) reliefRequest.city = city.trim();
      if (contactNumber !== undefined) reliefRequest.contactNumber = contactNumber.trim();
      if (requestType !== undefined) reliefRequest.requestType = requestType;
    }

    // Volunteer can update status of task assigned to them (strict flow only)
    if (isAssignedVolunteer && !isAdmin) {
      if (status !== undefined) {
        const prevStatus = reliefRequest.status;

        // Enforce strict progression: Assigned → In Progress → Completed
        const allowedTransitions = {
          'Assigned': 'In Progress',
          'In Progress': 'Completed',
        };

        if (!allowedTransitions[prevStatus] || allowedTransitions[prevStatus] !== status) {
          return res.status(400).json({
            success: false,
            message: `Invalid status transition. You can only move from "${prevStatus}" to "${allowedTransitions[prevStatus] || '(no transition allowed)'}"`,
          });
        }

        reliefRequest.status = status;

        // If completed, update volunteer completed tasks
        if (status === 'Completed' && prevStatus !== 'Completed' && reliefRequest.assignedVolunteer) {
          await Volunteer.findOneAndUpdate(
            { user: reliefRequest.assignedVolunteer },
            {
              $addToSet: { completedTasks: reliefRequest._id },
              $pull: { assignedTasks: reliefRequest._id },
            }
          );
        }

        // Notify requester about progress
        if (prevStatus !== status) {
          await createNotification({
            recipientId: reliefRequest.requester,
            title: `Relief Request Status: ${status}`,
            message: `Your relief request for ${reliefRequest.requestType} is now "${status}".`,
            type: 'Relief Request',
            relatedId: reliefRequest._id,
          });
        }
      }
    }

    // Admin can update any status and handle completions
    if (isAdmin) {
      if (status !== undefined) {
        const prevStatus = reliefRequest.status;
        reliefRequest.status = status;

        // If completed, update volunteer completed tasks
        if (status === 'Completed' && prevStatus !== 'Completed' && reliefRequest.assignedVolunteer) {
          await Volunteer.findOneAndUpdate(
            { user: reliefRequest.assignedVolunteer },
            {
              $addToSet: { completedTasks: reliefRequest._id },
              $pull: { assignedTasks: reliefRequest._id },
            }
          );
        }

        // Notify requester about progress
        if (prevStatus !== status) {
          await createNotification({
            recipientId: reliefRequest.requester,
            title: `Relief Request Status: ${status}`,
            message: `Your relief request for ${reliefRequest.requestType} is now "${status}".`,
            type: 'Relief Request',
            relatedId: reliefRequest._id,
          });
        }
      }
    }

    // Admin can assign volunteer, approve/reject, change priority
    if (isAdmin) {
      if (priority !== undefined) reliefRequest.priority = priority;

      if (assignedVolunteer !== undefined) {
        let volunteerUserId = assignedVolunteer || null;
        if (volunteerUserId) {
          const checkUser = await User.findById(volunteerUserId);
          if (!checkUser) {
            const checkVol = await Volunteer.findById(volunteerUserId);
            if (checkVol && checkVol.user) {
              volunteerUserId = checkVol.user;
            }
          }
        }

        reliefRequest.assignedVolunteer = volunteerUserId;
        if (volunteerUserId) {
          reliefRequest.status = 'Assigned';

          // Add to volunteer assigned tasks
          await Volunteer.findOneAndUpdate(
            { user: volunteerUserId },
            { $addToSet: { assignedTasks: reliefRequest._id } },
            { upsert: true }
          );

          // Notify assigned volunteer
          await createNotification({
            recipientId: volunteerUserId,
            title: `New Relief Task Assigned (${reliefRequest.priority} Priority)`,
            message: `You have been assigned to dispatch ${reliefRequest.requestType} in ${reliefRequest.city}.`,
            type: 'Relief Request',
            relatedId: reliefRequest._id,
          });

          // Notify requester
          if (reliefRequest.requester) {
            await createNotification({
              recipientId: reliefRequest.requester,
              title: 'Volunteer Assigned to Your Request',
              message: 'A field responder has been assigned to coordinate your relief supplies.',
              type: 'Relief Request',
              relatedId: reliefRequest._id,
            });
          }
        }
      }
    }

    const updated = await reliefRequest.save();
    const populated = await ReliefRequest.findById(updated._id)
      .populate('requester', 'name email phone city')
      .populate('disaster', 'title disasterType severity')
      .populate('assignedVolunteer', 'name email phone');

    return res.status(200).json({
      success: true,
      message: 'Relief request updated successfully',
      reliefRequest: populated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Admin: Assign volunteer to relief request
// @route   PUT /api/relief-requests/:id/assign
// @access  Private (Admin only)
const assignVolunteerToReliefRequest = async (req, res, next) => {
  try {
    const { volunteerId } = req.body;

    if (!volunteerId) {
      return res.status(400).json({
        success: false,
        message: 'Please provide volunteerId to assign',
      });
    }

    const reliefRequest = await ReliefRequest.findById(req.params.id);
    if (!reliefRequest) {
      return res.status(404).json({
        success: false,
        message: 'Relief request not found',
      });
    }

    // Support both User._id and Volunteer._id seamlessly
    let volunteerUser = await User.findById(volunteerId);
    if (!volunteerUser) {
      const volunteerDoc = await Volunteer.findById(volunteerId).populate('user');
      if (volunteerDoc && volunteerDoc.user) {
        volunteerUser = volunteerDoc.user;
      }
    }

    if (!volunteerUser) {
      return res.status(404).json({
        success: false,
        message: 'Selected volunteer not found',
      });
    }

    if (volunteerUser.role !== 'volunteer') {
      return res.status(400).json({
        success: false,
        message: 'Selected user does not have the "volunteer" role',
      });
    }

    // Update relief request in MongoDB
    reliefRequest.assignedVolunteer = volunteerUser._id;
    reliefRequest.status = 'Assigned';
    await reliefRequest.save();

    // Sync with Volunteer model's assignedTasks
    await Volunteer.findOneAndUpdate(
      { user: volunteerUser._id },
      { $addToSet: { assignedTasks: reliefRequest._id } },
      { upsert: true }
    );

    // Create notification for assigned volunteer
    await createNotification({
      recipientId: volunteerUser._id,
      title: 'New Relief Task Assigned',
      message: `You have been assigned to dispatch ${reliefRequest.requestType} in ${reliefRequest.city}.`,
      type: 'Relief Request',
      relatedId: reliefRequest._id,
    });

    // Create notification for requester
    if (reliefRequest.requester) {
      await createNotification({
        recipientId: reliefRequest.requester,
        title: 'Volunteer Assigned to Your Request',
        message: `${volunteerUser.name} has been assigned to coordinate your relief supplies.`,
        type: 'Relief Request',
        relatedId: reliefRequest._id,
      });
    }

    const populated = await ReliefRequest.findById(reliefRequest._id)
      .populate('requester', 'name email phone city')
      .populate('disaster', 'title disasterType severity city')
      .populate('assignedVolunteer', 'name email phone');

    return res.status(200).json({
      success: true,
      message: 'Volunteer assigned successfully',
      reliefRequest: populated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get relief requests assigned to logged-in volunteer
// @route   GET /api/relief-requests/my-tasks
// @access  Private (Volunteer / Admin)
const getMyAssignedTasks = async (req, res, next) => {
  try {
    const tasks = await ReliefRequest.find({
      assignedVolunteer: req.user._id,
    })
      .populate('requester', 'name email phone city')
      .populate('disaster', 'title disasterType city severity')
      .populate('assignedVolunteer', 'name email phone')
      .sort({ createdAt: -1 });

    return res.status(200).json({
      success: true,
      count: tasks.length,
      reliefRequests: tasks,
      tasks,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Volunteer: Update status of assigned task (Assigned -> In Progress -> Completed)
// @route   PUT /api/relief-requests/:id/status
// @access  Private (Volunteer / Admin)
const updateTaskStatus = async (req, res, next) => {
  try {
    const { status } = req.body;

    if (!status || !['In Progress', 'Completed'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Permitted status transitions are "In Progress" or "Completed".',
      });
    }

    const reliefRequest = await ReliefRequest.findById(req.params.id);
    if (!reliefRequest) {
      return res.status(404).json({
        success: false,
        message: 'Relief request not found',
      });
    }

    const isAdmin = req.user.role === 'admin';
    const isVolunteer = req.user.role === 'volunteer';

    if (!isAdmin && !isVolunteer) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden. Only volunteers can update task progress.',
      });
    }

    // Verify task is assigned to this volunteer
    if (
      isVolunteer &&
      (!reliefRequest.assignedVolunteer ||
        reliefRequest.assignedVolunteer.toString() !== req.user._id.toString())
    ) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You can only update tasks that are assigned to you.',
      });
    }

    const prevStatus = reliefRequest.status;

    // Strict status progression
    if (status === 'In Progress' && prevStatus !== 'Assigned') {
      return res.status(400).json({
        success: false,
        message: `Invalid status transition. Task must be in "Assigned" status to start, currently "${prevStatus}".`,
      });
    }

    if (status === 'Completed' && prevStatus !== 'In Progress') {
      return res.status(400).json({
        success: false,
        message: `Invalid status transition. Task must be in "In Progress" status before completing, currently "${prevStatus}".`,
      });
    }

    reliefRequest.status = status;
    await reliefRequest.save();

    // If completed, update Volunteer collection records
    if (status === 'Completed' && reliefRequest.assignedVolunteer) {
      await Volunteer.findOneAndUpdate(
        { user: reliefRequest.assignedVolunteer },
        {
          $addToSet: { completedTasks: reliefRequest._id },
          $pull: { assignedTasks: reliefRequest._id },
        }
      );
    }

    // Notify requester about status update
    if (reliefRequest.requester) {
      await createNotification({
        recipientId: reliefRequest.requester,
        title: `Relief Task Status: ${status}`,
        message: `Your relief request for ${reliefRequest.requestType} in ${reliefRequest.city} has been marked as "${status}".`,
        type: 'Relief Request',
        relatedId: reliefRequest._id,
      });
    }

    const populated = await ReliefRequest.findById(reliefRequest._id)
      .populate('requester', 'name email phone city')
      .populate('disaster', 'title disasterType city severity')
      .populate('assignedVolunteer', 'name email phone');

    return res.status(200).json({
      success: true,
      message: `Task marked as ${status} successfully`,
      reliefRequest: populated,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete relief request
// @route   DELETE /api/relief-requests/:id
// @access  Private (Admin or Requester if Pending)
const deleteReliefRequest = async (req, res, next) => {
  try {
    const reliefRequest = await ReliefRequest.findById(req.params.id);

    if (!reliefRequest) {
      return res.status(404).json({
        success: false,
        message: 'Relief request not found',
      });
    }

    if (
      req.user.role !== 'admin' &&
      reliefRequest.requester.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this relief request',
      });
    }

    await ReliefRequest.findByIdAndDelete(req.params.id);

    return res.status(200).json({
      success: true,
      message: 'Relief request removed successfully',
      deletedId: req.params.id,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createReliefRequest,
  getReliefRequests,
  getReliefRequestById,
  updateReliefRequest,
  deleteReliefRequest,
  assignVolunteerToReliefRequest,
  getMyAssignedTasks,
  updateTaskStatus,
};
