const Notification = require('../models/Notification');
const User = require('../models/User');

/**
 * Creates an in-app notification for a user or all admins
 * @param {Object} options
 * @param {string} [options.recipientId] - Specific recipient User ID
 * @param {boolean} [options.notifyAdmins] - If true, dispatches to all Admin users
 * @param {string} options.title - Notification title
 * @param {string} options.message - Notification body text
 * @param {string} options.type - Notification category
 * @param {string} [options.relatedId] - Associated entity ID
 */
const createNotification = async ({
  recipientId,
  notifyAdmins = false,
  title,
  message,
  type = 'System',
  relatedId = '',
}) => {
  try {
    if (notifyAdmins) {
      const admins = await User.find({ role: 'admin' }).select('_id');
      const adminNotifications = admins.map((admin) => ({
        recipient: admin._id,
        title,
        message,
        type,
        relatedId: relatedId ? relatedId.toString() : '',
      }));

      if (adminNotifications.length > 0) {
        await Notification.insertMany(adminNotifications);
      }
    }

    if (recipientId) {
      await Notification.create({
        recipient: recipientId,
        title,
        message,
        type,
        relatedId: relatedId ? relatedId.toString() : '',
      });
    }
  } catch (error) {
    console.error('[Notification Dispatch Error]:', error.message);
  }
};

module.exports = createNotification;
