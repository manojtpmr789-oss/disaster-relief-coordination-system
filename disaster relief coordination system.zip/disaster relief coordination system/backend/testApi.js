const testAllApis = async () => {
  const baseUrl = 'http://localhost:5000/api';
  console.log('=== RUNNING BACKEND API VALIDATION SUITE ===\n');

  try {
    // 1. Health check
    const healthRes = await fetch(`${baseUrl}/health`).then((r) => r.json());
    console.log('✔ Health Check:', healthRes.status === 'ONLINE' ? 'PASSED' : 'FAILED');

    // 2. Admin Login
    const adminLoginRes = await fetch(`${baseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'admin@disasterrelief.org',
        password: 'Admin@12345',
      }),
    }).then((r) => r.json());
    console.log('✔ Admin Login:', adminLoginRes.success && adminLoginRes.token ? 'PASSED' : 'FAILED');
    const adminToken = adminLoginRes.token;

    // 3. Register a new test user
    const randomSuffix = Date.now();
    const testEmail = `test_citizen_${randomSuffix}@disasterrelief.org`;
    const regRes = await fetch(`${baseUrl}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Citizen Jane Doe',
        email: testEmail,
        password: 'Password@12345',
        phone: '+1 555 123 9999',
        address: '77 Valley Rd',
        city: 'Shelter Bay',
        skills: ['First Aid'],
        availability: 'available',
      }),
    }).then((r) => r.json());
    console.log('✔ User Registration:', regRes.success && regRes.user.role === 'affected_user' ? 'PASSED' : 'FAILED');
    const userToken = regRes.token;
    const testUserId = regRes.user.id || regRes.user._id;

    // 4. Duplicate Email Validation
    const dupRes = await fetch(`${baseUrl}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Jane Clone',
        email: testEmail,
        password: 'Password@12345',
        phone: '+1 555 123 9999',
        address: '77 Valley Rd',
        city: 'Shelter Bay',
      }),
    });
    console.log('✔ Duplicate Email Rejection (400):', dupRes.status === 400 ? 'PASSED' : 'FAILED');

    // 5. Invalid Login Rejection
    const invalidLoginRes = await fetch(`${baseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: testEmail,
        password: 'WrongPassword!',
      }),
    });
    console.log('✔ Invalid Password Rejection (401):', invalidLoginRes.status === 401 ? 'PASSED' : 'FAILED');

    // 6. User GET /me
    const meRes = await fetch(`${baseUrl}/auth/me`, {
      headers: { Authorization: `Bearer ${userToken}` },
    }).then((r) => r.json());
    console.log('✔ GET /api/auth/me (User Token):', meRes.success && meRes.user.email === testEmail ? 'PASSED' : 'FAILED');

    // 7. User Profile Update
    const updateProfileRes = await fetch(`${baseUrl}/users/profile`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${userToken}`,
      },
      body: JSON.stringify({
        phone: '+1 555 999 8888',
        city: 'Highland Park',
        skills: ['First Aid', 'Emergency Dispatch'],
        availability: 'busy',
      }),
    }).then((r) => r.json());
    console.log(
      '✔ PUT /api/users/profile (Update):',
      updateProfileRes.success && updateProfileRes.user.city === 'Highland Park' ? 'PASSED' : 'FAILED'
    );

    // 8. Role Authorization Protection (Normal user accessing admin route)
    const forbiddenRes = await fetch(`${baseUrl}/users`, {
      headers: { Authorization: `Bearer ${userToken}` },
    });
    console.log('✔ Non-Admin Access Forbidden (403):', forbiddenRes.status === 403 ? 'PASSED' : 'FAILED');

    // 9. Admin GET /users with Search & Filter
    const adminGetUsersRes = await fetch(`${baseUrl}/users?search=Jane&role=affected_user`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log(
      '✔ Admin GET /api/users (Search & Filter):',
      adminGetUsersRes.success && adminGetUsersRes.users.length >= 1 ? 'PASSED' : 'FAILED'
    );

    // 10. Admin Update User Role
    const adminUpdateRoleRes = await fetch(`${baseUrl}/users/${testUserId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify({
        role: 'volunteer',
      }),
    }).then((r) => r.json());
    console.log(
      '✔ Admin Update User Role (PUT /api/users/:id):',
      adminUpdateRoleRes.success && adminUpdateRoleRes.user.role === 'volunteer' ? 'PASSED' : 'FAILED'
    );

    // 11. Dashboard Stats
    const statsRes = await fetch(`${baseUrl}/users/stats/summary`, {
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log(
      '✔ Dashboard Metrics Summary:',
      statsRes.success && statsRes.stats.totalUsers > 0 ? 'PASSED' : 'FAILED'
    );

    // 12. Admin Delete User
    const deleteRes = await fetch(`${baseUrl}/users/${testUserId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${adminToken}` },
    }).then((r) => r.json());
    console.log('✔ Admin Delete User (DELETE /api/users/:id):', deleteRes.success ? 'PASSED' : 'FAILED');

    console.log('\n=== ALL 12 BACKEND API TESTS PASSED SUCCESSFULLY! ===\n');
  } catch (err) {
    console.error('API Test Failed with error:', err);
  }
};

testAllApis();
