const mongoose = require('mongoose');
require('dotenv').config();

const Disaster = require('./models/Disaster');
const User = require('./models/User');

const runValidation = async () => {
  console.log('====================================================');
  console.log('🧪 TESTING DISASTER MODULE & MONGODB PERSISTENCE');
  console.log('====================================================');

  const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/disaster_relief_db';
  await mongoose.connect(mongoUri);
  console.log('✔ Connected to MongoDB:', mongoUri);

  const baseUrl = 'http://localhost:5000/api';

  // 1. Health check
  const health = await fetch(`${baseUrl}/health`).then((r) => r.json());
  console.log('✔ Backend Health API:', health.status);

  // 2. Login as affected user / admin
  let user = await User.findOne({ role: 'affected_user' });
  if (!user) {
    user = await User.create({
      name: 'Test Affected User',
      email: `test_affected_${Date.now()}@example.com`,
      password: 'User@12345',
      phone: '1234567890',
      address: 'Test Street 1',
      city: 'Testville',
      role: 'affected_user',
    });
  }

  const loginRes = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: user.email,
      password: 'User@12345',
    }),
  }).then((r) => r.json());

  let token = loginRes.token;
  if (!token) {
    // If password mismatch, try login with default resident
    const residentLogin = await fetch(`${baseUrl}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'resident@disasterrelief.org',
        password: 'Resident@12345',
      }),
    }).then((r) => r.json());
    token = residentLogin.token;
  }

  console.log('✔ Authenticated User Token acquired:', !!token);

  // 3. Test unauthenticated request rejection (401)
  const unauthRes = await fetch(`${baseUrl}/disasters`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: 'Unauthenticated flood report',
      disasterType: 'Flood',
      description: 'Water levels rising rapidly',
      location: 'Sector 5',
      city: 'Riverdale',
      severity: 'High',
    }),
  });
  console.log('✔ Unauthenticated rejection (401):', unauthRes.status === 401 ? 'PASSED' : 'FAILED');

  // 4. Test missing field rejection (400)
  const missingFieldRes = await fetch(`${baseUrl}/disasters`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      title: 'Missing description report',
      disasterType: 'Flood',
      location: 'Sector 5',
      city: 'Riverdale',
      severity: 'High',
    }),
  });
  console.log('✔ Missing required field rejection (400):', missingFieldRes.status === 400 ? 'PASSED' : 'FAILED');

  // 5. Submit valid disaster report (201)
  const reportPayload = {
    title: `Major River Overflow Sector ${Date.now().toString().slice(-4)}`,
    disasterType: 'Flood',
    description: 'High water levels breaching river banks. Immediate assistance requested.',
    location: 'Bridge No. 4, North Bank',
    city: 'Riverdale',
    severity: 'High',
    latitude: 19.076,
    longitude: 72.877,
  };

  const createRes = await fetch(`${baseUrl}/disasters`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(reportPayload),
  });

  const createData = await createRes.json();
  console.log('✔ Create Disaster POST (201):', createRes.status === 201 && createData.success ? 'PASSED' : 'FAILED');
  console.log('  Created ID:', createData.disaster?._id);
  console.log('  Initial Status:', createData.disaster?.status);
  console.log('  Reported By:', createData.disaster?.reportedBy?.name);

  const createdId = createData.disaster?._id;

  // 6. Direct MongoDB Verification
  const dbDoc = await Disaster.findById(createdId);
  console.log('✔ Direct MongoDB Document Verification:', dbDoc && dbDoc.title === reportPayload.title ? 'PASSED' : 'FAILED');
  console.log('  MongoDB doc status:', dbDoc?.status);
  console.log('  MongoDB doc reportedBy ref:', dbDoc?.reportedBy?.toString());

  // 7. Get Disaster by ID
  const getOneRes = await fetch(`${baseUrl}/disasters/${createdId}`, {
    headers: { Authorization: `Bearer ${token}` },
  }).then((r) => r.json());
  console.log('✔ GET /api/disasters/:id:', getOneRes.success && getOneRes.disaster?._id === createdId ? 'PASSED' : 'FAILED');

  // 8. Get All Disasters with Filters
  const getAllRes = await fetch(`${baseUrl}/disasters?search=Riverdale&type=Flood&severity=High`, {
    headers: { Authorization: `Bearer ${token}` },
  }).then((r) => r.json());
  console.log('✔ GET /api/disasters with search & filters:', getAllRes.success && getAllRes.disasters?.length > 0 ? 'PASSED' : 'FAILED');

  // 9. Update Disaster Status
  const updateRes = await fetch(`${baseUrl}/disasters/${createdId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ status: 'Verified' }),
  }).then((r) => r.json());
  console.log('✔ PUT /api/disasters/:id (Status Update):', updateRes.success && updateRes.disaster?.status === 'Verified' ? 'PASSED' : 'FAILED');

  // 10. Delete Disaster
  // Admin login for deletion
  const adminLogin = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: 'admin@disasterrelief.org',
      password: 'Admin@12345',
    }),
  }).then((r) => r.json());

  const deleteRes = await fetch(`${baseUrl}/disasters/${createdId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${adminLogin.token || token}` },
  }).then((r) => r.json());
  console.log('✔ DELETE /api/disasters/:id:', deleteRes.success ? 'PASSED' : 'FAILED');

  // Verify deletion in DB
  const postDeleteDb = await Disaster.findById(createdId);
  console.log('✔ Verified Deleted from MongoDB:', postDeleteDb === null ? 'PASSED' : 'FAILED');

  console.log('====================================================');
  console.log('🎉 ALL DISASTER MODULE BACKEND CHECKS PASSED!');
  console.log('====================================================');

  await mongoose.disconnect();
  process.exit(0);
};

runValidation().catch((err) => {
  console.error('Validation error:', err);
  process.exit(1);
});
