const mongoose = require('mongoose');

const disasterSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Disaster title is required'],
      trim: true,
    },
    disasterType: {
      type: String,
      required: [true, 'Disaster type is required'],
      enum: {
        values: [
          'Flood',
          'Earthquake',
          'Cyclone',
          'Landslide',
          'Fire',
          'Tsunami',
          'Drought',
          'Other',
        ],
        message: '{VALUE} is not a supported disaster type',
      },
    },
    description: {
      type: String,
      required: [true, 'Disaster description is required'],
      trim: true,
    },
    location: {
      type: String,
      required: [true, 'Specific location is required'],
      trim: true,
    },
    city: {
      type: String,
      required: [true, 'City/Region is required'],
      trim: true,
    },
    latitude: {
      type: Number,
      default: null,
    },
    longitude: {
      type: Number,
      default: null,
    },
    severity: {
      type: String,
      required: [true, 'Severity level is required'],
      enum: {
        values: ['Low', 'Medium', 'High', 'Critical'],
        message: '{VALUE} is not a valid severity level',
      },
    },
    reportedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Reporter reference is required'],
    },
    images: {
      type: [String],
      default: [],
    },
    status: {
      type: String,
      enum: {
        values: ['Pending', 'Verified', 'Active', 'Resolved'],
        message: '{VALUE} is not a valid status',
      },
      default: 'Pending',
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Disaster', disasterSchema);