const mongoose = require('mongoose');

const donationSchema = new mongoose.Schema(
  {
    donor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    donationType: {
      type: String,
      required: [true, 'Please select donation type'],
      enum: ['Money', 'Food', 'Water', 'Medicine', 'Clothing', 'Equipment', 'Other'],
      default: 'Money',
    },
    amount: {
      type: Number,
      default: 0,
      min: [0, 'Amount cannot be negative'],
    },
    itemName: {
      type: String,
      default: '',
      trim: true,
    },
    quantity: {
      type: Number,
      default: 1,
      min: [0, 'Quantity cannot be negative'],
    },
    description: {
      type: String,
      required: [true, 'Please provide description for donation'],
      trim: true,
    },
    disaster: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Disaster',
      default: null,
    },
    status: {
      type: String,
      enum: ['Pending', 'Received', 'Distributed', 'Rejected'],
      default: 'Pending',
    },
  },
  {
    timestamps: true,
  }
);

const Donation = mongoose.model('Donation', donationSchema);
module.exports = Donation;
