const mongoose = require('mongoose');

const reliefCampSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide relief camp/shelter name'],
      trim: true,
    },
    location: {
      type: String,
      required: [true, 'Please provide shelter address/location'],
      trim: true,
    },
    city: {
      type: String,
      required: [true, 'Please provide city'],
      trim: true,
    },
    latitude: {
      type: Number,
      default: 0,
    },
    longitude: {
      type: Number,
      default: 0,
    },
    capacity: {
      type: Number,
      required: [true, 'Please specify total capacity'],
      min: [1, 'Capacity must be at least 1 person'],
      default: 100,
    },
    currentOccupancy: {
      type: Number,
      min: [0, 'Occupancy cannot be negative'],
      default: 0,
    },
    availableBeds: {
      type: Number,
      default: 100,
    },
    foodAvailable: {
      type: Boolean,
      default: true,
    },
    medicalFacility: {
      type: Boolean,
      default: true,
    },
    contactNumber: {
      type: String,
      required: [true, 'Please provide camp manager contact number'],
      trim: true,
    },
    status: {
      type: String,
      enum: ['Open', 'Full', 'Closed'],
      default: 'Open',
    },
  },
  {
    timestamps: true,
  }
);

// Pre-save hook to calculate available beds and auto-update status
reliefCampSchema.pre('save', function (next) {
  if (this.currentOccupancy > this.capacity) {
    this.currentOccupancy = this.capacity;
  }
  this.availableBeds = Math.max(0, this.capacity - this.currentOccupancy);
  if (this.status !== 'Closed') {
    this.status = this.availableBeds === 0 ? 'Full' : 'Open';
  }
  next();
});

const ReliefCamp = mongoose.model('ReliefCamp', reliefCampSchema);
module.exports = ReliefCamp;
