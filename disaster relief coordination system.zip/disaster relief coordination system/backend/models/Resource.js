const mongoose = require('mongoose');

const resourceSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide resource name'],
      trim: true,
    },
    category: {
      type: String,
      required: [true, 'Please select a category'],
      enum: [
        'Food',
        'Water',
        'Medicine',
        'Clothing',
        'Shelter Equipment',
        'Emergency Equipment',
        'Other',
      ],
      default: 'Food',
    },
    quantity: {
      type: Number,
      required: [true, 'Please specify current quantity'],
      min: [0, 'Quantity cannot be negative'],
      default: 0,
    },
    unit: {
      type: String,
      required: [true, 'Please specify unit (e.g. kg, liters, boxes, units)'],
      trim: true,
      default: 'units',
    },
    location: {
      type: String,
      required: [true, 'Please provide warehouse/storage location'],
      trim: true,
    },
    city: {
      type: String,
      required: [true, 'Please provide city'],
      trim: true,
    },
    minimumStock: {
      type: Number,
      required: [true, 'Please specify minimum threshold before alert'],
      min: [0, 'Minimum stock cannot be negative'],
      default: 10,
    },
    expiryDate: {
      type: Date,
      default: null,
    },
    donatedBy: {
      type: String,
      default: 'Emergency Relief Reserve',
      trim: true,
    },
    status: {
      type: String,
      enum: ['Available', 'Low Stock', 'Out of Stock'],
      default: 'Available',
    },
  },
  {
    timestamps: true,
  }
);

// Pre-save hook to calculate status automatically
resourceSchema.pre('save', function (next) {
  if (this.quantity <= 0) {
    this.status = 'Out of Stock';
  } else if (this.quantity <= this.minimumStock) {
    this.status = 'Low Stock';
  } else {
    this.status = 'Available';
  }
  next();
});

const Resource = mongoose.model('Resource', resourceSchema);
module.exports = Resource;
