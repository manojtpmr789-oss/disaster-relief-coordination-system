const mongoose = require('mongoose');

const reliefRequestSchema = new mongoose.Schema(
  {
    requester: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    disaster: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Disaster',
      default: null,
    },
    requestType: {
      type: String,
      required: [true, 'Please specify request type'],
      enum: ['Food', 'Water', 'Medicine', 'Clothing', 'Shelter', 'Rescue', 'Other'],
      default: 'Food',
    },
    description: {
      type: String,
      required: [true, 'Please provide description of requested relief'],
      trim: true,
    },
    quantity: {
      type: Number,
      default: 1,
      min: [1, 'Quantity must be at least 1'],
    },
    priority: {
      type: String,
      enum: ['Low', 'Medium', 'High', 'Critical'],
      default: 'Medium',
    },
    location: {
      type: String,
      required: [true, 'Please provide delivery location or address'],
      trim: true,
    },
    city: {
      type: String,
      required: [true, 'Please provide city'],
      trim: true,
    },
    contactNumber: {
      type: String,
      required: [true, 'Please provide contact number'],
      trim: true,
    },
    status: {
      type: String,
      enum: ['Pending', 'Approved', 'Rejected', 'Assigned', 'In Progress', 'Completed'],
      default: 'Pending',
    },
    assignedVolunteer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

const ReliefRequest = mongoose.model('ReliefRequest', reliefRequestSchema);
module.exports = ReliefRequest;
