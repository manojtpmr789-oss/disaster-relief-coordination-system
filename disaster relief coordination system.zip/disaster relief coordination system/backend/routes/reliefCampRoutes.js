const express = require('express');
const {
  createReliefCamp,
  getReliefCamps,
  getReliefCampById,
  updateReliefCamp,
  updateOccupancy,
  deleteReliefCamp,
} = require('../controllers/reliefCampController');
const { requireAuth } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');

const router = express.Router();

router
  .route('/')
  .get(getReliefCamps)
  .post(requireAuth, createReliefCamp);

router
  .route('/:id')
  .get(getReliefCampById)
  .put(requireAuth, updateReliefCamp)
  .delete(requireAuth, requireRole('admin'), deleteReliefCamp);

router.put('/:id/occupancy', requireAuth, updateOccupancy);

module.exports = router;
