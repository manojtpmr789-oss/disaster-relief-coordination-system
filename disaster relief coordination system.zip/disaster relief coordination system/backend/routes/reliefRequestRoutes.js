const express = require('express');
const {
  createReliefRequest,
  getReliefRequests,
  getReliefRequestById,
  updateReliefRequest,
  deleteReliefRequest,
  assignVolunteerToReliefRequest,
  getMyAssignedTasks,
  updateTaskStatus,
} = require('../controllers/reliefRequestController');
const { requireAuth } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');

const router = express.Router();

// General requests collection
router
  .route('/')
  .get(requireAuth, getReliefRequests)
  .post(requireAuth, createReliefRequest);

// Dedicated volunteer tasks route (must be defined BEFORE :id)
router.get('/my-tasks', requireAuth, getMyAssignedTasks);

// Admin assignment route
router.put('/:id/assign', requireAuth, requireRole('admin'), assignVolunteerToReliefRequest);

// Volunteer task status transition route
router.put('/:id/status', requireAuth, updateTaskStatus);

// Single relief request CRUD
router
  .route('/:id')
  .get(requireAuth, getReliefRequestById)
  .put(requireAuth, updateReliefRequest)
  .delete(requireAuth, deleteReliefRequest);

module.exports = router;
