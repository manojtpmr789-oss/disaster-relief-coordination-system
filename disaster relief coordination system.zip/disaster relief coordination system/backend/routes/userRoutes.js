const express = require('express');
const {
  getProfile,
  updateProfile,
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  getDashboardStats,
} = require('../controllers/userController');
const { requireAuth } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');

const router = express.Router();

// User profile routes (Private to logged-in user)
router.get('/profile', requireAuth, getProfile);
router.put('/profile', requireAuth, updateProfile);

// Dashboard stats summary route (Private)
router.get('/stats/summary', requireAuth, getDashboardStats);

// Admin-only user management routes
router.get('/', requireAuth, requireRole('admin'), getAllUsers);
router.get('/:id', requireAuth, requireRole('admin'), getUserById);
router.put('/:id', requireAuth, requireRole('admin'), updateUser);
router.delete('/:id', requireAuth, requireRole('admin'), deleteUser);

module.exports = router;
