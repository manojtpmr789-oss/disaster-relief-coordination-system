const express = require('express');
const {
  createResource,
  getResources,
  getResourceById,
  updateResource,
  updateResourceQuantity,
  deleteResource,
} = require('../controllers/resourceController');
const { requireAuth } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');

const router = express.Router();

router
  .route('/')
  .get(requireAuth, getResources)
  .post(requireAuth, createResource);

router
  .route('/:id')
  .get(requireAuth, getResourceById)
  .put(requireAuth, updateResource)
  .delete(requireAuth, requireRole('admin'), deleteResource);

router.put('/:id/quantity', requireAuth, updateResourceQuantity);

module.exports = router;
