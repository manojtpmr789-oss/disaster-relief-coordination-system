const express = require('express');
const {
  getVolunteers,
  getVolunteerById,
  getMyVolunteerProfile,
  updateMyVolunteerProfile,
  verifyVolunteer,
  assignTaskToVolunteer,
} = require('../controllers/volunteerController');
const { requireAuth } = require('../middleware/authMiddleware');
const { requireRole } = require('../middleware/roleMiddleware');

const router = express.Router();

router.get('/', requireAuth, getVolunteers);
router.get('/profile/me', requireAuth, getMyVolunteerProfile);
router.put('/profile/me', requireAuth, updateMyVolunteerProfile);
router.get('/:id', requireAuth, getVolunteerById);
router.put('/:id/verify', requireAuth, requireRole('admin'), verifyVolunteer);
router.put('/:id/assign', requireAuth, requireRole('admin'), assignTaskToVolunteer);

module.exports = router;
