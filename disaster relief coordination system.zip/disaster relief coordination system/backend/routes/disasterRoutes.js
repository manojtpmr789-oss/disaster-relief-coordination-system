const express = require('express');
const {
  createDisaster,
  getDisasters,
  getDisasterById,
  updateDisaster,
  deleteDisaster,
} = require('../controllers/disasterController');
const { requireAuth } = require('../middleware/authMiddleware');

const router = express.Router();

router
  .route('/')
  .post(requireAuth, createDisaster)
  .get(requireAuth, getDisasters);

router
  .route('/:id')
  .get(requireAuth, getDisasterById)
  .put(requireAuth, updateDisaster)
  .delete(requireAuth, deleteDisaster);

module.exports = router;