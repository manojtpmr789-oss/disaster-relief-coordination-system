const express = require('express');
const { getDashboardStats, getVolunteerDashboardStats } = require('../controllers/dashboardController');
const { requireAuth } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/stats', requireAuth, getDashboardStats);
router.get('/volunteer-stats', requireAuth, getVolunteerDashboardStats);

module.exports = router;
