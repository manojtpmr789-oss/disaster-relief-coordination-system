const express = require('express');
const { getReportSummary } = require('../controllers/reportController');
const { requireAuth } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/summary', requireAuth, getReportSummary);

module.exports = router;
