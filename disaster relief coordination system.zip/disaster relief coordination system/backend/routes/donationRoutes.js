const express = require('express');
const {
  createDonation,
  getDonations,
  getDonationById,
  updateDonation,
  deleteDonation,
} = require('../controllers/donationController');
const { requireAuth } = require('../middleware/authMiddleware');

const router = express.Router();

router
  .route('/')
  .get(requireAuth, getDonations)
  .post(requireAuth, createDonation);

router
  .route('/:id')
  .get(requireAuth, getDonationById)
  .put(requireAuth, updateDonation)
  .delete(requireAuth, deleteDonation);

module.exports = router;
