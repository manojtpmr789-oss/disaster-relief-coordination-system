const mongoose = require('mongoose');
require('dotenv').config();

const User = require('./models/User');
const Volunteer = require('./models/Volunteer');

const runVolunteerValidation = async () => {
  console.log('====================================================');
  console.log('🧪 TESTING VOLUNTEER REGISTRATION & ADMIN VERIFICATION');
  console.log('====================================================');

  const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/disaster_relief_db';
  await mongoose.connect(mongoUri);
  console.log('✔ Connected to MongoDB:', mongoUri);

  const baseUrl = 'http://localhost:5000/api';

  // 1. Health check
  const health = await fetch(`${baseUrl}/health`).then((r) => r.json());
  console.log('✔ Backend Health API:', health.status);

  // 2. Register a new volunteer
  const uniqueTimestamp = Date.now();
  const volunteerPayload = {
    name: `Volunteer Marcus ${uniqueTimestamp.toString().slice(-4)}`,
    email: `volunteer_${uniqueTimestamp}@disasterrelief.org`,
    password: 'Volunteer@12345',
    phone: '+1 (555) 345-6789',
    address: '742 Responder Way, North Zone',
    city: 'Riverdale',
    role: 'volunteer',
    skills: ['First Aid / CPR', 'Search & Rescue', 'Emergency Driving'],
    availability: 'available',
    emergencyContact: '+1 (555) 987-6543',
  };

  const regRes = await fetch(`${baseUrl}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(volunteerPayload),
  });

  const regData = await regRes.json();
  console.log('✔ Volunteer Registration (201):', regRes.status === 201 && regData.success ? 'PASSED' : 'FAILED');
  console.log('  Registered User ID:', regData.user?._id || regData.user?.id);
  console.log('  Assigned Role:', regData.user?.role);

  const volunteerUserId = regData.user?._id || regData.user?.id;

  // 3. Direct MongoDB Verification of User document
  const userInDb = await User.findById(volunteerUserId);
  console.log('✔ User in MongoDB exists with role "volunteer":', userInDb && userInDb.role === 'volunteer' ? 'PASSED' : 'FAILED');

  // 4. Direct MongoDB Verification of Volunteer document
  const volunteerInDb = await Volunteer.findOne({ user: volunteerUserId });
  console.log('✔ Volunteer profile in MongoDB created:', !!volunteerInDb ? 'PASSED' : 'FAILED');
  console.log('  Volunteer doc ID:', volunteerInDb?._id);
  console.log('  Initial verificationStatus:', volunteerInDb?.verificationStatus);
  console.log('  Skills stored:', volunteerInDb?.skills);
  console.log('  City stored:', volunteerInDb?.city);
  console.log('  Emergency Contact:', volunteerInDb?.emergencyContact);

  if (volunteerInDb?.verificationStatus !== 'Pending') {
    throw new Error('FAILED: Initial verification status is not "Pending"');
  }

  // 5. Login as the newly created volunteer
  const volunteerLoginRes = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: volunteerPayload.email,
      password: volunteerPayload.password,
    }),
  }).then((r) => r.json());

  console.log('✔ Volunteer Login:', volunteerLoginRes.success && !!volunteerLoginRes.token ? 'PASSED' : 'FAILED');
  const volunteerToken = volunteerLoginRes.token;

  // 6. Admin Login
  const adminLoginRes = await fetch(`${baseUrl}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: 'admin@disasterrelief.org',
      password: 'Admin@12345',
    }),
  }).then((r) => r.json());

  console.log('✔ Admin Login:', adminLoginRes.success && !!adminLoginRes.token ? 'PASSED' : 'FAILED');
  const adminToken = adminLoginRes.token;

  // 7. Admin GET /api/volunteers (Verify newly created volunteer is in list)
  const getVolunteersRes = await fetch(`${baseUrl}/volunteers`, {
    headers: { Authorization: `Bearer ${adminToken}` },
  }).then((r) => r.json());

  console.log('✔ GET /api/volunteers list:', getVolunteersRes.success ? 'PASSED' : 'FAILED');
  const foundVolunteer = getVolunteersRes.volunteers?.find(
    (v) => (v.user?._id || v.user?.id || v.user) === volunteerUserId.toString()
  );
  console.log('✔ Newly registered volunteer found in Admin list:', !!foundVolunteer ? 'PASSED' : 'FAILED');
  console.log('  Status in list:', foundVolunteer?.verificationStatus);

  // 8. Admin Verify Volunteer action (PUT /api/volunteers/:id/verify)
  const verifyRes = await fetch(`${baseUrl}/volunteers/${volunteerInDb._id}/verify`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${adminToken}`,
    },
    body: JSON.stringify({ verificationStatus: 'Verified' }),
  }).then((r) => r.json());

  console.log('✔ Admin Verify action (PUT /api/volunteers/:id/verify):', verifyRes.success && verifyRes.volunteer?.verificationStatus === 'Verified' ? 'PASSED' : 'FAILED');

  // 9. Direct MongoDB check after Verify
  const verifiedInDb = await Volunteer.findById(volunteerInDb._id);
  console.log('✔ MongoDB verificationStatus is "Verified":', verifiedInDb.verificationStatus === 'Verified' ? 'PASSED' : 'FAILED');

  // 10. Non-admin forbidden check
  const nonAdminVerifyRes = await fetch(`${baseUrl}/volunteers/${volunteerInDb._id}/verify`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${volunteerToken}`,
    },
    body: JSON.stringify({ verificationStatus: 'Verified' }),
  });
  console.log('✔ Non-Admin Verify rejected (403):', nonAdminVerifyRes.status === 403 ? 'PASSED' : 'FAILED');

  // 11. Affected User Registration regression check
  const affectedPayload = {
    name: `Affected User ${uniqueTimestamp.toString().slice(-4)}`,
    email: `citizen_${uniqueTimestamp}@disasterrelief.org`,
    password: 'Password@12345',
    phone: '+1 (555) 111-2222',
    address: '12 Riverbank Dr',
    city: 'Riverdale',
    role: 'affected_user',
  };

  const affRegRes = await fetch(`${baseUrl}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(affectedPayload),
  }).then((r) => r.json());

  const affUserId = affRegRes.user?._id || affRegRes.user?.id;
  const affVolunteerDoc = await Volunteer.findOne({ user: affUserId });
  console.log('✔ Affected User registered with role "affected_user":', affRegRes.success && affRegRes.user?.role === 'affected_user' ? 'PASSED' : 'FAILED');
  console.log('✔ Affected User does NOT create Volunteer profile:', affVolunteerDoc === null ? 'PASSED' : 'FAILED');

  console.log('====================================================');
  console.log('🎉 ALL VOLUNTEER REGISTRATION & ADMIN VERIFICATION CHECKS PASSED!');
  console.log('====================================================');

  await mongoose.disconnect();
  process.exit(0);
};

runVolunteerValidation().catch((err) => {
  console.error('Validation error:', err);
  process.exit(1);
});
