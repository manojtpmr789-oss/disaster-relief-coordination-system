require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Disaster = require('./models/Disaster');
const ReliefRequest = require('./models/ReliefRequest');
const Volunteer = require('./models/Volunteer');
const Resource = require('./models/Resource');
const ReliefCamp = require('./models/ReliefCamp');
const Donation = require('./models/Donation');
const Notification = require('./models/Notification');

const seedFullData = async () => {
  try {
    const mongoUri =
      process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/disaster_relief_db';

    await mongoose.connect(mongoUri);
    console.log(`[Seed Script] Connected to database: ${mongoUri}`);

    // 1. Ensure / Get Seeded Users
    let admin = await User.findOne({ email: 'admin@disasterrelief.org' });
    if (!admin) {
      admin = await User.create({
        name: 'Emergency Coordinator Admin',
        email: 'admin@disasterrelief.org',
        password: 'Admin@12345',
        phone: '+1 (555) 019-2834',
        address: 'Incident Command HQ, Sector 4',
        city: 'Command HQ',
        role: 'admin',
        skills: ['Crisis Coordination', 'Disaster Response', 'Resource Logistics'],
        availability: 'available',
      });
    }

    let volunteerUser = await User.findOne({ email: 'volunteer@disasterrelief.org' });
    if (!volunteerUser) {
      volunteerUser = await User.create({
        name: 'Sarah Connor (First Responder)',
        email: 'volunteer@disasterrelief.org',
        password: 'Volunteer@12345',
        phone: '+1 (555) 043-9821',
        address: '142 Shelter Avenue',
        city: 'Metropolis',
        role: 'volunteer',
        skills: ['First Aid / CPR', 'Search & Rescue', 'Emergency Driving'],
        availability: 'available',
      });
    }

    let affectedUser = await User.findOne({ email: 'resident@disasterrelief.org' });
    if (!affectedUser) {
      affectedUser = await User.create({
        name: 'David Miller (Resident)',
        email: 'resident@disasterrelief.org',
        password: 'Resident@12345',
        phone: '+1 (555) 078-4312',
        address: '89 Riverside Boulevard, Zone B',
        city: 'Riverdale',
        role: 'affected_user',
        skills: [],
        availability: 'available',
      });
    }

    let donorUser = await User.findOne({ email: 'donor@disasterrelief.org' });
    if (!donorUser) {
      donorUser = await User.create({
        name: 'Global Aid Foundation (Donor)',
        email: 'donor@disasterrelief.org',
        password: 'Donor@12345',
        phone: '+1 (555) 091-1122',
        address: '500 Philanthropy Way, Suite 100',
        city: 'Capital City',
        role: 'donor',
        skills: ['Medical Supplies Funding', 'Food Rations Aid'],
        availability: 'available',
      });
    }

    // 2. Seed Volunteer Profile
    let volunteerProfile = await Volunteer.findOne({ user: volunteerUser._id });
    if (!volunteerProfile) {
      volunteerProfile = await Volunteer.create({
        user: volunteerUser._id,
        skills: ['First Aid / CPR', 'Search & Rescue', 'Emergency Driving', 'Paramedic'],
        availability: 'available',
        city: 'Metropolis',
        location: '142 Shelter Avenue',
        emergencyContact: '+1 (555) 043-9821',
        verificationStatus: 'Verified',
      });
    }

    // 3. Seed Disasters (with realistic GPS coordinates for Leaflet Map)
    const disasterCount = await Disaster.countDocuments();
    let sampleDisasters = [];
    if (disasterCount === 0) {
      sampleDisasters = await Disaster.insertMany([
        {
          title: 'Coastal Flash Flood & Surge Warning',
          disasterType: 'Flood',
          description: 'Severe coastal surge caused riverbanks to breach in Lower Harbor District. Over 400 households evacuated.',
          location: 'Lower Harbor Basin, Pier 12-18',
          city: 'Riverdale',
          latitude: 34.0522,
          longitude: -118.2437,
          severity: 'Critical',
          reportedBy: affectedUser._id,
          status: 'Active',
          images: [],
        },
        {
          title: 'Wildfire Containment Zone Alpha',
          disasterType: 'Fire',
          description: 'High-wind forest blaze approaching northern residential sectors. Rapid evacuation corridors active.',
          location: 'Pine Crest Ridge, North Sector',
          city: 'Metropolis',
          latitude: 34.1012,
          longitude: -118.3253,
          severity: 'High',
          reportedBy: volunteerUser._id,
          status: 'Active',
          images: [],
        },
        {
          title: 'Seismic Shockwave (Magnitude 6.2)',
          disasterType: 'Earthquake',
          description: 'Structural fissures reported on interstate highway bridge and urban water main burst.',
          location: 'Central Downtown Core, Grid 4',
          city: 'Capital City',
          latitude: 34.0407,
          longitude: -118.2468,
          severity: 'Critical',
          reportedBy: admin._id,
          status: 'Verified',
          images: [],
        },
        {
          title: 'Landslide Debris Blockade',
          disasterType: 'Landslide',
          description: 'Hillside debris blocking primary emergency convoy route on Highway 8.',
          location: 'Canyon Pass Mile 14',
          city: 'Highland Park',
          latitude: 34.1118,
          longitude: -118.1926,
          severity: 'Medium',
          reportedBy: affectedUser._id,
          status: 'Pending',
          images: [],
        },
      ]);
      console.log(`[Seed Script] Created ${sampleDisasters.length} disaster incident reports.`);
    } else {
      sampleDisasters = await Disaster.find();
    }

    // 4. Seed Relief Requests
    const requestCount = await ReliefRequest.countDocuments();
    if (requestCount === 0 && sampleDisasters.length > 0) {
      await ReliefRequest.insertMany([
        {
          requester: affectedUser._id,
          disaster: sampleDisasters[0]._id,
          requestType: 'Food',
          description: 'Urgent dry rations and bottled water for 12 stranded residents at Community Center.',
          quantity: 25,
          priority: 'High',
          location: '89 Riverside Boulevard, Zone B',
          city: 'Riverdale',
          contactNumber: '+1 (555) 078-4312',
          status: 'In Progress',
          assignedVolunteer: volunteerUser._id,
        },
        {
          requester: affectedUser._id,
          disaster: sampleDisasters[0]._id,
          requestType: 'Medicine',
          description: 'Insulin, sterile bandages, and basic pediatric antibiotics needed immediately.',
          quantity: 10,
          priority: 'Critical',
          location: 'Pier 14 Relief Point',
          city: 'Riverdale',
          contactNumber: '+1 (555) 078-4312',
          status: 'Approved',
          assignedVolunteer: null,
        },
        {
          requester: affectedUser._id,
          disaster: sampleDisasters[1]._id,
          requestType: 'Rescue',
          description: 'Senior citizen couple trapped due to smoke haze near canyon exit.',
          quantity: 2,
          priority: 'Critical',
          location: '412 North Ridge Lane',
          city: 'Metropolis',
          contactNumber: '+1 (555) 012-9933',
          status: 'Assigned',
          assignedVolunteer: volunteerUser._id,
        },
        {
          requester: affectedUser._id,
          disaster: sampleDisasters[2]._id,
          requestType: 'Water',
          description: 'Clean drinking water bottles for 50 evacuees following pipe rupture.',
          quantity: 100,
          priority: 'Medium',
          location: 'Downtown Assembly Square',
          city: 'Capital City',
          contactNumber: '+1 (555) 091-4455',
          status: 'Completed',
          assignedVolunteer: volunteerUser._id,
        },
      ]);
      console.log('[Seed Script] Seeded emergency relief requests.');
    }

    // 5. Seed Inventory Resources
    const resourceCount = await Resource.countDocuments();
    if (resourceCount === 0) {
      await Resource.insertMany([
        {
          name: 'Ready-to-Eat Emergency Food Rations',
          category: 'Food',
          quantity: 450,
          unit: 'packs',
          location: 'Central Depot Warehouse A',
          city: 'Metropolis',
          minimumStock: 100,
          donatedBy: 'Global Aid Foundation',
        },
        {
          name: 'Potable Drinking Water (5L Jugs)',
          category: 'Water',
          quantity: 80,
          unit: 'jugs',
          location: 'Harbor Logistics Bay 3',
          city: 'Riverdale',
          minimumStock: 100, // Trigger Low Stock
          donatedBy: 'Red Cross Aid',
        },
        {
          name: 'Trauma & Emergency First Aid Kits',
          category: 'Medicine',
          quantity: 15,
          unit: 'kits',
          location: 'Mobile Clinic Hub 1',
          city: 'Riverdale',
          minimumStock: 30, // Trigger Low Stock
          donatedBy: 'Apex Health Systems',
        },
        {
          name: 'Heavy Duty Evacuation Tents (6-Person)',
          category: 'Shelter Equipment',
          quantity: 65,
          unit: 'tents',
          location: 'Command HQ Storage',
          city: 'Command HQ',
          minimumStock: 20,
          donatedBy: 'Emergency Relief Reserve',
        },
        {
          name: 'Submersible Water Pumps & Generators',
          category: 'Emergency Equipment',
          quantity: 0,
          unit: 'units',
          location: 'Flood Response Shed B',
          city: 'Riverdale',
          minimumStock: 5, // Trigger Out of Stock
          donatedBy: 'Municipal Fire Services',
        },
        {
          name: 'Thermal Blankets & Winter Jackets',
          category: 'Clothing',
          quantity: 320,
          unit: 'sets',
          location: 'Central Depot Warehouse B',
          city: 'Capital City',
          minimumStock: 50,
          donatedBy: 'Citizens Relief Coalition',
        },
      ]);
      console.log('[Seed Script] Seeded inventory resources.');
    }

    // 6. Seed Relief Camps / Shelters (with GPS coordinates)
    const campCount = await ReliefCamp.countDocuments();
    if (campCount === 0) {
      await ReliefCamp.insertMany([
        {
          name: 'Riverdale High School Evacuation Shelter',
          location: '700 School Road, Sector 3',
          city: 'Riverdale',
          latitude: 34.0580,
          longitude: -118.2500,
          capacity: 250,
          currentOccupancy: 180,
          foodAvailable: true,
          medicalFacility: true,
          contactNumber: '+1 (555) 088-2341',
          status: 'Open',
        },
        {
          name: 'Metropolis Civic Center Relief Base',
          location: '100 Civic Plaza',
          city: 'Metropolis',
          latitude: 34.0950,
          longitude: -118.3100,
          capacity: 400,
          currentOccupancy: 400,
          foodAvailable: true,
          medicalFacility: true,
          contactNumber: '+1 (555) 077-9912',
          status: 'Full',
        },
        {
          name: 'St. Jude Community Hall & Clinic',
          location: '45 Church Street',
          city: 'Capital City',
          latitude: 34.0320,
          longitude: -118.2650,
          capacity: 120,
          currentOccupancy: 45,
          foodAvailable: true,
          medicalFacility: false,
          contactNumber: '+1 (555) 066-5544',
          status: 'Open',
        },
      ]);
      console.log('[Seed Script] Seeded relief camps & emergency shelters.');
    }

    // 7. Seed Donations
    const donationCount = await Donation.countDocuments();
    if (donationCount === 0) {
      await Donation.insertMany([
        {
          donor: donorUser._id,
          donationType: 'Money',
          amount: 15000,
          description: 'Emergency flood response funding for food distribution and clean water logistics.',
          status: 'Received',
          disaster: sampleDisasters[0]?._id || null,
        },
        {
          donor: donorUser._id,
          donationType: 'Food',
          itemName: 'Canned Nutrient Meals & Energy Bars',
          quantity: 500,
          description: '500 packs of high-calorie meal rations for displaced families.',
          status: 'Distributed',
          disaster: sampleDisasters[0]?._id || null,
        },
        {
          donor: donorUser._id,
          donationType: 'Medicine',
          itemName: 'Emergency Burn Creams & Sterile Gauze',
          quantity: 120,
          description: 'Medical supplies allocated for Wildfire containment zone responders.',
          status: 'Pending',
          disaster: sampleDisasters[1]?._id || null,
        },
        {
          donor: donorUser._id,
          donationType: 'Money',
          amount: 5000,
          description: 'Immediate shelter support and blankets fund.',
          status: 'Received',
          disaster: sampleDisasters[2]?._id || null,
        },
      ]);
      console.log('[Seed Script] Seeded aid donations.');
    }

    // 8. Seed Sample Notifications
    const notificationCount = await Notification.countDocuments();
    if (notificationCount === 0) {
      await Notification.insertMany([
        {
          recipient: admin._id,
          title: '🚨 Critical Disaster Reported: Coastal Flash Flood',
          message: 'Flash flood reported in Riverdale by resident. Severity: Critical.',
          type: 'Disaster',
          isRead: false,
        },
        {
          recipient: admin._id,
          title: '⚠️ Low Stock Alert: Potable Drinking Water',
          message: 'Water stock has fallen below threshold of 100 units at Riverdale Bay.',
          type: 'Resource',
          isRead: false,
        },
        {
          recipient: volunteerUser._id,
          title: 'Task Assigned: Food Dispatch in Riverdale',
          message: 'You have been assigned to coordinate 25 dry food packs.',
          type: 'Relief Request',
          isRead: false,
        },
        {
          recipient: affectedUser._id,
          title: 'Relief Request Update: In Progress',
          message: 'First Responder Sarah Connor is en route with your emergency rations.',
          type: 'Relief Request',
          isRead: false,
        },
      ]);
      console.log('[Seed Script] Seeded in-app notifications.');
    }

    await mongoose.connection.close();
    console.log('[Seed Script] Complete database seed finished successfully!');
    process.exit(0);
  } catch (error) {
    console.error('[Seed Error]:', error.message);
    process.exit(1);
  }
};

seedFullData();
